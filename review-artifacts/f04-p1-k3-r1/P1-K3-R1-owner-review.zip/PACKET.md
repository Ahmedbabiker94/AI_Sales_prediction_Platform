# F-04 P1-K3-R1 — Narrow crash-recovery correction

**NON-AUTHORITATIVE OWNER-REVIEW PACKET — 2026-11-21.**
**CHANGES REQUIRED remains the owner disposition; no protected-source authorization.**
**F-04 OPEN / NO-GO; B5-4-2 BLOCKED. P1-J UNAUTHORIZED / UNTRANSFERRED.**

## Exact identities and scope

Authenticated original K3 ZIP SHA-256:
`ca7178dc029ed8f905e036fd1b8581e38650e5349cf450b4a165dd478c445f51`.
Original K3 patch SHA-256:
`d0c57e33d1bd774b26070eaae3278e05335efb993ce8051d86c8c52a032846f7`.
Both originals are unchanged, including the previously published artifact.

- [Two-file R1 revision](revision.patch), against authenticated K3 proposed bytes:
  **6e4b4026323e961663ff6e8913956f6ed0703d8bac74465fead44116102a8f5b** (SHA-256).
- [Updated combined proposal](proposal.patch), against original source baseline
  `06c3c374232bb4fad6e549c322e3a1f6bdd0d195`:
  **3f3271c2e3f411381446109fec15461b64fbc03ef8ca87f5aebe86010b797550** (SHA-256).
- [Combined 23-path manifest](manifest.json), SHA-256 **ab78e03a175f880ac17cc9fcead5147432a9655e92dee4a193b2f11d75566d82**.
- [Exact two-file delta manifest](revision-manifest.json), SHA-256 **bf0019db5848ac571ce292623afba7aed764f1c6a14dfd7997ec49506c5aa7af**.

Only these two proposed source files differ from K3:

| Path | K3 Git blob | R1 Git blob |
|---|---|---|
| sales-forecast-platform/tests/postgres/credential_cleanup_supervisor.py | 5bc7c67a0be8d7a189da80eecb7db16d8efe5f99 | e4c579838226bed554f268fb0072043c72851e17 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_credential_supervision.py | 32bfb277ac1b51c706f1c1a073f873fa4c8fb455 | 6de654bf68955f6ccdd6a018d50e74e22a2cc362 |


The combined allowlist remains exactly 23 paths: no new path or operational
scope. All other 21 proposed files are byte-identical. All prior supervisor
functions/classes except _save are AST-identical, including _load, resource_plan,
reconcile, supervise, recovery main and private ACK validation. Imports for
secrets/stat and a 32-attempt allocation bound are the only new module support.
All 95 prior test methods and their assertions/decorators are AST-identical;
17 nonsecret recovery tests are appended in the existing test module. The
original RED source, historical fixture identities, image/wheel pins, selectors,
SQL/transport/admission contracts and excluded routes are unchanged.

## Confirmed defect and minimal correction

Original `_save` at lines 37-45 exclusively created one fixed
`.cleanup-lease-update` pathname. A leftover inode made every subsequent update
raise FileExistsError. The new regression reproduces this against the byte-
authenticated original implementation; the original source was never edited.

Corrected [supervisor _save](proposed/sales-forecast-platform/tests/postgres/credential_cleanup_supervisor.py#L36):

1. Allocate a fresh `.cleanup-lease-update-<128-bit nonce>` in the same directory,
   retaining O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC and mode 0600. Retry ONLY name
   collisions, with a maximum of 32. Never overwrite or delete a colliding object.
2. Retain the descriptor/inode until publication or error handling completes.
   Write, flush and fsync the complete nonsecret record before publication.
3. Verify the staging pathname still names that regular inode; recheck the
   canonical path's existing symlink restriction; atomically os.replace it.
4. Fsync the parent directory before success returns to any ACK-producing caller.
5. On failure, best-effort unlink ONLY this attempt's still-matching regular
   staging inode, then close the descriptor. Unknown replacements, symlinks and
   other processes' leftovers are never removed. Holding the FD prevents inode
   reuse from defeating this ownership comparison.

A hard interruption may still leave a nonsecret orphan. Recovery chooses another
exclusive pathname and does not parse, promote, follow or delete that orphan.
The original fixed staging file and malformed/forged/symlink/FIFO leftovers
therefore cannot permanently reserve the updater's sole slot. This is not a
fallback that disables exclusive creation, trusts temporary contents or permits
an absent/corrupt/untrusted canonical lease to authorize cleanup.

Canonical lease validation and exact resource name+label ownership checks are
unchanged. Recovery still writes UNCERTAIN and returns 72 even after currently
successful cleanup. It never sends a normal-completion ACK or creates an archive
receipt. A file visible after an ambiguous replace or directory-fsync failure
is not a successful private ACK. The existing same-invocation controller still
requires all original completion, teardown, handler and immutable-byte checks.

## Synthetic evidence and exact limits

| Check | Result |
|---|---|
| Authenticated original K3, new stale-fixed-file regression | Expected RED: FileExistsError; 1 unittest error |
| Python 3.12.14, focused R1 cases | 17 PASS, no failures/errors/skips |
| Python 3.12.14, full permitted synthetic suite | 112 PASS, no failures/errors/skips; includes unchanged 95 plus new 17 |
| Historical pure assertions | Eight functions exercised within the full suite; not pytest execution |
| Python 3.11 | UNEXECUTED: interpreter unavailable |
| Full pytest | UNEXECUTED: dependency unavailable; no installation |
| Original unchanged RED pytest node | UNEXECUTED; authoritative correction remains untransferred |
| Narrow and combined patch applicability | Both git apply --check PASS; no patch applied |
| Docker/PG, real signals/processes, target-host/power-loss proof | UNEXECUTED / NOT AUTHORIZED |

[New tests](proposed/sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_credential_supervision.py#L313)
cover interruption before replacement with an orphan retained; legacy fixed and
unique stale files; malformed/non-UTF8/forged-CONFIRMED contents; symlinks and FIFO;
forced file/directory/symlink collisions; bounded exhaustion then recovery;
KeyboardInterrupt/SystemExit during retries; file-fsync failure and descriptor
closure; displaced inode and staging-symlink substitution; O_EXCL/no-follow/mode
and fsync/rename order; directory-fsync failure without ACK; ambiguous final
replace with surviving CONFIRMED bytes but no ACK/receipt; repeated recovery;
and missing/untrusted/symlink canonical lease rejection.

Only public nonsecret metadata/markers are used by the new tests. The full suite
retains the prior deterministic fixture entropy and process/network/real-signal
audit guard. The filesystem operations themselves run on local temporary files;
reconciliation is stubbed. Failed-discard injection models a leftover after
uncatchable interruption; actual SIGKILL and crash durability were not tested.

Evidence: [RED log](red-results.txt), [focused log](focused-results.txt),
[full log](mock-results.txt), [verification](verification.json),
[applicability](applicability.json), [unexecuted checks](unexecuted-tests.md).
The original protected unexpected_manifest_secret regression is separate from
this new RED→GREEN counterexample. Its unchanged e0685f1c6cb4d932c33bc746ae4d14288c134620
source still imports actual run_postgres; only its equivalent actual-path
unittest ran. No mock result is integration or protected-runner acceptance.

## Same-pattern assessment

[Review](staging-pattern-review.md) and [scan evidence](staging-pattern-scan.json)
cover the exact original 42-member archive. No second fixed temporary-update
slot was found. The terminal-manifest publisher uses a random staging name;
its fixed final path intentionally refuses overwrites and stale PASS remains
non-authoritative. Fixed one-shot diagnostic outputs and exclusive initial
canonical lease creation have different fail-closed contracts and remain intact.
No admission-sensitive publisher, source fixture or other writer was modified.

## Residual risks and unchanged prerequisites

Unknown nonsecret orphans are deliberately retained, not garbage-collected.
Storage exhaustion, permissions, entropy/I/O faults, hostile ancestor races and
unsupported directory fsync can still fail closed. This correction removes the
specific permanent fixed-name collision; it does not promise recovery under an
unavailable or adversarial filesystem. It introduces no transactional CAS or
new multi-writer authority. The existing private-directory/trusted-host and
supervisor/restarter coordination requirements remain.

The external restarter, daemon uncertainty, target WSL/Windows filesystem,
physical crash durability, real interruption/restart, credential lifecycle,
no-persistent-plaintext policy, host swap/core controls and all prior supply-chain
and integration obligations remain UNVERIFIED. Finite empty inventory does not
resolve potentially late daemon mutations. No uncertainty or stale file becomes
an admission receipt. Source review and local fsync ordering are not power-loss
or real Docker/PostgreSQL proof.

Before any protected transfer, require separate owner review of the NEW hashes,
full mandatory offline tests on Python 3.11/3.12 (including unchanged original
RED), applicable provenance/security checks and explicit narrowly scoped source
permission. Any further necessary file/delta or failed assertion returns for
review; no skips, weakening or silent rebaseline. Real integration and restarter
deployment still need their own authorization. This AI packet is not independent
human signoff or owner acceptance.

Rollback of this proposal revision, if needed, restores only the two prior
proposed blobs listed above after checking current identities; that restores a
known recovery defect and does not make K3 acceptable. Protected checkout,
P1-J, original K3 archive and remote branches were not modified. No transfer,
merge, push, deployment, Docker/PG or real credential generation occurred.

Stop for owner review. F-04 OPEN / NO-GO; B5-4-2 BLOCKED.
