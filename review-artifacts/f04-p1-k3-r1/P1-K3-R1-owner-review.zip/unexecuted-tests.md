# Independent execution status

- Python 3.12.14: 112 stdlib unittest methods PASS; 0 failures/errors/skips.
  This includes all 95 unchanged K3 methods and the 17 R1 methods, not 129 tests.
  Eight historical assertion functions are exercised within that suite; not an
  additional pytest collection count.
- Focused R1: the same 17 methods PASS as a separately recorded subset.
- Authenticated OLD K3: one focused regression produces the expected
  FileExistsError (1 unittest error), proving the reported defect before correction.
- Python 3.11: ALL TESTS UNEXECUTED; interpreter unavailable.
- Full pytest: ALL NODES UNEXECUTED; dependency unavailable. None installed.
- Original unchanged unexpected_manifest_secret pytest node: UNEXECUTED. Its
  source remains e0685f1c6cb4d932c33bc746ae4d14288c134620; its equivalent actual
  proposed-runtime unittest is among the unchanged 95 and passes. No claim that
  the protected runner or original pytest node is GREEN is made.
- Real Docker/PostgreSQL, actual process supervision/signals/SIGKILL, WSL/Windows
  host filesystem, daemon timing, reboot/power-loss durability: UNEXECUTED and
  unauthorized. Tests use nonsecret local temporary files plus injected faults
  and stubbed reconciliation; no new credential-bearing tests exist.
- The original 39 workflow module entries remain unchanged. Original K3 metadata
  for unmaterialized baseline modules is inherited, not newly inspected or run.
  test-catalog.json lists source-level names, not collected parametrized IDs.

An initial attempt to load the original supervisor for the RED harness lacked
its sibling module import path and failed before the test ran. That harness
setup was corrected; red-results.txt contains the actual authenticated-source
counterexample. No source assertion was changed to obtain RED or GREEN.
