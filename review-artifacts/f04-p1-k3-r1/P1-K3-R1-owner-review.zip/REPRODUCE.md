# Reproduction and verification plan

This is a non-authoritative review bundle, not permission to apply or execute
operational code. Confirm original archive/patch identities and the new narrow
and combined hashes in PACKET.md, then validate every raw-file Git blob and
SHA-256 against the manifests. Git blob identity hashes `blob <size>\0<bytes>`.

The full proposal still requires a complete pinned repository baseline to run
all historical tests; the ZIP contains the 23 proposed files, not every unchanged
baseline module. run_mock_proposal.py exercises only the original four permitted
unittest modules with real external operations denied and deterministic public
fixture entropy. run_focused_recovery.py selects the 17 appended recovery tests.
No pytest replacement or dependency installation is included.

run_red_regression.py additionally reads the retained authenticated original K3
supervisor from the sibling K3 workspace and verifies its manifest hash before
running the SAME stale-stage assertion against it. It should fail with exactly
FileExistsError; red-results.txt records that counterexample. The revision tests
must pass unchanged against the corrected supervisor. Script paths document this
session layout and may require an explicitly configured isolated evidence layout
elsewhere; do not silently substitute another source version.

verify_revision.py reads prior K3 evidence and the materialized pinned baseline.
It generates/checks review artifacts only in its own non-authoritative directory;
it does not apply either patch. Do not run old K3/J artifact generators against
this revision. Preserve delivered logs; run any authorized reproduction in a new
isolated evidence directory. No application to protected sources is authorized.

Read-only applicability checks already passed: revision.patch against original
K3 proposed bytes, proposal.patch against original 06c3c374 materialized baseline.
Future full pytest/Python 3.11/3.12, original RED and all integration proof remain
separate prerequisites; see unexecuted-tests.md. No Docker/PG, true signals,
service deployment or publication is authorized here.
