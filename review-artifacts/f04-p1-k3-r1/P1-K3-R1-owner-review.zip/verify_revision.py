"""Assemble only local review artifacts; never applies patches or publishes."""
import ast
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'F04-P1-K3-NON-AUTHORITATIVE-06c3c374'
OLD_ZIP='ca7178dc029ed8f905e036fd1b8581e38650e5349cf450b4a165dd478c445f51'
OLD_PATCH='d0c57e33d1bd774b26070eaae3278e05335efb993ce8051d86c8c52a032846f7'
ORIGINAL_BASE='06c3c374232bb4fad6e549c322e3a1f6bdd0d195'
PG='sales-forecast-platform/tests/postgres/'
RT='sales-forecast-platform/tests/runtime/'
DELTA=[PG+'credential_cleanup_supervisor.py',RT+'test_r7_05b5_4_1_f04_credential_supervision.py']

def sha(data):return hashlib.sha256(data).hexdigest()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def files(root):return {str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*')
    if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
assert sha((PRIOR/'P1-K3-owner-review.zip').read_bytes())==OLD_ZIP
assert sha((PRIOR/'proposal.patch').read_bytes())==OLD_PATCH
assert sha((PRIOR/'manifest.json').read_bytes())=='84f1c22b0d610303b34c31c8f52fd018ede2420cb783754933cc8125c5b3de43'
oldmanifest=json.loads((PRIOR/'manifest.json').read_text())
with zipfile.ZipFile(PRIOR/'P1-K3-owner-review.zip') as archive:
 assert archive.testzip() is None
 for row in oldmanifest['files']:
  data=(PRIOR/'proposed'/row['path']).read_bytes()
  assert data==archive.read('proposed/'+row['path']) and sha(data)==row['sha256']
old=files(PRIOR/'proposed');new=files(ROOT/'proposed');base=files(ROOT/'baseline')
assert {p for p in set(old)|set(new) if old.get(p)!=new.get(p)}==set(DELTA)
rows=json.loads((ROOT/'allowlist.json').read_text());assert len(rows)==23
assert {p for p in set(base)|set(new) if base.get(p)!=new.get(p)}=={r['path'] for r in rows}
pins=json.loads((ROOT/'baseline-pins.json').read_text())['blobs']
for row in rows:
 if row['old_blob']:assert blob(base[row['path']])==row['old_blob']==pins[row['path']]
for rel,data in new.items():
 if rel.endswith('.py'):ast.parse(data.decode(),filename=rel)
# Every prior definition except _save is EXACT; imports and UPDATE_ATTEMPTS
# are the only additional top-level operational definitions.
def definitions(data):return {n.name:n for n in ast.parse(data).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
old_defs=definitions(old[DELTA[0]]);new_defs=definitions(new[DELTA[0]])
assert old_defs.keys()==new_defs.keys()
for name,node in old_defs.items():
 if name!='_save':assert ast.dump(node)==ast.dump(new_defs[name]),name
original_tests=0
for suffix in ('operational_admission','excluded_entrypoints','credential_transport','credential_supervision'):
 rel=RT+'test_r7_05b5_4_1_f04_'+suffix+'.py'
 before=ast.parse(old[rel]);after=ast.parse(new[rel])
 classes={n.name:n for n in after.body if isinstance(n,ast.ClassDef)}
 for cls in before.body:
  if not isinstance(cls,ast.ClassDef):continue
  existing={n.name:n for n in classes[cls.name].body if isinstance(n,ast.FunctionDef)}
  for fn in cls.body:
   if isinstance(fn,ast.FunctionDef):
    assert ast.dump(fn)==ast.dump(existing[fn.name]),cls.name+'.'+fn.name
    if fn.name.startswith('test_'):original_tests+=1
assert original_tests==95
red=RT+'test_r7_05b5_4_1_f04_cleanup_lifecycle.py'
assert new[red]==old[red]==base[red] and blob(new[red])=='e0685f1c6cb4d932c33bc746ae4d14288c134620'
for name,expected in (('run_postgres.py.txt','0863e81b733381a80b2f83560d8bbc231513ba41'),
                      ('run_b5_4_1_postgres.py.txt','040d0d30bb719d646eb350b229ccd9a4c5f2bf79')):
 assert blob(new[RT+'fixtures/f04_p1f/'+name])==expected

def patch_between(before,after,paths):
 output=[]
 for path in paths:
  old_data=before.get(path,b'');new_data=after[path]
  output.append(f'diff --git a/{path} b/{path}\n')
  if path not in before:output.append('new file mode 100644\n')
  output.append('index '+(blob(old_data) if path in before else '0'*40)+'..'+blob(new_data)+' 100644\n')
  output.extend(difflib.unified_diff(old_data.decode().splitlines(keepends=True),new_data.decode().splitlines(keepends=True),
      fromfile='a/'+path if path in before else '/dev/null',tofile='b/'+path,n=3))
 return ''.join(output).encode()
combined=patch_between(base,new,[r['path'] for r in rows]);delta=patch_between(old,new,DELTA)
(ROOT/'proposal.patch').write_bytes(combined)
(ROOT/'revision.patch').write_bytes(delta)
manifest_rows=[]
for row in rows:
 path=row['path'];data=new[path]
 manifest_rows.append(dict(row,new_blob=blob(data),sha256=sha(data),old_size=len(base.get(path,b'')),new_size=len(data)))
payload=dict(authority='NON-AUTHORITATIVE P1-K3-R1; NO TRANSFER OR REMOTE PUBLICATION AUTHORIZATION',
 baseline_commit=ORIGINAL_BASE,inventory_commit='4f84e168b495c6e77c53520cfeeb9c80a8c0010c',
 prior_untransferred_K3_patch_sha256=OLD_PATCH,authenticated_K3_zip_sha256=OLD_ZIP,
 patch_sha256=sha(combined),revision_patch_sha256=sha(delta),files=manifest_rows)
(ROOT/'manifest.json').write_text(json.dumps(payload,indent=2)+'\n')
delta_rows=[dict(path=p,old_blob=blob(old[p]),new_blob=blob(new[p]),old_sha256=sha(old[p]),new_sha256=sha(new[p]),
                old_size=len(old[p]),new_size=len(new[p]),mode='100644') for p in DELTA]
(ROOT/'revision-manifest.json').write_text(json.dumps(dict(against='authenticated untransferred P1-K3 proposed bytes',
 prior_patch_sha256=OLD_PATCH,prior_zip_sha256=OLD_ZIP,revision_patch_sha256=sha(delta),files=delta_rows),indent=2)+'\n')
(ROOT/'changed-file-identities.md').write_text('| Path | K3 Git blob | R1 Git blob |\n|---|---|---|\n'+
 '\n'.join(f"| {r['path']} | {r['old_blob']} | {r['new_blob']} |" for r in delta_rows)+'\n')
full=json.loads((ROOT/'mock-results.json').read_text());focused=json.loads((ROOT/'focused-results.json').read_text())
red_result=json.loads((ROOT/'red-results.json').read_text())
assert full['successful'] and full['tests_run']==112 and full['failures']==full['errors']==full['skipped']==0
assert focused['successful'] and focused['tests_run']==17 and focused['failures']==focused['errors']==focused['skipped']==0
assert not red_result['successful'] and red_result['tests_run']==1 and red_result['errors']==1
report=dict(status='FOCUSED REVISION PREPARED; OWNER AUTHORIZATION NOT GRANTED',
 original_K3_zip_unchanged=True,original_K3_patch_unchanged=True,
 exact_changed_files=DELTA,all_other_proposed_files_byte_identical=True,
 combined_allowlist_paths=23,new_allowlist_paths=0,original_baseline_preimages_verified=True,
 unchanged_supervisor_definitions=sorted(name for name in old_defs if name!='_save'),
 original_95_tests_ast_identical=True,original_RED_source_unchanged=True,historical_fixtures_unchanged=True,
 test_results=dict(python_312=full,focused=focused,old_K3_counterexample=red_result,
                  python_311='UNEXECUTED: interpreter absent',full_pytest='UNEXECUTED: dependency absent',
                  original_RED_pytest='UNEXECUTED: source unchanged; no pytest installed',
                  live_Docker_PostgreSQL_signals_power_loss='UNEXECUTED / NOT AUTHORIZED'),
 combined_patch_sha256=sha(combined),revision_patch_sha256=sha(delta))
(ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(combined_sha256=sha(combined),revision_sha256=sha(delta),changed_files=delta_rows,
 python_312_methods=full['tests_run'],focused_methods=focused['tests_run']),indent=2))
