"""Independent nonsecret lease supervisor for one fixed disposable resource set.

Separate session, private EOF pipe and deadline survive a runner-only SIGKILL.
If this process or the host also dies, an independently installed service must
invoke --recover on overdue leases after Docker becomes available. No finite
absence observation resolves an uncertain daemon mutation: retain its lease.
This module never admits evidence and never receives PostgreSQL credentials.
"""
import json
import os
from pathlib import Path
import selectors
import secrets
import signal
import stat
import subprocess
import sys
import time
from uuid import UUID
from credential_transport import DOCKER, TransportFailure, clean_host_environment, _kind, _failure

LEASE_NAME = 'cleanup-lease.json'
LEASE_SECONDS = 1200
UPDATE_ATTEMPTS = 32


def resource_plan(run_id):
    if type(run_id) is not str or str(UUID(run_id)) != run_id:
        raise ValueError('invalid cleanup identity')
    prefix = 'r7-05b3-' + UUID(run_id).hex
    return ([prefix+suffix for suffix in
             ('-provision','-server','-foundation','-restart','-b5-4-1')],
            [prefix+'-data', prefix+'-socket'])


def _save(path, record, *, initial=False):
    if path.name != LEASE_NAME or path.absolute() != path.resolve():
        raise ValueError('invalid private lease path')
    encoded = json.dumps(record, sort_keys=True).encode('ascii')
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC
    target = None
    descriptor = None
    identity = None
    published = False
    try:
        if initial:
            target = path
            descriptor = os.open(target, flags, 0o600)
        else:
            # A killed updater may leave any earlier staging inode behind.
            # Never consume, overwrite, unlink or trust that unknown object.
            for _ in range(UPDATE_ATTEMPTS):
                candidate = path.with_name('.cleanup-lease-update-' + secrets.token_hex(16))
                try:
                    descriptor = os.open(candidate, flags, 0o600)
                except FileExistsError:
                    continue
                target = candidate
                break
            if descriptor is None:
                raise FileExistsError('private lease update allocation exhausted')
        info = os.fstat(descriptor)
        identity = (info.st_dev, info.st_ino)
        # Retain the descriptor through publication/failure cleanup so an
        # unlinked inode cannot be reused and mistaken for our own staging file.
        with os.fdopen(descriptor, 'wb', closefd=False) as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(descriptor)
        if not initial:
            current = target.lstat()
            if (not stat.S_ISREG(current.st_mode)
                    or (current.st_dev, current.st_ino) != identity):
                raise OSError('private lease update staging changed')
            if path.absolute() != path.resolve():
                raise ValueError('invalid private lease path')
            os.replace(target, path)
            published = True
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        try:
            if not initial and not published and target is not None and identity is not None:
                try:
                    current = target.lstat()
                    if (stat.S_ISREG(current.st_mode)
                            and (current.st_dev, current.st_ino) == identity):
                        target.unlink()
                except OSError:
                    pass  # An orphan is non-authoritative and cannot reserve a fixed slot.
        finally:
            if descriptor is not None:
                os.close(descriptor)


def _load(path):
    if path.name != LEASE_NAME or path.absolute() != path.resolve():
        raise ValueError('invalid private lease')
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    with os.fdopen(descriptor, 'rb') as stream:
        import stat
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise ValueError('untrusted lease ownership')
        content = stream.read(2049)
    if len(content) > 2048:
        raise ValueError('oversized lease')
    value = json.loads(content)
    if (type(value) is not dict or set(value) != {'version','run_id','deadline','state'}
            or type(value['version']) is not int or value['version'] != 1
            or type(value['deadline']) is not int
            or value['state'] not in ('ARMED','UNCERTAIN','CONFIRMED')):
        raise ValueError('invalid cleanup lease')
    resource_plan(value['run_id'])
    return value


def _command(args):
    return subprocess.run([*DOCKER,*args], stdin=subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          env=clean_host_environment(), timeout=3,
                          close_fds=True, start_new_session=True)


def reconcile(run_id, command=_command):
    """Full exact name AND label required before deletion; no prune/foreign rm."""
    containers, volumes = resource_plan(run_id)
    confirmed = True
    for kind, names in (('container',containers), ('volume',volumes)):
        for name in names:
            try:
                result = command([kind,'inspect',name])
                if result.returncode:
                    confirmed = (b'no such '+kind.encode() in result.stderr.lower()) and confirmed
                    continue
                value = json.loads(result.stdout)
                if type(value) is not list or len(value) != 1 or type(value[0]) is not dict:
                    confirmed = False
                    continue
                item = value[0]
                labels = item.get('Config',{}).get('Labels') if kind == 'container' else item.get('Labels')
                actual = item.get('Name')
                if kind == 'container' and type(actual) is str:
                    actual = actual.removeprefix('/')
                if (actual != name or type(labels) is not dict
                        or labels.get('r7_05b3_run') != run_id):
                    confirmed = False
                    continue
                removal = ['rm','-f',name] if kind == 'container' else ['volume','rm',name]
                confirmed = (command(removal).returncode == 0) and confirmed
            except Exception:
                confirmed = False
        # Containers must be absent before deleting any volumes.
        if kind == 'container' and not confirmed:
            return False
    for query in (['ps','-aq','--filter','label=r7_05b3_run='+run_id],
                  ['volume','ls','-q','--filter','label=r7_05b3_run='+run_id]):
        try:
            result = command(query)
            if result.returncode or result.stdout.strip():
                confirmed = False
        except Exception:
            confirmed = False
    return confirmed


def supervise(path, *, input_fd=0, output_fd=1):
    record = _load(path)
    os.write(output_fd, b'ARMED\n')
    request = bytearray()
    with selectors.DefaultSelector() as selector:
        selector.register(input_fd, selectors.EVENT_READ)
        while time.time() < record['deadline']:
            if not selector.select(min(.25,max(0,record['deadline']-time.time()))):
                continue
            part = os.read(input_fd, 17-len(request))
            if not part:
                break
            request.extend(part)
            if len(request) > 16 or b'\n' in part:
                break
    settled = bytes(request) == b'SETTLED\n'
    # Persist uncertainty BEFORE attempting cleanup so supervisor death/reboot
    # leaves a recoverable, nonsecret lease. Never remove an uncertain lease.
    record['state'] = 'UNCERTAIN'
    _save(path, record)
    clean = reconcile(record['run_id'])
    if settled and clean:
        record['state'] = 'CONFIRMED'
        _save(path, record)
        os.write(output_fd,b'CONFIRMED\n')
        return 0
    # EOF/deadline/unknown request never proves daemon quiescence, even if
    # currently absent. A separate service retries cleanup, not admission.
    return 72


class CleanupSupervisor:
    def __init__(self, run_id, evidence):
        resource_plan(str(run_id))
        self.run_id = run_id
        self.path = Path(evidence)/LEASE_NAME
        self.process = None
        self.confirmed = False
        self.deadline = None

    def check_live(self):
        failed = None
        try:
            lease = _load(self.path)
            if (self.process is None or self.process.poll() is not None
                    or self.deadline is None or time.time() >= self.deadline
                    or lease['state'] != 'ARMED'
                    or lease['run_id'] != str(self.run_id)
                    or lease['deadline'] != self.deadline):
                failed = 'FAILED'
        except BaseException as error:
            failed = _kind(error)
        if failed:
            raise _failure(failed)

    def _read(self, expected):
        deadline = time.monotonic()+30
        content = bytearray()
        with selectors.DefaultSelector() as selector:
            selector.register(self.process.stdout,selectors.EVENT_READ)
            while time.monotonic()<deadline and len(content)<=32:
                if selector.select(.1):
                    part = os.read(self.process.stdout.fileno(),1)
                    if not part:
                        break
                    content.extend(part)
                    if part == b'\n':
                        return bytes(content) == expected
        return False

    def start(self):
        record = dict(version=1, run_id=str(self.run_id),
                      deadline=int(time.time())+LEASE_SECONDS, state='ARMED')
        self.deadline = record['deadline']
        _save(self.path,record,initial=True)
        failure = None
        try:
            self.process = subprocess.Popen(
                [sys.executable,str(Path(__file__).resolve()),'--supervise',str(self.path)],
                stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                env=clean_host_environment(),start_new_session=True,close_fds=True)
            if not self._read(b'ARMED\n'):
                raise RuntimeError()
            self.check_live()
        except BaseException as error:
            failure = _kind(error)
            self.abandon()
        if failure:
            raise _failure(failure)

    def finish(self, settled):
        failure = False
        try:
            if self.process is None or settled is not True:
                raise RuntimeError()
            self.process.stdin.write(b'SETTLED\n')
            self.process.stdin.flush()
            self.process.stdin.close()
            accepted = self._read(b'CONFIRMED\n')
            code = self.process.wait(timeout=5)
            lease = _load(self.path)
            self.confirmed = (accepted is True and type(code) is int and code == 0
                              and lease['state'] == 'CONFIRMED'
                              and lease['run_id'] == str(self.run_id)
                              and lease['deadline'] == self.deadline)
        except BaseException:
            failure = True
        if failure or not self.confirmed:
            self.abandon()
            return 'UNCONFIRMED'
        return 'CONFIRMED'

    def abandon(self):
        # Closing the private pipe asks the independent process to reconcile.
        # Do NOT kill it with the runner's CLI process group.
        if self.process is not None:
            try:
                self.process.stdin.close()
            except BaseException:
                pass


def main(argv):
    if len(argv)==2 and argv[0]=='--supervise':
        return supervise(Path(argv[1]))
    if len(argv)==3 and argv[:2]==['--allow-owned-disposable-cleanup','--recover']:
        path=Path(argv[2])
        record=_load(path)
        if time.time()<record['deadline'] or record['state']=='CONFIRMED':
            return 73
        # An overdue lease can be retried but cannot become an admission proof.
        reconcile(record['run_id'])
        record['state']='UNCERTAIN'
        _save(path,record)
        return 72
    return 74


if __name__=='__main__':
    status=74
    try:
        status=main(sys.argv[1:])
    except BaseException:
        pass
    raise SystemExit(status)
