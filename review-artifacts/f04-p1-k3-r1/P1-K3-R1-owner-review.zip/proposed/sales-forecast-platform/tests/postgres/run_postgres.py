"""Narrow B5-4-1 runtime. Low-level run() is not evidence admission.

Trusted-host, synchronous model only. The standalone CLI is excluded.
Operational success requires run_manifest_admission_controller.py.
"""
import argparse
from contextvars import ContextVar
import signal
import hashlib
import json
import re
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
from uuid import uuid4
from credential_transport import (CredentialSession, scram_verifier, validate_verifier,
                                  clean_host_environment)
from credential_cleanup_supervisor import CleanupSupervisor

BASE = 'sha256:417063b71e35c7a9889c10ac2516c328f16a483e065ec858df101eb9728c2df2'
POSTGRES = 'sha256:6a35283e53fbe883da6a6ffbce8d3999dc66076cc5c4e2f1d21bdbd9e26bf86f'
WHEEL = 'psycopg2_binary-2.9.12-cp311-cp311-manylinux2014_x86_64.manylinux_2_17_x86_64.whl'
WHEEL_SHA256 = 'e4e184b1fb6072bf05388aa41c697e1b2d01b3473f107e7ec44f186a32cfd0b8'
ROOT = Path(__file__).resolve().parents[2]
_LIFECYCLE = ContextVar('postgres_test_lifecycle', default=None)
_SUPERVISOR = ContextVar('postgres_cleanup_supervisor', default=None)
_TEST_SECRETS = ContextVar('postgres_test_secret_values', default=())


REPLACEMENT = "<redacted-disposable-secret>"


def _redact(text, secrets):
    if type(text) is not str or type(secrets) is not tuple:
        raise ValueError("invalid redaction inputs")
    if any(type(secret) is not str or not secret for secret in secrets):
        raise ValueError("invalid disposable secret")
    # The original runner uses distinct generated secrets. Disallow ambiguity
    # here; overlapping secrets would otherwise produce order-dependent counts.
    if len(set(secrets)) != len(secrets) or any(
        left in right for left in secrets for right in secrets if left != right
    ):
        raise ValueError("ambiguous disposable secrets")
    hits = 0
    for secret in secrets:
        hits += text.count(secret)
        text = text.replace(secret, REPLACEMENT)
    return text, hits


def finalize_manifest(record, secrets):
    """Return (redacted_manifest_json, failed) without any context variable.

    This intentionally models a *candidate proposal*: redact, count on actual
    serialized bytes before status decision, then serialize again. The caller
    must ensure trusted generated disposable secrets. No external writes.
    """
    if type(record) is not dict:
        raise ValueError("invalid lifecycle record")
    if record.get("cleanup_passed") is not True and record.get("cleanup_passed") is not False:
        raise ValueError("missing cleanup state")
    if type(record.get("secret_redactions", 0)) is not int or record.get("secret_redactions", 0) < 0:
        raise ValueError("invalid previous redaction count")
    snapshot = dict(record)
    raw = json.dumps(snapshot, indent=2, sort_keys=True, allow_nan=False)
    _, hits = _redact(raw, secrets)
    snapshot["secret_redactions"] = snapshot.get("secret_redactions", 0) + hits
    if snapshot["secret_redactions"]:
        snapshot["cleanup_passed"] = False
        snapshot["cleanup_status"] = "CLEANUP_UNCONFIRMED"
    if not snapshot["cleanup_passed"]:
        snapshot["result"] = "FAILED"
    final, final_hits = _redact(json.dumps(snapshot, indent=2, sort_keys=True, allow_nan=False), secrets)
    if final_hits != hits:
        # No silently introduced or removed secret occurrences after decision.
        raise ValueError("unstable redaction after finalization")
    return final, not snapshot["cleanup_passed"]


class CleanupUnconfirmed(RuntimeError):
    pass


def redact_test_secrets(value):
    """Remove exact disposable password values before publishing any text."""
    if type(value) is not str:
        raise TypeError('text expected')
    matches = 0
    for secret in _TEST_SECRETS.get():
        if secret and secret in value:
            matches += value.count(secret)
            value = value.replace(secret, '<redacted-disposable-secret>')
    if matches:
        lifecycle = _LIFECYCLE.get()
        if lifecycle is not None:
            lifecycle['secret_redactions'] = lifecycle.get('secret_redactions', 0) + matches
    return value


def write_evidence(path, text):
    text = redact_test_secrets(text)
    if path.absolute() != path.resolve():
        raise ValueError('symlink evidence output rejected')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, 'w') as stream:
        stream.write(text)


def publish_terminal_manifest(path, text):
    """Stage all bytes before atomically creating the one accepted manifest.

    Same-directory hard-link publication preserves the O_EXCL/no-overwrite
    property. An incomplete write is never published at run-manifest.json.
    This is candidate-only; host filesystem and crash durability remain outside
    the proof of synthetic tests.
    """
    staging = path.with_name('.run-manifest-' + secrets.token_hex(12) + '.tmp')
    try:
        write_evidence(staging, text)
        # Link is atomic on the local filesystem: if destination already
        # exists, do not overwrite someone else's evidence, even a symlink.
        os.link(staging, path, follow_symlinks=False)
    except BaseException:
        # Some injected fault models create the hard link then raise. In that
        # ambiguous case remove ONLY a destination known to share the exact
        # staging inode. Never unlink an unrelated/pre-existing destination.
        try:
            if (not staging.is_symlink() and staging.exists()
                    and not path.is_symlink() and path.exists()
                    and os.path.samefile(staging, path)):
                path.unlink()
        except BaseException:
            pass  # Cannot prove cleanup after a hostile host/filesystem race.
        raise
    finally:
        # An error AFTER successful publication must not make a valid PASS
        # manifest appear failed. A leftover non-accepted staging name is
        # safer than throwing here after the terminal commit point.
        try:
            if not staging.is_symlink():
                staging.unlink(missing_ok=True)
        except BaseException:
            pass



PROXIES = ('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY', 'http_proxy', 'https_proxy', 'all_proxy', 'no_proxy')


def command(args, *, timeout=30, stdin=None, check=True, build=False):
    # CLI argv only; never shell=True. Environment is needed only by the host's
    # Docker CLI. Nothing is forwarded into workers except explicit test values.
    env = clean_host_environment()
    for key in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH'):
        env.pop(key, None)
    if args[0] == 'docker':
        args = ['docker', '--host=unix:///var/run/docker.sock', *args[1:]]
    if build:
        env['DOCKER_BUILDKIT'] = '0'
    lifecycle = _LIFECYCLE.get()
    supervision = _SUPERVISOR.get()
    raw_command = args[2:] if args[:2] == ['docker','--host=unix:///var/run/docker.sock'] else []
    if supervision is not None and (raw_command[:1] in (['run'],['create'],['start'])
                                    or raw_command[:2] == ['volume','create']):
        supervision.check_live()
    attempt = None
    if lifecycle is not None:
        deadline = lifecycle.get('cleanup_deadline')
        if deadline is not None:
            timeout = min(timeout, max(.05, deadline-time.monotonic()))
            if time.monotonic() >= deadline:
                raise TimeoutError('bounded reconciliation expired')
        # Register possible daemon mutations BEFORE starting the local CLI.
        raw = args[2:] if args[:2] == ['docker', '--host=unix:///var/run/docker.sock'] else []
        kind, name = None, None
        if raw[:1] in (['run'], ['create']) and '--name' in raw:
            kind, name = 'container', raw[raw.index('--name')+1]
        elif raw[:1] in (['start'], ['restart']):
            kind, name = 'container', raw[-1]
        elif raw[:2] == ['volume', 'create']:
            kind, name = 'volume', raw[-1]
        if kind is not None:
            if not name.startswith('r7-05b3-'+lifecycle['run_hex']+'-'):
                raise ValueError('foreign creation rejected')
            attempt = dict(kind=kind, name=name, started_ns=time.time_ns(), state='PENDING')
            lifecycle['creation_attempts'].append(attempt)
    process = None
    sanitized_timeout = None
    try:
        process = subprocess.Popen(args, stdin=subprocess.PIPE if stdin is not None else subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env, start_new_session=True)
        if attempt is not None:
            attempt['local_pid'] = process.pid
        stdout, stderr = process.communicate(input=stdin, timeout=timeout)
        result = subprocess.CompletedProcess(args, process.returncode, stdout, stderr)
        if attempt is not None:
            attempt.update(state='RETURNED' if result.returncode == 0 else 'DAEMON_UNRESOLVED', returned_ns=time.time_ns(), local_reaped=True, cli_returncode=process.returncode)
    except BaseException as error:
        if attempt is not None:
            attempt.update(state='DAEMON_UNRESOLVED', interrupted_ns=time.time_ns())
        # R2-01: a *secondary* failure during bounded local CLI cleanup must
        # never escape from within the raw TimeoutExpired exception handler.
        # Such an escape implicitly chains the original credential-bearing
        # TimeoutExpired (including .cmd, .stdout and .stderr) into tracebacks.
        # Record only fixed stage codes, not raw secondary error objects/text.
        secondary_interrupt = None
        local_reap_issues = []
        local_reaped_confirmed = False
        if process is not None:
            # Own session/process group only. Reaping the CLI does NOT cancel
            # an uncertain Docker daemon request; leave that state unresolved.
            try:
                polled = process.poll()
            except BaseException as reap_error:
                local_reap_issues.append('POLL_EXCEPTION')
                if isinstance(reap_error, KeyboardInterrupt):
                    secondary_interrupt = secondary_interrupt or 'KEYBOARD_INTERRUPT'
                elif isinstance(reap_error, SystemExit):
                    secondary_interrupt = secondary_interrupt or 'SYSTEM_EXIT'
                # If poll is unreliable, avoid killing a potentially reused
                # process group. Still attempt the bounded local wait below.
                should_kill = False
            else:
                should_kill = polled is None
                if not should_kill:
                    local_reaped_confirmed = True
            if should_kill:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                except BaseException as reap_error:
                    local_reap_issues.append('KILLPG_EXCEPTION')
                    if isinstance(reap_error, KeyboardInterrupt):
                        secondary_interrupt = secondary_interrupt or 'KEYBOARD_INTERRUPT'
                    elif isinstance(reap_error, SystemExit):
                        secondary_interrupt = secondary_interrupt or 'SYSTEM_EXIT'
            try:
                process.communicate(timeout=3)
            except subprocess.TimeoutExpired:
                # Never expose a second TimeoutExpired (which may retain argv).
                local_reap_issues.append('WAIT_TIMEOUT')
            except BaseException as reap_error:
                local_reap_issues.append('WAIT_EXCEPTION')
                if isinstance(reap_error, KeyboardInterrupt):
                    secondary_interrupt = secondary_interrupt or 'KEYBOARD_INTERRUPT'
                elif isinstance(reap_error, SystemExit):
                    secondary_interrupt = secondary_interrupt or 'SYSTEM_EXIT'
            else:
                local_reaped_confirmed = True
            if attempt is not None:
                # A PID or returncode alone is not proof that a failed
                # communicate() reaped the local child process.
                attempt['local_reaped'] = local_reaped_confirmed
                if local_reap_issues:
                    attempt['local_reap_issues'] = local_reap_issues
        if isinstance(error, subprocess.TimeoutExpired):
            # Preserve the class of a secondary control-flow interrupt using a
            # *new*, public credential-free exception. No secondary error text,
            # raw TimeoutExpired, .cmd or output is retained in public chains.
            # All new exceptions are raised OUTSIDE this exception handler.
            if secondary_interrupt == 'KEYBOARD_INTERRUPT':
                sanitized_timeout = KeyboardInterrupt(
                    'disposable PostgreSQL timeout cleanup interrupted; details suppressed')
            elif secondary_interrupt == 'SYSTEM_EXIT':
                sanitized_timeout = SystemExit(
                    'disposable PostgreSQL timeout cleanup interrupted; details suppressed')
            else:
                sanitized_timeout = RuntimeError(
                    'disposable PostgreSQL command timed out; command details suppressed')
        elif isinstance(error, UnicodeError):
            # P1-A-01/P1-C-02: subprocess Unicode errors may carry raw
            # credentials in .object/.args, while secondary polling, killing
            # or bounded reaping may receive SIGINT/SystemExit. Preserve the
            # secondary termination CLASS, never its raw exception object.
            # Just as for TimeoutExpired, emit ONLY fixed safe diagnostics
            # outside the raw exception handler; daemon state remains
            # DAEMON_UNRESOLVED regardless of local reap outcomes.
            if secondary_interrupt == 'KEYBOARD_INTERRUPT':
                sanitized_timeout = KeyboardInterrupt(
                    'disposable PostgreSQL decoding cleanup interrupted; details suppressed')
            elif secondary_interrupt == 'SYSTEM_EXIT':
                sanitized_timeout = SystemExit(
                    'disposable PostgreSQL decoding cleanup interrupted; details suppressed')
            else:
                sanitized_timeout = RuntimeError(
                    'disposable PostgreSQL subprocess decoding failed; details suppressed')
        else:
            raise
    if sanitized_timeout is not None:
        raise sanitized_timeout
    if check and result.returncode:
        redact_test_secrets(result.stderr)
        raise RuntimeError('disposable PostgreSQL command failed; output withheld')
    return result


def parse_disposable_inspect_metadata(raw_stdout):
    """Parse untrusted Docker-inspect metadata without publishing raw JSON.

    A JSONDecodeError.doc/.args may contain the disposable test passwords
    embedded in Config.Env. Never let the raw parser exception become a
    primary body error or the implicit cause/context of CleanupUnconfirmed.
    Do not construct or raise the public diagnostic inside its handler.
    Traceback frame-local memory sanitization is NOT claimed here.
    """
    invalid_json = False
    try:
        parsed = json.loads(raw_stdout)
    except json.JSONDecodeError:
        invalid_json = True
    if invalid_json:
        raise RuntimeError(
            'disposable PostgreSQL inspection JSON invalid; details suppressed') from None
    # P1-E: valid JSON can still be hostile inspection metadata. Validate
    # structure BEFORE assigning to the retained lifecycle or iterating Env:
    # Config.Env as a STRING would silently become a character array;
    # a DICT entry can raise AttributeError.obj with a raw test credential.
    # One inspect target must yield exactly one object; only a list of
    # plain KEY=VALUE strings is supported (empty Env list is valid).
    valid_structure = (
        type(parsed) is list
        and len(parsed) == 1
        and type(parsed[0]) is dict
        and type(parsed[0].get('Config')) is dict)
    if valid_structure:
        env_entries = parsed[0]['Config'].get('Env')
        valid_structure = (
            type(env_entries) is list
            and all(type(item) is str
                    and '=' in item
                    and item.split('=', 1)[0] != ''
                    for item in env_entries))
    # P1-F confidentiality boundary: a schema-compliant Env list is still
    # untrusted. Multiple harmless-looking KEY=VALUE values (or even key
    # names) can reconstruct a generated disposable credential without any
    # contiguous secret for exact redaction to detect. NEVER publish raw Env
    # names, raw values, or any other fields from Docker inspect.
    #
    # Diagnostic projection policy, fixed by reviewed source:
    # - Only explicitly named password keys may appear, always masked.
    # - Small, explicitly approved non-secret literal values may appear.
    # - If an approved nonsecret key has any OTHER value, mask it.
    # - Unknown keys are omitted entirely (including their NAMES).
    # - Duplicate/invalid keys fail closed before publication.
    projected_env = []
    if valid_structure:
        masked_names = frozenset((
            'POSTGRES_PASSWORD', 'PGPASSWORD', 'R7_PG_ADMIN_PASSWORD',
            'R7_PG_MIGRATOR_PASSWORD', 'R7_PG_WRITER_PASSWORD',
            'R7_PG_READER_PASSWORD',
        ))
        approved_literals = {
            'SAFE_FEATURE_FLAG': 'enabled',
            'HTTP_PROXY': '',
            'NAME': 'a=b',
        }
        seen_names = set()
        for item in env_entries:
            name, value = item.split('=', 1)
            # Restrict diagnostic metadata names to a small ASCII variable
            # grammar. Control characters, NUL and secret-bearing pseudo-
            # variable keys are never retained in successful evidence.
            valid_name = (
                name.isascii()
                and (name[0].isalpha() or name[0] == '_')
                and all(char.isalnum() or char == '_' for char in name)
            )
            if not valid_name or name in seen_names:
                valid_structure = False
                break
            seen_names.add(name)
            if name in masked_names:
                projected_env.append(name + '=<test-secret>')
            elif name in approved_literals:
                if value == approved_literals[name]:
                    projected_env.append(name + '=' + approved_literals[name])
                else:
                    projected_env.append(name + '=<redacted-env-value>')
            # Everything else is dropped, including arbitrary extra metadata
            # and UNKNOWN_ENV values. No access to raw Env after this point.
    if not valid_structure:
        # A constant error outside the JSON parser handler has no unsafe
        # .doc, .obj, original args or exception-context publication.
        raise RuntimeError(
            'disposable PostgreSQL inspection metadata schema invalid; details suppressed') from None
    return {'Config': {'Env': projected_env}}



def _private_json(raw, message):
    invalid = False
    try:
        value = json.loads(raw)
    except (ValueError, TypeError, UnicodeError):
        invalid = True
    if invalid:
        raise RuntimeError(message) from None
    return value


def publish_stage_diagnostic(evidence, stage, result):
    """Never publish producer text, lengths, exception reprs or arbitrary names."""
    if stage not in ('foundation', 'restart', 'b5-4-1'):
        raise ValueError('fixed stage required')
    if type(result.returncode) is not int or not -255 <= result.returncode <= 255:
        raise RuntimeError('invalid stage exit status')
    try:
        # Exact-secret observations still reject the final run. Split/encoded
        # strings are withheld, not decoded or copied into terminal evidence.
        redact_test_secrets(result.stdout)
        redact_test_secrets(result.stderr)
        for suffix in ('stdout', 'stderr'):
            write_evidence(evidence / (stage + '.' + suffix), 'OUTPUT_WITHHELD\n')
    except BaseException:
        lifecycle = _LIFECYCLE.get()
        if lifecycle is not None:
            lifecycle['result'] = 'FAILED'
            lifecycle['evidence_status'] = 'EVIDENCE_UNAVAILABLE'
        raise


def _inventory_summary(raw, allowed):
    # Publish only names already generated by trusted run ownership code.
    if type(raw) is not str:
        return 'UNAVAILABLE'
    names = raw.strip().splitlines()
    if any(name not in allowed for name in names):
        return 'UNAVAILABLE'
    return '\n'.join(names)


def inspect_image(identity):
    parsed = _private_json(command(['docker', 'image', 'inspect', identity]).stdout,
                           'image inspection JSON invalid; details suppressed')
    valid = (type(parsed) is list and len(parsed) == 1 and type(parsed[0]) is dict)
    value = parsed[0] if valid else {}
    if (not valid or type(identity) is not str
            or re.fullmatch(r'sha256:[0-9a-f]{64}', identity) is None
            or value.get('Id') != identity or value.get('Os') != 'linux'
            or value.get('Architecture') != 'amd64'):
        raise ValueError('exact test image unavailable')
    return value


def remove_owned(kind, name, run_id):
    """Never remove a pre-existing/foreign resource after a failed creation."""
    args = ['docker', kind, 'inspect', name]
    info = command(args, check=False)
    if info.returncode:
        return 'no such '+kind in info.stderr.lower()
    parsed = _private_json(info.stdout, 'ownership inspection JSON invalid; details suppressed')
    if type(parsed) is not list or len(parsed) != 1 or type(parsed[0]) is not dict:
        return False
    value = parsed[0]
    config = value.get('Config')
    if kind == 'container' and type(config) is not dict:
        return False
    labels = config.get('Labels') if kind == 'container' else value.get('Labels')
    if type(labels) is not dict or labels.get('r7_05b3_run') != str(run_id):
        return False
    delete = ['docker', 'rm', '-f', name] if kind == 'container' else ['docker', 'volume', 'rm', name]
    return command(delete, check=False).returncode == 0


def build_client(wheelhouse, work):
    inspect_image(BASE)
    wheel = wheelhouse/WHEEL
    if wheel.is_symlink() or hashlib.sha256(wheel.read_bytes()).hexdigest() != WHEEL_SHA256:
        raise ValueError('verified exact driver wheel required')
    context = work/'build'
    (context/'wheels').mkdir(parents=True)
    shutil.copyfile(wheel, context/'wheels'/WHEEL)
    for name in ('Dockerfile', 'requirements.lock'):
        shutil.copyfile(ROOT/'tests/postgres'/name, context/name)
    iid = work/'client-image-id'
    command(['docker', 'build', '--network=none', '--pull=false', '--iidfile', str(iid), str(context)], timeout=180, build=True)
    identity = iid.read_text().strip()
    inspect_image(identity)
    return identity


def remove_transient_credential_file(path):
    """Historical API, now absence-only: never create/delete a credential file.

    A legacy file, symlink or uncertain filesystem result is a security fault.
    This preserves the original fault-injection regression without treating
    unlink as credential retirement or providing a disk fallback.
    """
    try:
        path.lstat()  # any file type, including a dangling symlink, is forbidden
    except FileNotFoundError:
        return 'NOT_PRESENT'
    except Exception:
        return 'UNCONFIRMED'
    return 'UNCONFIRMED'


def normalize_transient_credential_cleanup_status(status):
    """Trust only literal built-in str statuses; never call custom __eq__.

    Comparing an arbitrary return value to a string can execute attacker-defined
    equality code or accept a forged REMOVED/NOT_PRESENT signal. Keep output
    JSON-safe, deterministic, and fail-closed for every non-exact input.
    """
    if type(status) is str and status == 'NOT_PRESENT':
        return status
    return 'UNCONFIRMED'


def _fixed_status(value, expected):
    """Never invoke equality on a foreign cleanup return object."""
    return expected if type(value) is str and value == expected else 'UNCONFIRMED'


def verified_clean_source():
    """Fail closed on untrusted/dirty Git provenance before Docker mutations.

    A Windows .git pointer that WSL Git cannot read is rejected. This check
    establishes a clean source snapshot, not a trust boundary against a
    malicious host or Docker daemon.
    """
    top = command(['git', '-C', str(ROOT), 'rev-parse', '--show-toplevel']).stdout.strip()
    # This repository keeps the Python project in sales-forecast-platform/.
    # Validate the entire containing Git worktree, not only the subdirectory.
    try:
        root_matches = (bool(top)
                        and Path(top).resolve(strict=True) == ROOT.parent.resolve(strict=True)
                        and ROOT.name == 'sales-forecast-platform')
    except (OSError, RuntimeError):
        root_matches = False
    if not root_matches:
        raise ValueError('disposable test source must be expected Git worktree')
    commit = command(['git', '-C', str(ROOT), 'rev-parse', '--verify', 'HEAD']).stdout.strip()
    if len(commit) not in (40, 64) or any(ch not in '0123456789abcdef' for ch in commit):
        raise ValueError('invalid source commit identity')
    status = command(['git', '-C', str(ROOT), 'status', '--porcelain',
                      '--untracked-files=all']).stdout
    if status:
        raise ValueError('disposable test source checkout must be clean')
    return commit


def run(*, allow, wheelhouse, evidence, _host_stage=None):
    if allow is not True:
        raise ValueError('explicit disposable-database authorization required')
    if evidence.absolute() != evidence.resolve():
        raise ValueError('symlink evidence directory rejected')
    # Validate provenance BEFORE creating evidence or touching Docker.
    source_commit = verified_clean_source()
    evidence.mkdir(mode=0o700, parents=False, exist_ok=False)
    run_id = uuid4()
    prefix = 'r7-05b3-'+run_id.hex
    database = 'r7_05b3_'+run_id.hex
    data, socket, server = prefix+'-data', prefix+'-socket', prefix+'-server'
    containers = []
    volumes = []
    envfile = evidence/'test-client.env'  # prohibited legacy-path absence witness only
    transport = None
    supervisor = None
    record = {'version': '2.0', 'run_id': str(run_id), 'database': database,
              'source_commit': source_commit,
              'source_status': '', 'result': 'FAILED',
              'cleanup_passed': False, 'cleanup_status': 'CLEANUP_UNCONFIRMED',
              'operations': [], 'native_execution': False, 'production_connections': False}
    record.update(run_hex=run_id.hex, creation_attempts=[],
                  credential_transport='STDIN_PIPE_V1', transport_retirement='UNCONFIRMED',
                  supervisor_cleanup='UNCONFIRMED', server_activations=0,
                  credential_file_cleanup='UNCONFIRMED')
    token = _LIFECYCLE.set(record)
    supervisor_token = _SUPERVISOR.set(None)
    inspection_token = None  # suspend resource-ownership context during read-only listings
    credential_cleanup_attempted = False
    # Cooperative SIGTERM deferral during the legacy-path absence check.
    # This protects the check bookkeeping seam; a hard kill, another
    # process, or arbitrary KeyboardInterrupt cannot be made atomic by Python.
    deferred_term = {'active': False, 'pending': False}
    secret_token = None
    handler_attempted = False
    handler_restore_attempted = False
    handler_restore_failed = False
    previous_term = None
    # Body completion is local bookkeeping, never terminal PASS evidence.
    body_passed = False

    def restore_handler_once():
        """Attempt SIGTERM restoration once; never silently approve failure."""
        nonlocal handler_restore_attempted, handler_restore_failed
        if handler_attempted and previous_term is not None and not handler_restore_attempted:
            # Mark BEFORE invoking signal.signal: a restoration fault must not
            # produce an unbounded retry or an accepted success manifest.
            handler_restore_attempted = True
            try:
                signal.signal(signal.SIGTERM, previous_term)
            except BaseException:
                handler_restore_failed = True
                record['handler_restoration'] = 'UNCONFIRMED'
                record['result'] = 'FAILED'
                record['cleanup_passed'] = False
                record['cleanup_status'] = 'CLEANUP_UNCONFIRMED'
            else:
                record['handler_restoration'] = 'RESTORED'

    try:
        previous_term = signal.getsignal(signal.SIGTERM)
        # R2-02: CPython may return None for a previous native/non-Python
        # handler. signal.signal cannot restore that original state. Never
        # install our own callback when restoration cannot be represented.
        # A rejected early setup is not evidence of successful cleanup.
        if previous_term is None:
            record['handler_restoration'] = 'UNCONFIRMED'
            record['result'] = 'FAILED'
            record['cleanup_passed'] = False
            record['cleanup_status'] = 'CLEANUP_UNCONFIRMED'
            record['evidence_status'] = 'EVIDENCE_UNAVAILABLE'
            raise CleanupUnconfirmed(
                'CLEANUP_UNCONFIRMED: SIGTERM prior handler unrepresentable') from None
        handler_attempted = False
        def interrupted(signum, frame):
            if deferred_term['active']:
                deferred_term['pending'] = True
                return
            raise KeyboardInterrupt('test runner interrupted')
        handler_attempted = True
        signal.signal(signal.SIGTERM, interrupted)
        passwords = {role: 'test-only-'+secrets.token_hex(20) for role in ('admin', 'migrator', 'writer', 'reader')}
        secret_token = _TEST_SECRETS.set(tuple(passwords.values()))
        empty_proxies = [item for key in PROXIES for item in ('-e', key+'=')]
        isolation = ['--log-driver=none', '--ulimit', 'core=0:0', '--network=none', '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges', '--cpus=1', '--pids-limit=64']

        def ready():
            end = time.monotonic()+45
            while time.monotonic() < end:
                final = command(['docker', 'exec', server, 'cat', '/proc/1/comm'], check=False)
                if final.stdout.strip() == 'postgres':
                    result = transport.psql(command, server,
                        ['-h', '/var/run/postgresql', '-U', 'r7_test_owner', '-d', database, '-At', '-c',
                         'SELECT current_database(),current_user,version(),system_identifier FROM pg_control_system()'])
                    if result.returncode == 0:
                        redact_test_secrets(result.stdout)
                        return result.stdout.strip()
                time.sleep(.2)
            raise TimeoutError('final disposable PostgreSQL server not ready')

        try:
            inspect_image(POSTGRES)
            client = build_client(wheelhouse.resolve(strict=True), evidence)
            record.update(postgres_image=POSTGRES, client_image=client, base_image=BASE, driver_wheel_sha256=WHEEL_SHA256)
            supervisor = CleanupSupervisor(run_id, evidence)
            supervisor.start()
            _SUPERVISOR.set(supervisor)
            transport = CredentialSession(run_id, database, evidence, passwords, record, supervisor)
            for name, options in ((data, []), (socket, ['--driver=local', '--opt=type=tmpfs', '--opt=device=tmpfs', '--opt=o=size=16m,mode=1777'])):
                absent = command(['docker', 'volume', 'inspect', name], check=False)
                if absent.returncode == 0 or 'no such volume' not in absent.stderr.lower():
                    raise ValueError('fresh disposable volume required')
                command(['docker', 'volume', 'create', '--label', 'r7_05b3_run='+str(run_id), *options, name])
                volumes.append(name)
            provision = prefix+'-provision'
            containers.append(provision)
            command(['docker', 'run', '--name', provision, '--label', 'r7_05b3_run='+str(run_id), '--network=none', '--read-only', '--user=0:0',
                '--cap-drop=ALL', '--cap-add=CHOWN', '--security-opt=no-new-privileges', '--cpus=1',
                '--memory=64m', '--memory-swap=64m', '--pids-limit=32', *empty_proxies,
                '--mount', 'type=volume,src='+data+',dst=/var/lib/postgresql/data', '--entrypoint', 'chown', POSTGRES, '999:999', '/var/lib/postgresql/data'])
            command(['docker', 'rm', provision])
            containers.remove(provision)
            containers.append(server)
            server_args = ['docker', 'create', '-i', '--name', server, '--label', 'r7_05b3_run='+str(run_id), *isolation,
                '--user=999:999', '--memory=512m', '--memory-swap=512m', '--tmpfs=/tmp:rw,noexec,nosuid,size=32m',
                '--mount', 'type=volume,src='+data+',dst=/var/lib/postgresql/data',
                '--mount', 'type=volume,src='+socket+',dst=/var/run/postgresql', *empty_proxies,
                '-e', 'PGDATA=/var/lib/postgresql/data/pgdata', '-e', 'POSTGRES_DB='+database,
                '-e', 'POSTGRES_USER=r7_test_owner', '-e', 'POSTGRES_PASSWORD_FILE=/dev/stdin',
                '-e', 'POSTGRES_INITDB_ARGS=--auth-local=scram-sha-256 --auth-host=scram-sha-256', POSTGRES,
                '-c', 'listen_addresses=', '-c', 'shared_buffers=32MB', '-c', 'max_connections=20',
                '-c', 'logging_collector=off', '-c', 'log_destination=stderr',
                '-c', 'log_statement=none', '-c', 'log_min_error_statement=panic',
                '-c', 'fsync=on', '-c', 'synchronous_commit=on', '-c', 'full_page_writes=on']
            command(server_args)
            transport.activate(server, inspect=command)
            private_cluster_before_restart = ready()
            record['cluster_before_restart'] = 'PRIVATE_READINESS_OBSERVED'
            verifiers = {role: scram_verifier(passwords[role], secrets.token_bytes(16))
                         for role in ('migrator', 'writer', 'reader')}
            # Verifiers are sensitive too; redact them before public evidence.
            _TEST_SECRETS.set(tuple(passwords.values()) + tuple(verifiers.values()))
            bootstrap = (ROOT/'tests/postgres/bootstrap.sql').read_text()
            for role, verifier in verifiers.items():
                marker = ":'"+role+"_verifier'"
                if bootstrap.count(marker) != 1:
                    raise ValueError('bootstrap verifier source drift')
                bootstrap = bootstrap.replace(marker, "'"+validate_verifier(verifier)+"'")
            result = transport.psql(command, server,
                ['-h', '/var/run/postgresql', '-U', 'r7_test_owner', '-d', database,
                 '-v', 'ON_ERROR_STOP=1', '-v', 'test_database='+database,
                 '-v', 'test_identity=r7_05b3_disposable:'+str(run_id)], bootstrap)
            if result.returncode:
                raise RuntimeError('disposable bootstrap authentication failed')
            redact_test_secrets(result.stdout)
            redact_test_secrets(result.stderr)
            # P1-F: record ONLY the approved fixed diagnostic projection;
            # no raw inspect Env values, keys or other source fields retained.
            record['server_inspect'] = parse_disposable_inspect_metadata(command(['docker', 'inspect', server]).stdout)
            for stage, module in (('foundation', 'tests/postgres/test_forecast_evidence_postgres.py'),
                                  ('restart', 'tests/postgres/test_forecast_evidence_restart.py')):
                if stage == 'restart':
                    command(['docker', 'stop', '--time=5', server], timeout=20)
                    transport.reap_activation(require_success=True)
                    transport.activate(server, inspect=command)
                    private_cluster_after_restart = ready()
                    record['cluster_after_restart'] = 'PRIVATE_READINESS_OBSERVED'
                    if private_cluster_before_restart != private_cluster_after_restart:
                        raise ValueError('disposable cluster changed on restart')
                name = prefix+'-'+stage
                containers.append(name)
                args = ['docker', 'run', '-i', '--name', name, '--label', 'r7_05b3_run='+str(run_id), *isolation,
                    '--user=1000:1000', '--memory=1g', '--memory-swap=1g', '--ulimit', 'cpu=180:180',
                    '--tmpfs=/tmp:rw,noexec,nosuid,size=256m', '--mount', 'type=volume,src='+socket+',dst=/run/r7pg,readonly',
                    '--mount', 'type=bind,src='+str(ROOT/'src')+',dst=/code/src,readonly',
                    '--mount', 'type=bind,src='+str(ROOT/'tests')+',dst=/code/tests,readonly',
                    '--workdir=/code', *empty_proxies,
                    '-e', 'PYTHONDONTWRITEBYTECODE=1', '-e', 'PYTHONPATH=/code', '-e', 'OMP_NUM_THREADS=1',
                    '-e', 'OPENBLAS_NUM_THREADS=1', '-e', 'HOME=/tmp', '-e', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD=1',
                    '--entrypoint', 'python', client,
                    '/code/tests/postgres/credential_test_client.py', stage]
                result = command(args, timeout=240, check=False, stdin=transport.client_frame(stage))
                try:
                    publish_stage_diagnostic(evidence, stage, result)
                except BaseException:
                    # Even if resources later clean up, stage evidence is
                    # incomplete. Preserve the original I/O exception.
                    record['evidence_status'] = 'EVIDENCE_UNAVAILABLE'
                    record['result'] = 'FAILED'
                    raise
                # The parser already projects only approved constant
                # diagnostics; never reintroduce raw Docker metadata.
                info = parse_disposable_inspect_metadata(command(['docker', 'inspect', name]).stdout)
                record['operations'].append({'stage': stage, 'exit_code': result.returncode, 'inspect': info})
                if result.returncode:
                    raise RuntimeError('bounded PostgreSQL '+stage+' tests failed')
                command(['docker', 'rm', name])
                containers.remove(name)
            if _host_stage is not None:
                _host_stage(server=server, socket=socket, client=client, envfile=envfile, transport=transport,
                    run_id=run_id, database=database, record=record)
            body_passed = True
        except BaseException as error:
            record['result'] = 'FAILED'
            record['error_type'] = type(error).__name__
            raise
        finally:
            # F04-M2: a successful body is NOT terminal success. Keep the
            # lifecycle fail-closed during all resource reconciliation, owned
            # credential unlink, and prior SIGTERM handler restoration. In
            # particular, BaseException/KeyboardInterrupt escaping cleanup
            # cannot leave a retained in-memory PASS record.
            record['result'] = 'FAILED'
            record['cleanup_passed'] = False
            record['cleanup_status'] = 'CLEANUP_UNCONFIRMED'
            # Keep named volumes until the bounded container reconciliation finishes.
            # A timed-out create can still attach them after the local CLI is gone.
            if transport is not None:
                try:
                    command(['docker', 'stop', '--time=5', server], timeout=20)
                    transport.reap_activation(require_success=True)
                except BaseException:
                    record['transport_retirement'] = 'UNCONFIRMED'
            attempts = record['creation_attempts']
            owned_containers = list(dict.fromkeys(containers + record.get('extra_containers', [])
                + [x['name'] for x in attempts if x['kind']=='container']))
            owned_volumes = list(dict.fromkeys(volumes+[x['name'] for x in attempts if x['kind']=='volume']))
            ambiguous = any(x['state'] != 'RETURNED' for x in attempts)
            record['cleanup_deadline'] = time.monotonic()+10
            cleanup = []
            try:
                while True:
                    round_ok = True
                    for name in reversed(owned_containers):
                        try:
                            round_ok = remove_owned('container', name, run_id) and round_ok
                        except Exception:
                            round_ok = False
                    if not ambiguous or time.monotonic() >= record['cleanup_deadline']-.3:
                        cleanup.append(round_ok)
                        break
                    time.sleep(.25)
                record['cleanup_deadline'] = time.monotonic()+6
                for name in reversed(owned_volumes):
                    try:
                        cleanup.append(remove_owned('volume', name, run_id))
                    except Exception:
                        cleanup.append(False)
            finally:
                record.pop('cleanup_deadline', None)
            if transport is not None:
                try:
                    transport.reap_activation(require_success=True)
                finally:
                    record['transport_retirement'] = _fixed_status(transport.retire(), 'RETIRED')
                    record['server_activations'] = transport.activations
            if supervisor is not None:
                record['supervisor_cleanup'] = _fixed_status(supervisor.finish(
                    settled=(not ambiguous and bool(cleanup) and all(cleanup)
                             and record['transport_retirement'] == 'RETIRED')), 'CONFIRMED')
            # Match accepted runner: no active lifecycle context while issuing
            # final read-only inventory queries and publishing evidence.
            # Keep the original binding token for outer finally restoration.
            inspection_token = _LIFECYCLE.set(None)
            for key, query in (('remaining_containers', ['ps','-aq','--filter','label=r7_05b3_run='+str(run_id)]),
                               ('remaining_volumes', ['volume','ls','-q','--filter','label=r7_05b3_run='+str(run_id)])):
                try:
                    allowed_names = owned_containers if key == 'remaining_containers' else owned_volumes
                    record[key] = _inventory_summary(
                        command(['docker', *query], timeout=2).stdout, allowed_names)
                except Exception:
                    record[key] = 'UNAVAILABLE'
            record['possible_owned_containers'] = owned_containers
            record['possible_owned_volumes'] = owned_volumes
            # No finite polling period proves an interrupted daemon request cannot
            # finish later. Absence is insufficient while any creation is unresolved.
            record['cleanup_passed'] = (bool(cleanup) and all(cleanup) and not ambiguous
                and not record['remaining_containers'] and not record['remaining_volumes']
                and (transport is None or record['transport_retirement'] == 'RETIRED')
                and (supervisor is None or record['supervisor_cleanup'] == 'CONFIRMED'))
            record['cleanup_status'] = 'CLEANUP_SUCCESS' if record['cleanup_passed'] else 'CLEANUP_UNCONFIRMED'
            # No credential file is created. Keep the historical absence-check API
            # as an independent prohibited-path guard, never as retirement.
            # Defer cooperative SIGTERM around its single bounded check.
            deferred_term['active'] = True
            try:
                credential_cleanup_attempted = True  # no unsafe duplicate unlink
                try:
                    removal_status = remove_transient_credential_file(envfile)
                except BaseException:
                    record['credential_file_cleanup'] = 'UNCONFIRMED'
                    record['result'] = 'FAILED'
                    record['cleanup_passed'] = False
                    record['cleanup_status'] = 'CLEANUP_UNCONFIRMED'
                    raise
                record['credential_file_cleanup'] = (
                    normalize_transient_credential_cleanup_status(removal_status))
                if record['credential_file_cleanup'] == 'UNCONFIRMED':
                    record['result'] = 'FAILED'
                    record['cleanup_passed'] = False
                    record['cleanup_status'] = 'CLEANUP_UNCONFIRMED'
            finally:
                if deferred_term['pending']:
                    # Interrupted finalization cannot retain a PASS result,
                    # regardless of whether the owned envfile was removed.
                    record['result'] = 'FAILED'
                    record['cleanup_passed'] = False
                    record['cleanup_status'] = 'CLEANUP_UNCONFIRMED'
                deferred_term['active'] = False
            if deferred_term['pending']:
                deferred_term['pending'] = False
                raise KeyboardInterrupt('deferred SIGTERM during credential cleanup')
            # No success evidence can be published until the previous SIGTERM
            # handler has been restored. A restoration fault fails closed.
            # Preserve a pending original exception rather than masking it
            # when *both* body and restoration fail.
            pending_error = sys.exc_info()[1]
            restore_handler_once()
            if handler_restore_failed and pending_error is None:
                raise CleanupUnconfirmed(
                    'CLEANUP_UNCONFIRMED: SIGTERM handler restoration not confirmed') from None
            # Promote to PASS only after every terminal success prerequisite.
            # No exception raised during reconciliation reaches this point.
            if (body_passed and record['cleanup_passed']
                    and type(record.get('credential_file_cleanup')) is str
                    and record['credential_file_cleanup'] == 'NOT_PRESENT'
                    and not handler_restore_failed):
                record['result'] = 'PASS'
            # Detect and redact secrets even in unexpected metadata keys.
            # EVIDENCE_UNAVAILABLE is distinct from owned-resource cleanup
            # status: cleanup can succeed even when publication cannot.
            if record.get('evidence_status') != 'EVIDENCE_UNAVAILABLE':
                record['evidence_status'] = 'AVAILABLE'
            publication_failed = False
            publisher_interrupt = None
            try:
                manifest_text, rejected = finalize_manifest(
                    record, tuple(_TEST_SECRETS.get()))
                # R2-03: the pure finalizer owns the definitive *redacted*
                # terminal classification. Apply its exact serialized state
                # to the SAME retained record reference captured by host-stage
                # observers before attempting publication. Updating individual
                # fields is insufficient: a secret can occur in a nested
                # value OR dict key, and partial updates retain raw metadata.
                finalized_record = json.loads(manifest_text)
                record.clear()
                record.update(finalized_record)
                publish_terminal_manifest(
                    evidence/'run-manifest.json', manifest_text)
            except BaseException as publisher_error:
                # P1-C-01: publisher/serializer errors are external-data
                # surfaces. Their .args/.object/filename/attributes may retain
                # disposable credentials. Do NOT retain this error object or
                # raise anything inside its active exception handler. Bare
                # 'from None' there does NOT clear the public __context__.
                publication_failed = True
                if isinstance(publisher_error, KeyboardInterrupt):
                    publisher_interrupt = 'KEYBOARD_INTERRUPT'
                elif isinstance(publisher_error, SystemExit):
                    publisher_interrupt = 'SYSTEM_EXIT'
                record['result'] = 'FAILED'
                record['evidence_status'] = 'EVIDENCE_UNAVAILABLE'
            if publication_failed:
                # After the publisher exception handler has fully exited,
                # choose a fixed diagnostic outcome. Uncertain owned cleanup
                # outranks the test error and the evidence publication error.
                owned_uncertain = (
                    record.get('cleanup_passed') is not True
                    and record.get('cleanup_status') == 'CLEANUP_UNCONFIRMED'
                    and bool(record.get('possible_owned_containers')
                        or record.get('possible_owned_volumes')
                        or record.get('credential_file_cleanup') == 'UNCONFIRMED'))
                if owned_uncertain:
                    raise CleanupUnconfirmed(
                        'CLEANUP_UNCONFIRMED: owned resource cleanup and manifest publication not confirmed') from None
                if pending_error is not None:
                    # With independently confirmed cleanup, a known-safe
                    # primary test error keeps identity and traceback. It
                    # cannot inherit the now-exited unsafe publisher error.
                    raise pending_error.with_traceback(
                        pending_error.__traceback__) from None
                if publisher_interrupt == 'KEYBOARD_INTERRUPT':
                    raise KeyboardInterrupt(
                        'terminal manifest publication interrupted; details suppressed') from None
                if publisher_interrupt == 'SYSTEM_EXIT':
                    raise SystemExit(
                        'terminal manifest publication interrupted; details suppressed') from None
                raise OSError(
                    'terminal manifest publication failed; details suppressed') from None
            if rejected and not (handler_restore_failed and pending_error is not None):
                raise CleanupUnconfirmed('CLEANUP_UNCONFIRMED: owned resource or credential cleanup not confirmed') from None
    finally:
        try:
            if record.get('credential_file_cleanup') != 'NOT_PRESENT':
                record['result'] = 'FAILED'
                record['cleanup_passed'] = False
                record['cleanup_status'] = 'CLEANUP_UNCONFIRMED'
            if transport is not None and not transport.retired:
                record['transport_retirement'] = _fixed_status(transport.retire(), 'RETIRED')
            if supervisor is not None and not supervisor.confirmed:
                supervisor.abandon()
            # A reconciliation interruption must never skip a bounded attempt
            # to remove only the owned transient credential file. This path
            # is reached after an exceptional exit before normal cleanup.
            if not credential_cleanup_attempted:
                deferred_term['active'] = True
                try:
                    credential_cleanup_attempted = True
                    try:
                        removal_status = remove_transient_credential_file(envfile)
                    except BaseException:
                        removal_status = 'UNCONFIRMED'
                    record['credential_file_cleanup'] = (
                        normalize_transient_credential_cleanup_status(removal_status))
                    if record['credential_file_cleanup'] == 'UNCONFIRMED':
                        record['result'] = 'FAILED'
                        record['cleanup_passed'] = False
                        record['cleanup_status'] = 'CLEANUP_UNCONFIRMED'
                finally:
                    if deferred_term['pending']:
                        record['result'] = 'FAILED'
                        record['cleanup_passed'] = False
                        record['cleanup_status'] = 'CLEANUP_UNCONFIRMED'
                    deferred_term['active'] = False
                if deferred_term['pending']:
                    deferred_term['pending'] = False
                    raise KeyboardInterrupt('deferred SIGTERM during credential cleanup')
        finally:
            pending_exit_error = sys.exc_info()[1]
            try:
                restore_handler_once()
                if handler_restore_failed and pending_exit_error is None:
                    raise CleanupUnconfirmed(
                        'CLEANUP_UNCONFIRMED: SIGTERM handler restoration not confirmed') from None
            finally:
                try:
                    if secret_token is not None:
                        passwords.clear()
                        _TEST_SECRETS.reset(secret_token)
                finally:
                    try:
                        if inspection_token is not None:
                            _LIFECYCLE.reset(inspection_token)
                    finally:
                        try:
                            _SUPERVISOR.reset(supervisor_token)
                        finally:
                            _LIFECYCLE.reset(token)



if __name__ == '__main__':
    raise SystemExit('F04_NARROW_SCOPE_EXCLUDED: base CLI; use approved B5-4-1 controller')
