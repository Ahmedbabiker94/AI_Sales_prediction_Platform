"""Fixed B5-4-1 reporting stage; shared corrected runtime, minimized output."""
from pathlib import Path
from run_postgres import (
    ROOT, PROXIES, POSTGRES, BASE, command, write_evidence,
    redact_test_secrets, publish_stage_diagnostic,
)

TESTS = (
    'tests/postgres/test_stored_forecast_accuracy_postgres.py',
    'tests/postgres/test_canonical_reporting_read.py',
    'tests/postgres/test_r7_05b5_4_1_host_reporting_requests.py',
)


def reporting_stage(*, server, socket, client, envfile, transport, run_id, database, record):
    # The foundation stage already performed the checked migration; restart
    # stage verified a NEW client with the same durable, isolated cluster.
    prefix = 'r7-05b3-' + run_id.hex
    name = prefix + '-b5-4-1'
    isolation = [
        '--log-driver=none', '--ulimit', 'core=0:0', '--network=none', '--read-only', '--cap-drop=ALL',
        '--security-opt=no-new-privileges', '--cpus=1', '--pids-limit=64',
    ]
    empty_proxies = [
        item for key in PROXIES for item in ('-e', key + '=')
    ]
    # run_postgres.run owns the lifecycle and must also own this extra
    # container; its callback can append a run-scoped container identity.
    # Ensure an independent cleanup attempt even on failed/aborted pytest.
    args = [
        'docker', 'run', '-i', '--name', name,
        '--label', 'r7_05b3_run=' + str(run_id), *isolation,
        '--user=1000:1000', '--memory=1g', '--memory-swap=1g',
        '--ulimit', 'cpu=180:180',
        '--tmpfs=/tmp:rw,noexec,nosuid,size=256m',
        '--mount', 'type=volume,src=' + socket + ',dst=/run/r7pg,readonly',
        '--mount', 'type=bind,src=' + str(ROOT/'src') + ',dst=/code/src,readonly',
        '--mount', 'type=bind,src=' + str(ROOT/'tests') + ',dst=/code/tests,readonly',
        '--workdir=/code', *empty_proxies,
        '-e', 'PYTHONDONTWRITEBYTECODE=1', '-e', 'PYTHONPATH=/code',
        '-e', 'OMP_NUM_THREADS=1', '-e', 'OPENBLAS_NUM_THREADS=1',
        '-e', 'HOME=/tmp', '-e', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD=1',
        '--entrypoint', 'python', client,
        '/code/tests/postgres/credential_test_client.py', 'b5-4-1',
    ]
    from run_postgres import _LIFECYCLE
    lifecycle = _LIFECYCLE.get()
    if lifecycle is None or lifecycle.get('run_hex') != run_id.hex:
        raise RuntimeError('original disposable run lifecycle required')
    # Add before Docker invocation so the original harness cleanup owns the
    # name even if Docker's run request is interrupted or ambiguous.
    # Lifecycle's retry reconciliation will verify run labels.
    created = lifecycle.setdefault('extra_containers', [])
    created.append(name)
    result = command(args, timeout=240, check=False,
                     stdin=transport.client_frame('b5-4-1'))
    evidence_dir = Path(record['b5_4_1_evidence_dir'])
    try:
        publish_stage_diagnostic(evidence_dir, 'b5-4-1', result)
    except BaseException:
        # F04-R4-LOW: a partial B5 output is not complete evidence, even if
        # owned resources later reconcile. Mirror foundation/restart status.
        # Bare raise preserves the original I/O or interruption exception.
        record['evidence_status'] = 'EVIDENCE_UNAVAILABLE'
        record['result'] = 'FAILED'
        raise
    record['operations'].append({
        'stage': 'b5-4-1', 'exit_code': result.returncode,
        'tests': list(TESTS),
    })
    if result.returncode:
        raise RuntimeError('isolated B5-4-1 PostgreSQL tests failed')


