"""Opt-in narrow B5-4-1 CLI; success requires immutable same-run admission."""
import argparse
from pathlib import Path
import run_manifest_admission_controller as controller


def _arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--allow-disposable-postgres', action='store_true')
    parser.add_argument('--wheelhouse', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    if not args.allow_disposable_postgres:
        parser.error('explicit disposable PostgreSQL permission required')
    return args


def main(args=None):
    args = _arguments() if args is None else args
    receipt = controller.invoke_b5_4_1_and_admit(
        allow=True, wheelhouse=args.wheelhouse, evidence=args.evidence)
    if type(receipt) is not controller.VerifiedB541Manifest:
        raise SystemExit('B5-4-1 admission denied: verified receipt required')
    # Consume the pinned bytes only; never re-open the manifest pathname.
    return receipt.manifest_bytes


if __name__ == '__main__':
    # Fixed diagnostics avoid publishing raw exceptions from CLI inputs,
    # filesystem/daemon faults, traceback locals or producer output.
    args = _arguments()
    failed = None
    try:
        main(args)
    except BaseException as error:
        failed = 'INTERRUPTED' if isinstance(error, KeyboardInterrupt) else 'FAILED'
    if failed == 'INTERRUPTED':
        raise KeyboardInterrupt('B5-4-1 interrupted; evidence not admitted') from None
    if failed is not None:
        raise SystemExit('B5-4-1 failed or interrupted; evidence not admitted')
