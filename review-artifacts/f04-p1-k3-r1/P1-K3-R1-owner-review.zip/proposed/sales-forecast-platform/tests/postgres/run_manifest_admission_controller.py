"""Synchronous B5-4-1-only admission. No durable/archive authority."""
from dataclasses import dataclass
import hashlib
import json
import os
import re
from pathlib import Path
import stat
from uuid import UUID

import run_postgres as runtime
from credential_transport import CredentialSession
from run_b5_4_1_reporting_stage import reporting_stage, TESTS as REPORTING_TESTS


_MAX_MANIFEST_BYTES = 1_048_576


@dataclass(frozen=True)
class VerifiedB541Manifest:
    """Immutable in-process evidence snapshot, not an archive receipt."""
    run_id: str
    sha256: str
    manifest_bytes: bytes
    source_commit: str


def _read_manifest_bytes(path):
    """Read exactly once from a no-follow regular-file descriptor (Linux only).

    This is a trusted-host candidate, not protection against hostile ancestor
    replacement or malicious filesystem behavior. Never re-open by path to
    validate the bytes a second time.
    """
    if not isinstance(path, Path):
        return None
    try:
        if (path.name != 'run-manifest.json' or path.is_symlink()
                or path.absolute() != path.resolve()
                or not hasattr(os, 'O_NOFOLLOW') or not hasattr(os, 'O_NONBLOCK')):
            return None
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode):
                return None
            content = stream.read(_MAX_MANIFEST_BYTES + 1)
        if len(content) > _MAX_MANIFEST_BYTES:
            return None
        return content
    except (OSError, ValueError, TypeError):
        return None


def _valid_terminal_state(record, run_id):
    """Reject wrong invocation identity and nonterminal/ambiguous cleanup."""
    if type(record) is not dict or type(run_id) is not UUID:
        return False
    return (
        record.get('run_id') == str(run_id)
        and record.get('run_hex') == run_id.hex
        and record.get('result') == 'PASS'
        and record.get('evidence_status') == 'AVAILABLE'
        and record.get('cleanup_passed') is True
        and record.get('cleanup_status') == 'CLEANUP_SUCCESS'
        and record.get('handler_restoration') == 'RESTORED'
        and type(record.get('credential_transport')) is str
        and record['credential_transport'] == 'STDIN_PIPE_V1'
        and type(record.get('transport_retirement')) is str
        and record['transport_retirement'] == 'RETIRED'
        and type(record.get('supervisor_cleanup')) is str
        and record['supervisor_cleanup'] == 'CONFIRMED'
        and type(record.get('server_activations')) is int
        and record['server_activations'] == 2
        and type(record.get('credential_file_cleanup')) is str
        and record['credential_file_cleanup'] == 'NOT_PRESENT'
        and type(record.get('secret_redactions')) is int
        and record['secret_redactions'] == 0
        and record.get('native_execution') is False
        and record.get('production_connections') is False
        and type(record.get('source_commit')) is str
        and len(record['source_commit']) in (40, 64)
        and all(ch in '0123456789abcdef' for ch in record['source_commit'])
    )



def _diagnostic_schema(record, run_id, evidence):
    """Only fixed diagnostic shapes from trusted runtime code are admissible."""
    required = {
        'version','run_id','run_hex','database','source_commit','source_status',
        'result','cleanup_passed','cleanup_status','operations','native_execution',
        'production_connections','creation_attempts','postgres_image','client_image',
        'base_image','driver_wheel_sha256','cluster_before_restart','cluster_after_restart',
        'server_inspect','remaining_containers','remaining_volumes',
        'possible_owned_containers','possible_owned_volumes','credential_file_cleanup',
        'handler_restoration','evidence_status','b5_4_1_evidence_dir',
        'credential_transport','transport_retirement','supervisor_cleanup','server_activations',
    }
    if set(record) not in (required, required | {'secret_redactions'},
                           required | {'extra_containers'},
                           required | {'secret_redactions','extra_containers'}):
        return False
    if (record['version'] != '2.0' or record['source_status'] != ''
            or record['database'] != 'r7_05b3_' + run_id.hex
            or record['b5_4_1_evidence_dir'] != str(evidence)
            or record['postgres_image'] != runtime.POSTGRES
            or record['base_image'] != runtime.BASE
            or record['driver_wheel_sha256'] != runtime.WHEEL_SHA256
            or type(record['client_image']) is not str
            or re.fullmatch(r'sha256:[0-9a-f]{64}',record['client_image']) is None
            or record['cluster_before_restart'] != 'PRIVATE_READINESS_OBSERVED'
            or record['cluster_after_restart'] != 'PRIVATE_READINESS_OBSERVED'
            or record['remaining_containers'] != '' or record['remaining_volumes'] != ''):
        return False
    prefix = 'r7-05b3-' + run_id.hex
    containers = {prefix + suffix for suffix in (
        '-provision','-server','-foundation','-restart','-b5-4-1')}
    volumes = {prefix+'-data',prefix+'-socket'}
    for key, allowed in (
            ('possible_owned_containers',containers),('possible_owned_volumes',volumes),
            ('extra_containers',{prefix+'-b5-4-1'})):
        values=record.get(key,[])
        if type(values) is not list or any(type(x) is not str or x not in allowed for x in values):
            return False
    def inspect_projection(value):
        if type(value) is not dict or set(value) != {'Config'}:
            return False
        config=value['Config']
        if type(config) is not dict or set(config) != {'Env'} or type(config['Env']) is not list:
            return False
        approved = {
            name+'=<test-secret>' for name in ('POSTGRES_PASSWORD','PGPASSWORD',
                'R7_PG_ADMIN_PASSWORD','R7_PG_MIGRATOR_PASSWORD',
                'R7_PG_WRITER_PASSWORD','R7_PG_READER_PASSWORD')}
        for name, literal in (('SAFE_FEATURE_FLAG','enabled'),('HTTP_PROXY',''),('NAME','a=b')):
            approved.update((name+'='+literal,name+'=<redacted-env-value>'))
        entries=config['Env']
        return (all(type(x) is str and x in approved for x in entries)
                and len({x.split('=',1)[0] for x in entries})==len(entries))
    if not inspect_projection(record['server_inspect']):
        return False
    operations=record['operations']
    if type(operations) is not list or len(operations)!=3:
        return False
    for operation, stage in zip(operations,('foundation','restart','b5-4-1')):
        keys={'stage','exit_code','tests'} if stage=='b5-4-1' else {'stage','exit_code','inspect'}
        if (type(operation) is not dict or set(operation)!=keys
                or operation['stage']!=stage or type(operation['exit_code']) is not int
                or operation['exit_code']!=0):
            return False
        if stage=='b5-4-1':
            if operation['tests']!=list(REPORTING_TESTS):
                return False
        elif not inspect_projection(operation['inspect']):
            return False
    attempts=record['creation_attempts']
    if type(attempts) is not list:
        return False
    allowed_attempt_keys={'kind','name','started_ns','state','local_pid','returned_ns',
                          'local_reaped','cli_returncode'}
    for attempt in attempts:
        if (type(attempt) is not dict or not {'kind','name','state'}<=set(attempt)
                or not set(attempt)<=allowed_attempt_keys
                or attempt['kind'] not in ('container','volume')
                or attempt['state']!='RETURNED'
                or type(attempt['name']) is not str
                or attempt['name'] not in (containers if attempt['kind']=='container' else volumes)):
            return False
        for key in ('started_ns','local_pid','returned_ns','cli_returncode'):
            if key in attempt and (type(attempt[key]) is not int or attempt[key]<0):
                return False
        if 'local_reaped' in attempt and attempt['local_reaped'] is not True:
            return False
    return True


def invoke_b5_4_1_and_admit(*, allow, wheelhouse, evidence):
    """Run once and admit ONLY its matching finalized, redacted byte snapshot.

    A separately supplied True, a prior run's result, and a bare PASS file
    cannot influence the decision. Exceptions from the runner (including
    KeyboardInterrupt and SystemExit) propagate: no result is issued.
    The reporting callback is fixed by source; callers cannot supply one.
    """
    if not isinstance(evidence, Path):
        raise TypeError('controller requires pathlib evidence directory')
    captured = []

    def stage(**kwargs):
        # The callback is invoked from the same runner we're controlling.
        # Capture its own identity and the SAME dict reference finalized later.
        run_id = kwargs.get('run_id')
        record = kwargs.get('record')
        envfile = kwargs.get('envfile')
        transport = kwargs.get('transport')
        if (captured or type(run_id) is not UUID or type(record) is not dict
                or not isinstance(envfile, Path)
                or envfile != evidence / 'test-client.env'
                or type(transport) is not CredentialSession
                or transport.run_id != run_id or transport.evidence != evidence
                or transport._lifecycle is not record or transport.retired):
            raise RuntimeError('untrusted or duplicate run stage identity')
        captured.append((run_id, record, transport))
        kwargs['record']['b5_4_1_evidence_dir'] = str(evidence)
        reporting_stage(**kwargs)

    # This exact call is the ONLY source of completion. If it raises or is
    # interrupted, NO receipt is created, regardless of leftover file status.
    runtime.run(allow=allow, wheelhouse=wheelhouse, evidence=evidence,
                   _host_stage=stage)

    if len(captured) != 1:
        return None
    run_id, record, transport = captured[0]
    if (transport.retired is not True or transport._passwords
            or transport.activations != 2
            or transport.client_stages != ['foundation','restart','b5-4-1']):
        return None
    if not _valid_terminal_state(record, run_id) or not _diagnostic_schema(record, run_id, evidence):
        return None

    # R2-03 guarantees the original retained dict reference is replaced by
    # the *finalized redacted* snapshot before publication. Reconstruct those
    # expected canonical bytes from that in-memory run state, never from the
    # untrusted file that a consumer is trying to admit.
    try:
        expected = json.dumps(record, indent=2, sort_keys=True,
                              allow_nan=False).encode('utf-8')
    except (ValueError, TypeError, OverflowError, UnicodeError):
        return None
    if len(expected) > _MAX_MANIFEST_BYTES:
        return None
    expected_digest = hashlib.sha256(expected).hexdigest()
    actual = _read_manifest_bytes(evidence / 'run-manifest.json')
    if actual is None or len(actual) != len(expected):
        return None
    if hashlib.sha256(actual).hexdigest() != expected_digest or actual != expected:
        return None
    # Return only a pinned immutable copy. Consumers must use this verified
    # snapshot, not re-read an untrusted path that may change later.
    return VerifiedB541Manifest(
        run_id=str(run_id), sha256=expected_digest,
        manifest_bytes=actual, source_commit=record['source_commit'])


def admit_archive_without_attestation(_path):
    """Explicit default-deny archive/import boundary.

    A raw manifest is insufficient after the synchronous controller exits.
    No authenticated durable receipt, replay policy, restart recovery, or
    fsync protocol is implemented here; therefore archive admission is False.
    """
    return None
