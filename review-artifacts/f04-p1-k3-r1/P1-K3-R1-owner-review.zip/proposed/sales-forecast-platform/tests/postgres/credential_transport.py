"""Bounded, file-free credential delivery for the fixed disposable test plan.

Linux/WSL only. Neither process-local environment nor Python memory is a
confidentiality boundary against the host, same UID, debugger, swap or dumps.
No daemon configuration, argv, lease or public exception contains passwords.
"""
import base64
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import selectors
import signal
import stringprep
import subprocess
import time
import unicodedata
from uuid import UUID

ROLES = ('admin', 'migrator', 'writer', 'reader')
MAX_FRAME = 2048
ITERATIONS = 4096
TESTS = {
    'foundation': ('tests/postgres/test_forecast_evidence_postgres.py',),
    'restart': ('tests/postgres/test_forecast_evidence_restart.py',),
    'b5-4-1': (
        'tests/postgres/test_stored_forecast_accuracy_postgres.py',
        'tests/postgres/test_canonical_reporting_read.py',
        'tests/postgres/test_r7_05b5_4_1_host_reporting_requests.py',
    ),
}
DOCKER = ('docker', '--host=unix:///var/run/docker.sock')


class TransportFailure(RuntimeError):
    """Fixed public diagnostic: external exceptions must not be chained here."""


def _failure(kind=None):
    if kind == 'INTERRUPTED':
        return KeyboardInterrupt('credential transport interrupted; details withheld')
    if kind == 'EXIT':
        return SystemExit('credential transport exited; details withheld')
    return TransportFailure('credential transport failed; details withheld')


def _kind(error):
    return ('INTERRUPTED' if isinstance(error, KeyboardInterrupt) else
            'EXIT' if isinstance(error, SystemExit) else 'FAILED')


def normalize_password(value):
    """SASLprep using Unicode 3.2 tables; reject PostgreSQL's raw fallback.

    Generated transport passwords are nonempty printable ASCII. Normalization
    is explicit so an eventual broader caller cannot silently hash differently.
    """
    failed = False
    try:
        if type(value) is not str or not 1 <= len(value.encode('utf-8')) <= 256:
            raise ValueError()
        mapped = ''.join(' ' if stringprep.in_table_c12(c) else c
                         for c in value if not stringprep.in_table_b1(c))
        normalized = unicodedata.ucd_3_2_0.normalize('NFKC', mapped)
        prohibited = (stringprep.in_table_a1, stringprep.in_table_c12,
                      stringprep.in_table_c21, stringprep.in_table_c22,
                      stringprep.in_table_c3, stringprep.in_table_c4,
                      stringprep.in_table_c5, stringprep.in_table_c6,
                      stringprep.in_table_c7, stringprep.in_table_c8,
                      stringprep.in_table_c9)
        if (not normalized or len(normalized.encode('utf-8')) > 256
                or any(fn(c) for c in normalized for fn in prohibited)):
            raise ValueError()
        if any(stringprep.in_table_d1(c) for c in normalized):
            if (any(stringprep.in_table_d2(c) for c in normalized)
                    or not stringprep.in_table_d1(normalized[0])
                    or not stringprep.in_table_d1(normalized[-1])):
                raise ValueError()
    except BaseException as error:
        failed = _kind(error)
    if failed:
        raise _failure(failed)
    return normalized


def validate_verifier(value):
    failed = False
    try:
        if type(value) is not str or len(value) > 256:
            raise ValueError()
        match = re.fullmatch(r'SCRAM-SHA-256\$([1-9][0-9]{0,6}):([A-Za-z0-9+/]+=*)\$([A-Za-z0-9+/]+=*):([A-Za-z0-9+/]+=*)', value)
        if match is None or int(match[1]) != ITERATIONS:
            raise ValueError()
        for part, length in zip(match.groups()[1:], (16, 32, 32)):
            raw = base64.b64decode(part, validate=True)
            if len(raw) != length or base64.b64encode(raw).decode('ascii') != part:
                raise ValueError()
    except BaseException as error:
        failed = _kind(error)
    if failed:
        raise _failure(failed)
    return value


def scram_verifier(password, salt):
    """Explicit salt input: caller supplies 16 cryptographically random bytes.

    Tests supply only published synthetic constants. Verifiers are sensitive
    authenticators and must be withheld/redacted just like plaintext passwords.
    """
    prepared = normalize_password(password)
    if type(salt) is not bytes or len(salt) != 16:
        raise TransportFailure('invalid SCRAM salt')
    salted = hashlib.pbkdf2_hmac('sha256', prepared.encode('utf-8'), salt, ITERATIONS)
    client = hmac.new(salted, b'Client Key', hashlib.sha256).digest()
    stored = hashlib.sha256(client).digest()
    server = hmac.new(salted, b'Server Key', hashlib.sha256).digest()
    enc = lambda value: base64.b64encode(value).decode('ascii')
    return validate_verifier(f'SCRAM-SHA-256${ITERATIONS}:{enc(salt)}${enc(stored)}:{enc(server)}')


def validate_identity(run_id, database):
    if (type(run_id) is not str or type(database) is not str
            or re.fullmatch(r'[0-9a-f-]{36}', run_id) is None
            or str(UUID(run_id)) != run_id or database != 'r7_05b3_' + UUID(run_id).hex):
        raise TransportFailure('invalid disposable transport identity')


def validate_passwords(passwords):
    if type(passwords) is not dict or set(passwords) != set(ROLES):
        raise TransportFailure('invalid credential set')
    # This intentionally restricts generated credentials. No line endings,
    # delimiters, quoting, C-string truncation or normalization ambiguity.
    for value in passwords.values():
        if type(value) is not str or re.fullmatch(r'test-only-[a-z0-9]{40}', value) is None:
            raise TransportFailure('invalid transport credential')
    if len(set(passwords.values())) != len(ROLES):
        raise TransportFailure('duplicate transport credential')


def encode_frame(run_id, database, stage, passwords):
    validate_identity(run_id, database)
    validate_passwords(passwords)
    if type(stage) is not str or stage not in TESTS:
        raise TransportFailure('unapproved client stage')
    payload = json.dumps(dict(version=1, run_id=run_id, database=database,
                              stage=stage, passwords=passwords),
                         separators=(',', ':'), ensure_ascii=True).encode('ascii')
    if len(payload) > MAX_FRAME:
        raise TransportFailure('oversized credential frame')
    return f'{len(payload):04d}'.encode('ascii') + payload


def read_frame(fd, *, read=os.read):
    """Exact reads: never prefetch a SQL byte or accept partial/extra frames."""
    failed = False
    try:
        def exact(size):
            result = bytearray()
            while len(result) < size:
                part = read(fd, size - len(result))
                if not part:
                    raise ValueError()
                result.extend(part)
            return bytes(result)
        header = exact(4)
        if any(byte not in b'0123456789' for byte in header):
            raise ValueError()
        size = int(header)
        if not 1 <= size <= MAX_FRAME:
            raise ValueError()
        def pairs(values):
            result = {}
            for key, value in values:
                if key in result:
                    raise ValueError()
                result[key] = value
            return result
        value = json.loads(exact(size).decode('ascii'), object_pairs_hook=pairs)
        if type(value) is not dict or set(value) != {'version','run_id','database','stage','passwords'}:
            raise ValueError()
        if type(value['version']) is not int or value['version'] != 1 or value['stage'] not in TESTS:
            raise ValueError()
        validate_identity(value['run_id'], value['database'])
        validate_passwords(value['passwords'])
        if read(fd, 1) != b'':
            raise ValueError()
    except BaseException as error:
        failed = _kind(error)
    if failed:
        raise _failure(failed)
    return value


def clean_host_environment():
    # Keep the host's executable lookup; force the existing fixed local daemon.
    # Never inherit application secrets into a Docker CLI or cleanup supervisor.
    return {key: os.environ[key] for key in ('PATH','HOME','LANG','LC_ALL') if key in os.environ}


def validate_attachment_configuration(raw):
    """Private check: do not infer daemon EOF configuration from CLI flags."""
    failure = None
    try:
        value = json.loads(raw)
        if type(value) is not list or len(value) != 1 or type(value[0]) is not dict:
            raise ValueError()
        config = value[0].get('Config')
        if (type(config) is not dict or config.get('OpenStdin') is not True
                or config.get('StdinOnce') is not True or config.get('Tty') is not False):
            raise ValueError()
    except BaseException as error:
        failure = _kind(error)
    if failure:
        raise _failure(failure)


# Shell builtins consume exactly one bounded ASCII password line, without
# prefetch. SQL remains on stdin for psql. -w prevents a fallback prompt from
# accidentally treating SQL as a password; no startup file or pager is used.
PSQL_ADAPTER = r'''set -eu
IFS= read -r -n 50 credential
test "${#credential}" -eq 50
IFS= read -r -n 1 terminator
test -z "$terminator"
case "$credential" in test-only-*) ;; *) exit 71;; esac
case "$credential" in *[!a-z0-9-]*) exit 71;; esac
export PGPASSWORD="$credential"
unset credential
exec psql -X -w -P pager=off "$@"
'''


class CredentialSession:
    """One run, one runtime; mutable channel state is never an admission token."""
    def __init__(self, run_id, database, evidence, passwords, lifecycle, supervisor=None):
        validate_identity(str(run_id), database)
        validate_passwords(passwords)
        self.run_id, self.database = run_id, database
        self.evidence = Path(evidence)
        self._passwords = dict(passwords)
        self._lifecycle = lifecycle
        self._attachments = []
        self._failed = False
        self.retired = False
        self.activations = 0
        self.client_stages = []
        self.supervisor = supervisor

    def activate(self, server, *, popen=None, inspect=None):
        """Fresh start/attach per activation; secret enters stdin only.

        Output is deliberately discarded, and daemon log persistence is disabled
        in the separately reviewed create argv. EOF ends delivery, not service.
        """
        if self.retired or self._failed or server != 'r7-05b3-'+self.run_id.hex+'-server':
            raise TransportFailure('invalid activation state')
        attempt = dict(kind='container', name=server, started_ns=time.time_ns(), state='PENDING')
        self._lifecycle['creation_attempts'].append(attempt)
        failure = None
        process = None
        try:
            if self.supervisor is not None:
                self.supervisor.check_live()
            if inspect is None:
                raise TransportFailure('attachment configuration proof required')
            validate_attachment_configuration(
                inspect(['docker','container','inspect',server]).stdout)
            popen = subprocess.Popen if popen is None else popen
            process = popen([*DOCKER, 'start', '--attach', '--interactive', server],
                            stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL, env=clean_host_environment(),
                            start_new_session=True, close_fds=True)
            # Retain ownership before any input write or interruption.
            self._attachments.append((process, attempt))
            attempt['local_pid'] = process.pid
            descriptor = process.stdin.fileno()
            os.set_blocking(descriptor, False)
            payload = (self._passwords['admin']+'\n').encode('ascii')
            deadline = time.monotonic() + 10
            with selectors.DefaultSelector() as selector:
                selector.register(descriptor, selectors.EVENT_WRITE)
                offset = 0
                while offset < len(payload):
                    if time.monotonic() >= deadline or process.poll() is not None:
                        raise TimeoutError()
                    if selector.select(min(.1, max(0, deadline-time.monotonic()))):
                        try:
                            offset += os.write(descriptor, payload[offset:])
                        except BlockingIOError:
                            continue
            process.stdin.close()  # explicit finite EOF; no wait for server exit
            self.activations += 1
        except BaseException as error:
            failure = _kind(error)
            self._failed = True
            attempt['state'] = 'DAEMON_UNRESOLVED'
        if failure:
            raise _failure(failure)

    def reap_activation(self, *, require_success):
        failure = None
        for process, attempt in self._attachments:
            if attempt.get('local_reaped') is True:
                continue
            try:
                code = process.wait(timeout=5)
                attempt.update(local_reaped=True, cli_returncode=code,
                               returned_ns=time.time_ns())
                if require_success and code == 0 and attempt['state'] != 'DAEMON_UNRESOLVED':
                    attempt['state'] = 'RETURNED'
                else:
                    attempt['state'] = 'DAEMON_UNRESOLVED'
                    self._failed = True
            except BaseException as error:
                failure = failure or _kind(error)
                attempt['state'] = 'DAEMON_UNRESOLVED'
                self._failed = True
                try:
                    if process.poll() is None:
                        os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=3)
                    attempt['local_reaped'] = True
                except BaseException as secondary:
                    if isinstance(secondary, (KeyboardInterrupt, SystemExit)):
                        failure = _kind(secondary)
        if failure:
            raise _failure(failure)

    def psql(self, command, server, args, sql=''):
        if self.retired or self._failed or type(sql) is not str:
            raise TransportFailure('invalid psql transport state')
        if self.supervisor is not None:
            self.supervisor.check_live()
        failure = None
        try:
            result = command(['docker','exec','-i',server,'bash','-c',PSQL_ADAPTER,
                              'r7-fixed-psql', *args],
                             stdin=self._passwords['admin']+'\n'+sql,
                             check=False, timeout=8)
        except BaseException as error:
            failure = _kind(error)
            self._failed = True
        if failure:
            raise _failure(failure)
        return result

    def client_frame(self, stage):
        if self.retired or self._failed:
            raise TransportFailure('retired credential transport')
        if self.supervisor is not None:
            self.supervisor.check_live()
        frame = encode_frame(str(self.run_id), self.database, stage, self._passwords)
        self.client_stages.append(stage)
        return frame.decode('ascii')

    def retire(self):
        """Drop owned references; this is not secure erasure of Python memory."""
        self._passwords.clear()
        self.retired = all(a.get('local_reaped') is True for _, a in self._attachments)
        return ('RETIRED' if self.retired and not self._failed else 'UNCONFIRMED')
