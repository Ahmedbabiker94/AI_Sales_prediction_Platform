"""Fixed stdin adapter: no selectable modules, passfiles or disk fallback."""
import os
import resource
import sys
from credential_transport import ROLES, TESTS, read_frame


def main():
    # Finite producer EOF plus an OS timer bounds even malformed/truncated input.
    import signal
    def interrupted(_signum, _frame):
        raise KeyboardInterrupt('credential input interrupted')
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGALRM, interrupted)
    signal.alarm(10)
    try:
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        value = read_frame(0)
    finally:
        signal.alarm(0)
    if len(sys.argv) != 2 or sys.argv[1] != value['stage']:
        raise RuntimeError('fixed client stage required')
    # Clear ambient PG settings before loading the known fixture environment.
    for key in tuple(os.environ):
        if key.startswith(('PG', 'R7_PG_')):
            del os.environ[key]
    os.environ['R7_PG_INSTANCE'] = value['run_id']
    os.environ['R7_PG_DATABASE'] = value['database']
    for role in ROLES:
        os.environ['R7_PG_'+role.upper()+'_PASSWORD'] = value['passwords'][role]
    try:
        import pytest
        return pytest.main(['-q','--tb=short','--maxfail=1','-p','no:cacheprovider',
                            *TESTS[value['stage']]])
    finally:
        for role in ROLES:
            os.environ.pop('R7_PG_'+role.upper()+'_PASSWORD', None)
        value['passwords'].clear()


if __name__ == '__main__':
    outcome = 70
    try:
        outcome = main()
    except BaseException:
        # The parent receives only a status. Never format exception/locals.
        pass
    raise SystemExit(outcome)
