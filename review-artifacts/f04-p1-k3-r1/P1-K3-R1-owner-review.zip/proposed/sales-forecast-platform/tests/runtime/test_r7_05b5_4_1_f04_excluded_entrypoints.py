"""P1-I exclusions: safe collection, refusal before operational work."""
import ast
import builtins
from pathlib import Path
import runpy
import subprocess
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
EXCLUDED = (
    ('tests/postgres/run_forecast_read.py','run'),
    ('tests/postgres/run_stored_accuracy.py','run'),
    ('tests/persistence/run_authorized_persistence.py','main'),
    ('tests/persistence/test_interruption_recovery.py','main'),
)


class ExclusionTests(unittest.TestCase):
    def test_excluded_cli_denies_before_imports(self):
        for rel, _ in EXCLUDED:
            with self.subTest(rel=rel):
                with patch.object(subprocess,'Popen',side_effect=AssertionError('process forbidden')):
                    with self.assertRaisesRegex(RuntimeError,'F04_NARROW_SCOPE_EXCLUDED'):
                        runpy.run_path(str(ROOT/rel),run_name='__main__')

    def test_collection_safe_load_then_call_denies_before_private_imports(self):
        real_import = builtins.__import__
        def guarded_import(name,*args,**kwargs):
            if name == 'src' or name.startswith('src.'):
                raise AssertionError('native/private import forbidden')
            return real_import(name,*args,**kwargs)
        for rel, entry in EXCLUDED:
            with self.subTest(rel=rel), patch.object(builtins,'__import__',side_effect=guarded_import):
                namespace = runpy.run_path(str(ROOT/rel),run_name='collection_safe')
                with self.assertRaisesRegex(RuntimeError,'F04_NARROW_SCOPE_EXCLUDED'):
                    if entry == 'run':
                        namespace[entry](None,None)
                    else:
                        namespace[entry]()

    def test_base_cli_refuses_before_run(self):
        argv = ['runner','--allow-disposable-postgres','--wheelhouse','absent','--evidence','absent']
        with patch.object(sys,'argv',argv), patch.object(
                subprocess,'Popen',side_effect=AssertionError('process forbidden')):
            with self.assertRaisesRegex(SystemExit,'F04_NARROW_SCOPE_EXCLUDED'):
                runpy.run_path(str(ROOT/'tests/postgres/run_postgres.py'),run_name='__main__')

    def test_callable_guards_are_unconditional_first_statements(self):
        for rel, entry in EXCLUDED:
            body = ast.parse((ROOT/rel).read_text()).body
            fn = next(node for node in body if isinstance(node,ast.FunctionDef) and node.name==entry)
            self.assertIsInstance(fn.body[0],ast.Raise)
            self.assertIsInstance(fn.body[0].exc.args[0],ast.Constant)


if __name__ == '__main__':
    unittest.main()
