"""Synthetic fixed public vectors only; no daemon, credentials or subprocess."""
import ast
import base64
import hashlib
import hmac
import io
import json
import os
from pathlib import Path
import signal
import sys
import tempfile
import traceback
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from uuid import UUID

PG = Path(__file__).resolve().parents[1]/'postgres'
sys.path.insert(0,str(PG))
import credential_transport as transport
import credential_test_client as client

RUN = UUID('12345678-1234-1234-1234-123456789abc')
DB = 'r7_05b3_'+RUN.hex
# Public fixtures are deliberately not generated, registered or usable anywhere.
PASSWORDS = {role:'test-only-'+str(n)*40 for n,role in enumerate(transport.ROLES,1)}


def inspect_attachment(_args):
    return SimpleNamespace(stdout=json.dumps([{'Config':{'OpenStdin':True,'StdinOnce':True,'Tty':False}}]))


def assert_safe(test, error, marker):
    pending=[error]
    seen=set()
    while pending:
        value=pending.pop()
        if id(value) in seen:
            continue
        seen.add(id(value))
        test.assertNotIn(marker,repr(value.args))
        test.assertNotIn(marker,repr(vars(value)))
        pending.extend(e for e in (value.__cause__,value.__context__) if e is not None)
    test.assertNotIn(marker,''.join(traceback.format_exception(error)))


class FrameTests(unittest.TestCase):
    def decode(self, value, chunk=1):
        stream=io.BytesIO(value)
        return transport.read_frame(0,read=lambda fd,n:stream.read(min(n,chunk)))

    def test_exact_frame_and_fragmented_reads(self):
        frame=transport.encode_frame(str(RUN),DB,'foundation',PASSWORDS)
        for chunk in (1,2,17,4096):
            with self.subTest(chunk=chunk):
                value=self.decode(frame,chunk)
                self.assertEqual(value['passwords'],PASSWORDS)
                self.assertEqual(value['database'],DB)

    def test_every_truncation_and_extra_byte_rejected(self):
        frame=transport.encode_frame(str(RUN),DB,'foundation',PASSWORDS)
        for n in range(len(frame)):
            with self.subTest(length=n),self.assertRaises(transport.TransportFailure):
                self.decode(frame[:n],4096)
        with self.assertRaises(transport.TransportFailure):
            self.decode(frame+b'x',4096)

    def test_malformed_headers_and_oversize(self):
        for value in (b'',b'0000',b'2049',b'9999',b'-001',b'\x00\x00\x00\x10',b'ABCD'):
            with self.subTest(value=value),self.assertRaises(transport.TransportFailure):
                self.decode(value)

    def test_json_attributes_chains_and_tracebacks_do_not_escape(self):
        marker='PUBLIC_SYNTHETIC_UNSAFE_JSON'
        data=(marker+'{').encode()
        with self.assertRaises(transport.TransportFailure) as caught:
            self.decode(f'{len(data):04d}'.encode()+data,4096)
        assert_safe(self,caught.exception,marker)

    def test_invalid_shapes_duplicates_and_identity(self):
        good=json.loads(transport.encode_frame(str(RUN),DB,'foundation',PASSWORDS)[4:])
        invalid=[[],None,dict(good,extra='x'),dict(good,version=True),
                 dict(good,stage='native'),dict(good,stage={}),
                 dict(good,database='production'),dict(good,run_id='bad'),
                 dict(good,passwords={}),dict(good,passwords=dict(PASSWORDS,admin=''))]
        for value in invalid:
            data=json.dumps(value).encode()
            with self.subTest(value=type(value).__name__),self.assertRaises(transport.TransportFailure):
                self.decode(f'{len(data):04d}'.encode()+data,4096)
        data=b'{"version":1,"version":1}'
        with self.assertRaises(transport.TransportFailure):
            self.decode(f'{len(data):04d}'.encode()+data,4096)

    def test_interrupt_and_system_exit_classes_are_sanitized(self):
        for cls in (KeyboardInterrupt,SystemExit):
            def read(fd,size):
                raise cls('PUBLIC_SYNTHETIC_UNSAFE_INTERRUPT')
            with self.subTest(cls=cls),self.assertRaises(cls) as caught:
                transport.read_frame(0,read=read)
            assert_safe(self,caught.exception,'PUBLIC_SYNTHETIC_UNSAFE_INTERRUPT')

    def test_no_newline_nul_unicode_or_duplicate_password(self):
        for bad in ('',PASSWORDS['admin']+'\n',PASSWORDS['admin']+'\x00','é'*40,
                    'test-only-'+'a'*1000,PASSWORDS['writer']):
            with self.subTest(length=len(bad)),self.assertRaises(transport.TransportFailure):
                transport.encode_frame(str(RUN),DB,'foundation',dict(PASSWORDS,admin=bad))


class ScramTests(unittest.TestCase):
    def test_public_pencil_password_fixed_salt_hmac_vector(self):
        # A public fixture password and fixed salt; SHA-256 result calculated
        # independently via the PBKDF2 and HMAC definitions.
        salt=bytes(range(16))
        value=transport.scram_verifier('pencil',salt)
        fields=value.split('$')
        count,actual_salt=fields[1].split(':')
        stored,server=fields[2].split(':')
        salted=hashlib.pbkdf2_hmac('sha256',b'pencil',salt,4096)
        client=hmac.digest(salted,b'Client Key','sha256')
        self.assertEqual(int(count),4096)
        self.assertEqual(base64.b64decode(actual_salt),salt)
        self.assertEqual(base64.b64decode(stored),hashlib.sha256(client).digest())
        self.assertEqual(base64.b64decode(server),hmac.digest(salted,b'Server Key','sha256'))
        self.assertIs(transport.validate_verifier(value),value)

    def test_saslprep_public_vectors(self):
        for value,expected in (('I\u00adX','IX'),('user','user'),('\u00aa','a'),
                               ('\u2168','IX'),('a\u00a0b','a b')):
            with self.subTest(value=value):
                self.assertEqual(transport.normalize_password(value),expected)

    def test_prohibited_empty_unassigned_bidi_and_invalid_utf8(self):
        for bad in ('','\u00ad','\x00','a\n','\ud800','\u0221','a\u0627', 'x'*257):
            with self.subTest(value=repr(bad)),self.assertRaises(transport.TransportFailure):
                transport.normalize_password(bad)

    def test_wrong_salt_key_count_base64_and_noncanonical_verifier(self):
        good=transport.scram_verifier('pencil',b'0123456789abcdef')
        cases=[None,'x',good.replace('4096:','0:'),good.replace('4096:','-1:'),
               good.replace('4096:','4097:'),good+'\n',good+'x',
               good.replace('SCRAM-SHA-256','SCRAM-SHA-512'),
               'SCRAM-SHA-256$4096:AA==$AA==:AA==']
        for bad in cases:
            with self.subTest(value=type(bad).__name__),self.assertRaises(transport.TransportFailure):
                transport.validate_verifier(bad)
        for salt in (b'',b'a'*15,b'a'*17,'a'*16):
            with self.subTest(salt=type(salt).__name__),self.assertRaises(transport.TransportFailure):
                transport.scram_verifier('pencil',salt)


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.record={'creation_attempts':[]}
        self.session=transport.CredentialSession(RUN,DB,Path('/synthetic'),PASSWORDS,self.record)

    def test_frames_follow_fixed_stage_and_retirement_is_terminal(self):
        for stage in ('foundation','restart','b5-4-1'):
            self.session.client_frame(stage)
        self.assertEqual(self.session.client_stages,list(transport.TESTS))
        self.assertEqual(self.session.retire(),'RETIRED')
        self.assertEqual(self.session._passwords,{})
        with self.assertRaises(transport.TransportFailure):
            self.session.client_frame('foundation')

    def test_unreaped_attachment_cannot_retire(self):
        self.session._attachments=[(None,{'state':'PENDING'})]
        self.assertEqual(self.session.retire(),'UNCONFIRMED')
        self.assertFalse(self.session.retired)
        self.assertEqual(self.session._passwords,{})

    def test_managed_activation_writes_only_stdin_and_closes_eof(self):
        captured=[]
        stdin=SimpleNamespace(fileno=lambda:99,close=lambda:captured.append('EOF'))
        process=SimpleNamespace(stdin=stdin,pid=77,poll=lambda:None)
        selector=SimpleNamespace(register=lambda *a:None,select=lambda *a:[True])
        manager=SimpleNamespace(__enter__=lambda self:selector,__exit__=lambda *a:None)
        class Selector:
            def __enter__(self): return selector
            def __exit__(self,*args): pass
        def popen(args,**kwargs):
            captured.append((args,kwargs))
            return process
        def write(fd,value):
            captured.append(value)
            return min(len(value),7)  # force several partial writes
        with patch.object(transport.os,'set_blocking'),patch.object(transport.os,'write',side_effect=write),\
             patch.object(transport.selectors,'DefaultSelector',Selector):
            self.session.activate('r7-05b3-'+RUN.hex+'-server',popen=popen,inspect=inspect_attachment)
        args,kwargs=captured[0]
        self.assertNotIn(PASSWORDS['admin'],repr(args)+repr(kwargs))
        self.assertTrue(kwargs['close_fds'])
        self.assertTrue(kwargs['start_new_session'])
        self.assertEqual(args[-4:-1],['start','--attach','--interactive'])
        self.assertEqual(captured[-1],'EOF')
        self.assertEqual(self.session.activations,1)
        self.assertEqual(self.record['creation_attempts'][0]['state'],'PENDING')

    def test_activation_interrupt_is_uncertain_and_public_graph_is_safe(self):
        for cls in (OSError,KeyboardInterrupt,SystemExit):
            def popen(*args,**kwargs): raise cls('PUBLIC_SYNTHETIC_UNSAFE_POPEN')
            with self.subTest(cls=cls),self.assertRaises(BaseException) as caught:
                self.session.activate('r7-05b3-'+RUN.hex+'-server',popen=popen,inspect=inspect_attachment)
            assert_safe(self,caught.exception,'PUBLIC_SYNTHETIC_UNSAFE_POPEN')
            self.assertEqual(self.record['creation_attempts'][-1]['state'],'DAEMON_UNRESOLVED')
            self.session=transport.CredentialSession(RUN,DB,Path('/synthetic'),PASSWORDS,self.record)

    def test_failed_or_interrupted_reap_never_confirms_retirement(self):
        for outcome in (137,KeyboardInterrupt('PUBLIC_SYNTHETIC_REAP')):
            def wait(**kw):
                if isinstance(outcome,BaseException):raise outcome
                return outcome
            process=SimpleNamespace(wait=wait,pid=77,poll=lambda:1)
            attempt={'state':'PENDING'}
            self.session._attachments=[(process,attempt)]
            try:self.session.reap_activation(require_success=True)
            except KeyboardInterrupt as error:assert_safe(self,error,'PUBLIC_SYNTHETIC_REAP')
            self.assertEqual(attempt['state'],'DAEMON_UNRESOLVED')
            self.assertEqual(self.session.retire(),'UNCONFIRMED')

    def test_psql_wrapper_keeps_password_out_of_argv_and_config(self):
        captured={}
        def command(args,**kwargs):captured.update(args=args,kwargs=kwargs)
        self.session.psql(command,'server',['-c','SELECT 1'],'SELECT 2;\n')
        self.assertNotIn(PASSWORDS['admin'],repr(captured['args']))
        self.assertNotIn('PGPASSFILE',repr(captured['args']))
        self.assertEqual(captured['kwargs']['stdin'],PASSWORDS['admin']+'\nSELECT 2;\n')
        self.assertIn('-w',transport.PSQL_ADAPTER)
        self.assertIn('-X',transport.PSQL_ADAPTER)

    def test_psql_external_error_attributes_and_chains_are_withheld(self):
        for cls in (OSError,ValueError,KeyboardInterrupt,SystemExit):
            session=transport.CredentialSession(RUN,DB,Path('/synthetic'),PASSWORDS,self.record)
            def command(*args,**kwargs):
                error=cls('PUBLIC_UNSAFE_PSQL_ERROR')
                error.payload='PUBLIC_UNSAFE_PSQL_ERROR'
                raise error
            with self.subTest(cls=cls),self.assertRaises(BaseException) as caught:
                session.psql(command,'server',[])
            assert_safe(self,caught.exception,'PUBLIC_UNSAFE_PSQL_ERROR')
            self.assertEqual(session.retire(),'UNCONFIRMED')


class SourceContractTests(unittest.TestCase):
    def test_daemon_stdin_once_non_tty_configuration_required(self):
        transport.validate_attachment_configuration(inspect_attachment(None).stdout)
        for key,value in (('OpenStdin',False),('StdinOnce',False),('Tty',True),('StdinOnce',1)):
            config={'OpenStdin':True,'StdinOnce':True,'Tty':False,key:value}
            with self.subTest(key=key,value=value),self.assertRaises(transport.TransportFailure):
                transport.validate_attachment_configuration(json.dumps([{'Config':config}]))
        with self.assertRaises(transport.TransportFailure) as caught:
            transport.validate_attachment_configuration('PUBLIC_UNSAFE_INSPECT_JSON')
        assert_safe(self,caught.exception,'PUBLIC_UNSAFE_INSPECT_JSON')

    def test_absence_guard_rejects_present_symlink_and_uncertain_stat(self):
        import run_postgres as runtime
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'test-client.env'
            self.assertEqual(runtime.remove_transient_credential_file(path),'NOT_PRESENT')
            path.write_text('PUBLIC_FORBIDDEN_LEGACY_MARKER')
            self.assertEqual(runtime.remove_transient_credential_file(path),'UNCONFIRMED')
            self.assertTrue(path.exists())  # guard must not delete/read a discovered file
            path.unlink()
            path.symlink_to(Path(directory)/'missing')
            self.assertEqual(runtime.remove_transient_credential_file(path),'UNCONFIRMED')
            with patch.object(Path,'lstat',side_effect=PermissionError('synthetic stat denied')):
                self.assertEqual(runtime.remove_transient_credential_file(path),'UNCONFIRMED')

    def test_worker_clears_environment_after_failure_without_files_or_exec(self):
        value=dict(run_id=str(RUN),database=DB,stage='foundation',passwords=dict(PASSWORDS))
        def fake_pytest(args):
            self.assertEqual(tuple(args[-1:]),transport.TESTS['foundation'])
            self.assertEqual(os.environ['R7_PG_ADMIN_PASSWORD'],PASSWORDS['admin'])
            self.assertNotIn('PGPASSWORD',os.environ)
            raise RuntimeError('synthetic pytest failure')
        with patch.object(client,'read_frame',return_value=value),\
             patch.object(client.signal if hasattr(client,'signal') else signal,'signal'),\
             patch.object(signal,'alarm'),patch.object(client.resource,'setrlimit'),\
             patch.object(sys,'argv',['adapter','foundation']),\
             patch.dict(os.environ,{'PGPASSWORD':'PUBLIC_AMBIENT_VALUE'},clear=False),\
             patch.dict(sys.modules,{'pytest':SimpleNamespace(main=fake_pytest)}):
            with self.assertRaises(RuntimeError):client.main()
            self.assertFalse(any('R7_PG_'+r.upper()+'_PASSWORD' in os.environ for r in transport.ROLES))
            self.assertEqual(value['passwords'],{})

    def test_fixed_selectors_and_client_interface(self):
        import run_b5_4_1_reporting_stage as reporting
        self.assertEqual(reporting.TESTS,transport.TESTS['b5-4-1'])
        self.assertEqual(transport.TESTS['foundation'],('tests/postgres/test_forecast_evidence_postgres.py',))
        self.assertEqual(transport.TESTS['restart'],('tests/postgres/test_forecast_evidence_restart.py',))
        source=(PG/'credential_test_client.py').read_text()
        self.assertIn("read_frame(0)",source)
        self.assertIn("signal.alarm(10)",source)
        self.assertIn("*TESTS[value['stage']]",source)
        self.assertNotIn('exec(',source)

    def test_no_disk_fallback_envfile_secret_argv_or_blind_restart(self):
        source=(PG/'run_postgres.py').read_text()
        stage=(PG/'run_b5_4_1_reporting_stage.py').read_text()
        for text in (source,stage):
            self.assertNotIn('--env-file',text)
            self.assertNotIn("'POSTGRES_PASSWORD='+",text)
            self.assertNotIn("'PGPASSWORD='+",text)
            self.assertNotIn("with open(envfile",text)
            self.assertNotIn("'docker', 'restart'",text)
        tree=ast.parse(source)
        absence=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='remove_transient_credential_file')
        self.assertFalse(any(isinstance(n,ast.Attribute) and n.attr=='unlink' for n in ast.walk(absence)))
        self.assertIn('POSTGRES_PASSWORD_FILE=/dev/stdin',source)
        self.assertIn('logging_collector=off',source)
        self.assertIn('--log-driver=none',source)
        self.assertIn('core=0:0',source)


if __name__=='__main__':
    unittest.main()
