"""P1-I mock-only proposal tests. No Docker, PostgreSQL, network or child process."""
import contextlib
import hashlib
import importlib
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import traceback
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from uuid import uuid4

POSTGRES = Path(__file__).resolve().parents[1] / 'postgres'
sys.path.insert(0, str(POSTGRES))
import run_postgres as runtime
from credential_transport import CredentialSession
import run_b5_4_1_reporting_stage as reporting
import run_manifest_admission_controller as controller
import run_b5_4_1_postgres as wrapper


def terminal(run_id):
    value = dict(run_id=str(run_id), run_hex=run_id.hex, result='PASS',
                evidence_status='AVAILABLE', cleanup_passed=True,
                cleanup_status='CLEANUP_SUCCESS', handler_restoration='RESTORED',
                credential_file_cleanup='NOT_PRESENT', secret_redactions=0,
                native_execution=False, production_connections=False,
                source_commit='a' * 40)
    projection={'Config':{'Env':[]}}
    value.update(credential_transport='STDIN_PIPE_V1', transport_retirement='RETIRED',
        supervisor_cleanup='CONFIRMED', server_activations=2, version='2.0',database='r7_05b3_'+run_id.hex,source_status='',
        operations=[dict(stage=s,exit_code=0,inspect=projection) for s in ('foundation','restart')]+[
            dict(stage='b5-4-1',exit_code=0,tests=list(reporting.TESTS))],
        creation_attempts=[],postgres_image=runtime.POSTGRES,client_image='sha256:'+'c'*64,
        base_image=runtime.BASE,driver_wheel_sha256=runtime.WHEEL_SHA256,
        cluster_before_restart='PRIVATE_READINESS_OBSERVED',cluster_after_restart='PRIVATE_READINESS_OBSERVED',
        server_inspect=projection,remaining_containers='',remaining_volumes='',
        possible_owned_containers=[],possible_owned_volumes=[])
    return value


def canonical(value):
    return json.dumps(value, indent=2, sort_keys=True, allow_nan=False).encode()


class AdmissionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.addCleanup(patch.stopall)
        patch.object(subprocess, 'Popen', side_effect=AssertionError('process forbidden')).start()

    def synthetic(self, *, mutation=None, error=None, calls=1, wrong_path=False):
        def run(*, evidence, _host_stage, **_):
            evidence.mkdir()
            run_id = uuid4()
            record = terminal(run_id)
            transport = CredentialSession(run_id, 'r7_05b3_'+run_id.hex, evidence,
                {role:'test-only-'+str(n)*40 for n,role in enumerate(('admin','migrator','writer','reader'),1)},record)
            for index in range(calls):
                _host_stage(run_id=run_id, record=record, transport=transport,
                            envfile=(self.root / 'wrong' if wrong_path else evidence / 'test-client.env'),
                            socket='socket', client='sha256:' + 'c' * 64,
                            server='server', database='database')
            transport._passwords.clear()
            transport.retired = True
            transport.activations = 2
            transport.client_stages = ['foundation','restart','b5-4-1']
            data = canonical(record)
            if mutation is not None:
                data = mutation(data, record)
            (evidence / 'run-manifest.json').write_bytes(data)
            if error is not None:
                raise error
        return run

    def invoke(self, run):
        with patch.object(runtime, 'run', side_effect=run), patch.object(controller, 'reporting_stage'):
            return controller.invoke_b5_4_1_and_admit(
                allow=True, wheelhouse=self.root, evidence=self.root / 'evidence')

    def test_one_invocation_and_immutable_snapshot(self):
        receipt = self.invoke(self.synthetic())
        self.assertIs(type(receipt), controller.VerifiedB541Manifest)
        self.assertEqual(receipt.sha256, hashlib.sha256(receipt.manifest_bytes).hexdigest())
        before = receipt.manifest_bytes
        (self.root / 'evidence/run-manifest.json').write_text('replacement')
        self.assertEqual(receipt.manifest_bytes, before)
        with self.assertRaises(AttributeError):
            receipt.manifest_bytes = b'forged'

    def test_same_length_mutation_denied(self):
        self.assertIsNone(self.invoke(self.synthetic(
            mutation=lambda data, _: data.replace(b'"source_commit": "a', b'"source_commit": "b', 1))))

    def test_cross_run_substitution_denied(self):
        def mutate(_, record):
            other = dict(record, run_id=str(uuid4()))
            return canonical(other)
        self.assertIsNone(self.invoke(self.synthetic(mutation=mutate)))

    def test_retained_record_mutation_denied(self):
        def mutate(data, record):
            record['source_commit'] = 'b' * 40
            return data
        self.assertIsNone(self.invoke(self.synthetic(mutation=mutate)))

    def test_publication_ambiguity_and_interrupts_deny(self):
        for cls in (OSError, RuntimeError, KeyboardInterrupt, SystemExit):
            with self.subTest(cls=cls), tempfile.TemporaryDirectory() as directory:
                self.root = Path(directory)
                with self.assertRaises(cls):
                    self.invoke(self.synthetic(error=cls('safe primary')))
                self.assertEqual(json.loads((self.root/'evidence/run-manifest.json').read_bytes())['result'], 'PASS')

    def test_missing_completion_callback_denied(self):
        self.assertIsNone(self.invoke(self.synthetic(calls=0)))

    def test_duplicate_callback_denied(self):
        with self.assertRaises(RuntimeError):
            self.invoke(self.synthetic(calls=2))

    def test_wrong_evidence_path_denied(self):
        with self.assertRaises(RuntimeError):
            self.invoke(self.synthetic(wrong_path=True))


    def test_schema_rejects_unknown_record_fields_and_raw_inspect(self):
        def mutate(_, record):
            record['unapproved'] = 'ENCODED_PRODUCER_TEXT'
            return canonical(record)
        self.assertIsNone(self.invoke(self.synthetic(mutation=mutate)))

    def test_schema_rejects_unknown_nested_inspect_fields(self):
        def mutate(_, record):
            record['server_inspect']['Config']['Labels']={'payload':'ENCODED_PRODUCER_TEXT'}
            return canonical(record)
        self.assertIsNone(self.invoke(self.synthetic(mutation=mutate)))

    def test_archive_and_boolean_are_not_admission(self):
        self.assertIsNone(controller.admit_archive_without_attestation(self.root/'PASS'))
        with self.assertRaises(TypeError):
            controller.invoke_b5_4_1_and_admit(allow=True, wheelhouse=self.root,
                evidence=self.root, run_completed=True)

    def test_reader_denies_fifo_symlink_oversize_and_missing(self):
        path = self.root/'run-manifest.json'
        self.assertIsNone(controller._read_manifest_bytes(path))
        os.mkfifo(path)
        self.assertIsNone(controller._read_manifest_bytes(path))
        path.unlink()
        target = self.root/'target'
        target.write_bytes(b'PASS')
        path.symlink_to(target)
        self.assertIsNone(controller._read_manifest_bytes(path))
        path.unlink()
        path.write_bytes(b'x' * (controller._MAX_MANIFEST_BYTES + 1))
        self.assertIsNone(controller._read_manifest_bytes(path))

    def test_cli_missing_receipt_cannot_succeed(self):
        argv = ['wrapper', '--allow-disposable-postgres', '--wheelhouse', str(self.root),
                '--evidence', str(self.root/'evidence')]
        with patch.object(sys, 'argv', argv), patch.object(
                controller, 'invoke_b5_4_1_and_admit', return_value=None):
            with self.assertRaises(SystemExit):
                wrapper.main()

    def test_cli_consumes_receipt_without_reopening(self):
        receipt = controller.VerifiedB541Manifest('run', 'digest', b'immutable', 'a'*40)
        argv = ['wrapper', '--allow-disposable-postgres', '--wheelhouse', str(self.root),
                '--evidence', str(self.root/'absent')]
        with patch.object(sys, 'argv', argv), patch.object(
                controller, 'invoke_b5_4_1_and_admit', return_value=receipt):
            self.assertIs(wrapper.main(), receipt.manifest_bytes)

    def test_single_runtime_identity(self):
        self.assertIs(controller.runtime, runtime)
        self.assertIs(reporting.command, runtime.command)
        self.assertIs(reporting.publish_stage_diagnostic, runtime.publish_stage_diagnostic)
        self.assertIs(reporting.reporting_stage.__globals__['publish_stage_diagnostic'].__globals__['_LIFECYCLE'],
                      runtime._LIFECYCLE)


class RuntimeTests(unittest.TestCase):
    setUp = AdmissionTests.setUp
    def fixture(self, *, output='SPLIT_AND_ENCODED_PRIVATE_OUTPUT', fault=None,
                publisher=None, cleanup=True, secret=False, handler_failure=False):
        observed = dict(removals=[], commands=[], records=[], restored=[])
        patch.object(runtime, 'verified_clean_source', return_value='a'*40).start()
        patch.object(runtime, 'inspect_image', return_value={}).start()
        patch.object(runtime, 'build_client', return_value='sha256:'+'c'*64).start()
        class SyntheticSupervisor:
            confirmed=False
            def __init__(self,*args):pass
            def start(self):pass
            def check_live(self):pass
            def finish(self,settled):
                self.confirmed=settled is True
                return 'CONFIRMED' if self.confirmed else 'UNCONFIRMED'
            def abandon(self):pass
        patch.object(runtime,'CleanupSupervisor',SyntheticSupervisor).start()
        def activate(session,server,**kwargs):
            session.activations+=1
            session._lifecycle['creation_attempts'].append(dict(kind='container',name=server,state='RETURNED'))
        patch.object(CredentialSession,'activate',activate).start()
        patch.object(CredentialSession,'reap_activation',lambda *a,**kw:None).start()
        patch.object(runtime.secrets,'token_bytes',return_value=b'0123456789abcdef').start()

        patch.object(runtime.signal, 'getsignal', return_value=signal.SIG_DFL).start()
        def handler(sig, value):
            observed['restored'].append(value)
            if handler_failure and value == signal.SIG_DFL:
                raise OSError('restoration failed')
        patch.object(runtime.signal, 'signal', side_effect=handler).start()
        def remove(kind, name, run_id):
            observed['removals'].append((kind,name))
            return cleanup
        patch.object(runtime, 'remove_owned', side_effect=remove).start()
        def command(args, **kwargs):
            observed['commands'].append(args)
            result = SimpleNamespace(returncode=0, stdout='', stderr='')
            if args[:3] == ['docker','volume','inspect']:
                return SimpleNamespace(returncode=1, stdout='', stderr='no such volume')
            if args[:2] == ['docker','inspect']:
                result.stdout = json.dumps([{'Config':{'Env':['UNKNOWN='+output]}}])
            elif args[:2] == ['docker','exec']:
                result.stdout = 'postgres' if args[-2:] == ['/proc/1/comm'] else output
                if args[-1] == '/proc/1/comm':
                    result.stdout = 'postgres'
            elif args[:2] == ['docker','run'] and '/code/tests/postgres/credential_test_client.py' in args:
                if args[args.index('--name')+1].endswith('-b5-4-1'):
                    observed['records'].append(runtime._LIFECYCLE.get())
                    if fault is not None:
                        raise fault
                result.stdout = runtime._TEST_SECRETS.get()[0] if secret else output
                result.stderr = output
            return result
        patch.object(runtime, 'command', side_effect=command).start()
        # Reporting references the SAME mocked command for this synthetic run.
        patch.object(reporting, 'command', runtime.command).start()
        if publisher is not None:
            patch.object(runtime, 'publish_terminal_manifest', side_effect=publisher).start()
        return observed

    def test_actual_runtime_reporting_success_withholds_all_producer_output(self):
        observed = self.fixture()
        console = io.StringIO()
        with contextlib.redirect_stdout(console), contextlib.redirect_stderr(console):
            receipt = controller.invoke_b5_4_1_and_admit(
                allow=True, wheelhouse=self.root, evidence=self.root/'evidence')
        self.assertIsNotNone(receipt)
        for path in (self.root/'evidence').iterdir():
            if path.is_file():
                self.assertNotIn(b'SPLIT_AND_ENCODED_PRIVATE_OUTPUT', path.read_bytes())
        self.assertNotIn('PRIVATE_OUTPUT', console.getvalue())
        self.assertIsNone(runtime._LIFECYCLE.get())
        self.assertEqual(runtime._TEST_SECRETS.get(), ())
        self.assertFalse((self.root/'evidence/test-client.env').exists())
        self.assertTrue(any(name.endswith('-b5-4-1') for _,name in observed['removals']))

    def test_primary_interrupts_reconcile_and_deny(self):
        for cls in (RuntimeError, KeyboardInterrupt, SystemExit):
            with self.subTest(cls=cls), tempfile.TemporaryDirectory() as directory:
                self.root = Path(directory)
                with contextlib.ExitStack() as stack:
                    # fixture patches are stopped between cases by this explicit boundary.
                    observed = self.fixture(fault=cls('safe stage fault'))
                    with self.assertRaises(cls):
                        controller.invoke_b5_4_1_and_admit(
                            allow=True, wheelhouse=self.root, evidence=self.root/'evidence')
                    manifest = json.loads((self.root/'evidence/run-manifest.json').read_bytes())
                    self.assertEqual(manifest['result'],'FAILED')
                    self.assertTrue(any(name.endswith('-b5-4-1') for _,name in observed['removals']))
                    self.assertFalse((self.root/'evidence/test-client.env').exists())
                    self.assertIsNone(runtime._LIFECYCLE.get())
                    self.assertEqual(runtime._TEST_SECRETS.get(), ())
                patch.stopall()

    def test_unconfirmed_cleanup_outranks_primary_and_publisher(self):
        primary = ValueError('safe primary')
        self.fixture(fault=primary, cleanup=False,
                     publisher=OSError('UNSAFE_PUBLISHER_TOKEN'))
        with self.assertRaises(runtime.CleanupUnconfirmed) as caught:
            controller.invoke_b5_4_1_and_admit(
                allow=True, wheelhouse=self.root, evidence=self.root/'evidence')
        self.assertNotIn('UNSAFE_PUBLISHER_TOKEN', repr(caught.exception))
        self.assertIs(caught.exception.__context__, primary)
        self.assertIsNone(caught.exception.__cause__)
        graph = [caught.exception]
        seen = set()
        while graph:
            error = graph.pop()
            if id(error) in seen:
                continue
            seen.add(id(error))
            self.assertNotIn('UNSAFE_PUBLISHER_TOKEN', repr(error.args))
            self.assertNotIn('UNSAFE_PUBLISHER_TOKEN', repr(vars(error)))
            graph.extend(item for item in (error.__context__, error.__cause__) if item is not None)
        self.assertNotIn('UNSAFE_PUBLISHER_TOKEN', ''.join(traceback.format_exception(caught.exception)))


    def test_confirmed_cleanup_preserves_safe_primary_over_unsafe_publisher(self):
        primary = ValueError('safe primary')
        self.fixture(fault=primary,publisher=OSError('UNSAFE_PUBLISHER_TOKEN'))
        with self.assertRaises(ValueError) as caught:
            controller.invoke_b5_4_1_and_admit(
                allow=True,wheelhouse=self.root,evidence=self.root/'evidence')
        self.assertIs(caught.exception,primary)
        self.assertIsNone(caught.exception.__context__)
        self.assertNotIn('UNSAFE_PUBLISHER_TOKEN',''.join(traceback.format_exception(caught.exception)))

    def test_standalone_unsafe_publisher_is_fixed_oserror(self):
        self.fixture(publisher=ValueError('UNSAFE_PUBLISHER_TOKEN'))
        with self.assertRaises(OSError) as caught:
            controller.invoke_b5_4_1_and_admit(
                allow=True,wheelhouse=self.root,evidence=self.root/'evidence')
        self.assertIsNone(caught.exception.__context__)
        self.assertIsNone(caught.exception.__cause__)
        self.assertNotIn('UNSAFE_PUBLISHER_TOKEN',repr(vars(caught.exception)))
        self.assertNotIn('UNSAFE_PUBLISHER_TOKEN',''.join(traceback.format_exception(caught.exception)))

    def test_credential_unlink_failure_denies(self):
        self.fixture()
        with patch.object(runtime,'remove_transient_credential_file',return_value='UNCONFIRMED'):
            with self.assertRaises(runtime.CleanupUnconfirmed):
                controller.invoke_b5_4_1_and_admit(
                    allow=True,wheelhouse=self.root,evidence=self.root/'evidence')
        self.assertEqual(json.loads((self.root/'evidence/run-manifest.json').read_bytes())[
            'credential_file_cleanup'],'UNCONFIRMED')

    def test_exact_secret_observation_rejects_admission(self):
        self.fixture(secret=True)
        with self.assertRaises(runtime.CleanupUnconfirmed):
            controller.invoke_b5_4_1_and_admit(
                allow=True, wheelhouse=self.root, evidence=self.root/'evidence')
        record = json.loads((self.root/'evidence/run-manifest.json').read_bytes())
        self.assertGreater(record['secret_redactions'], 0)
        self.assertEqual(record['result'], 'FAILED')
        self.assertNotIn('test-only-', json.dumps(record))

    def test_partial_stdout_and_stderr_are_unavailable(self):
        original = runtime.write_evidence
        for suffix in ('stdout','stderr'):
            with self.subTest(suffix=suffix), tempfile.TemporaryDirectory() as directory:
                self.root = Path(directory)
                self.fixture()
                def write(path, text):
                    if path.name == 'b5-4-1.'+suffix:
                        path.write_text('PARTIAL_FIXED_MARKER')
                        raise KeyboardInterrupt('safe output interruption')
                    return original(path,text)
                with patch.object(runtime,'write_evidence',side_effect=write):
                    with self.assertRaises(KeyboardInterrupt):
                        controller.invoke_b5_4_1_and_admit(
                            allow=True,wheelhouse=self.root,evidence=self.root/'evidence')
                record=json.loads((self.root/'evidence/run-manifest.json').read_bytes())
                self.assertEqual(record['result'],'FAILED')
                self.assertEqual(record['evidence_status'],'EVIDENCE_UNAVAILABLE')
                self.assertFalse((self.root/'evidence/test-client.env').exists())
                patch.stopall()

    def test_credential_unlink_and_handler_failure_deny(self):
        self.fixture(handler_failure=True)
        with self.assertRaises(runtime.CleanupUnconfirmed):
            controller.invoke_b5_4_1_and_admit(
                allow=True,wheelhouse=self.root,evidence=self.root/'evidence')
        self.assertIsNone(runtime._LIFECYCLE.get())
        self.assertFalse((self.root/'evidence/test-client.env').exists())

    def test_unsafe_image_json_has_no_raw_public_exception(self):
        with patch.object(runtime,'command', return_value=SimpleNamespace(stdout='CREDENTIAL_IN_JSON')):
            with self.assertRaises(RuntimeError) as caught:
                runtime.inspect_image(runtime.POSTGRES)
        self.assertIsNone(caught.exception.__context__)
        self.assertIsNone(caught.exception.__cause__)
        self.assertNotIn('CREDENTIAL_IN_JSON',repr(caught.exception))
        self.assertFalse(hasattr(caught.exception,'doc'))


    def test_original_unexpected_manifest_secret_finalization_path(self):
        tick = [0]
        def clock():
            tick[0] += 1
            return tick[0]
        patch.object(runtime,'time',SimpleNamespace(monotonic=clock,sleep=lambda _:None)).start()
        patch.object(runtime,'verified_clean_source',return_value='a'*40).start()
        patch.object(runtime.signal,'getsignal',return_value=signal.SIG_DFL).start()
        patch.object(runtime.signal,'signal',return_value=None).start()
        captured = {}
        name = 'r7-05b3-'+uuid4().hex+'-synthetic'
        def stop(identity):
            record = runtime._LIFECYCLE.get()
            captured['record'] = record
            record['creation_attempts'].append(dict(kind='container',name=name,state='RETURNED'))
            record['unexpected_metadata']={'custom_field':runtime._TEST_SECRETS.get()[0]}
            raise RuntimeError('synthetic preflight stop: no Docker used')
        patch.object(runtime,'inspect_image',side_effect=stop).start()
        patch.object(runtime,'remove_owned',return_value=True).start()
        patch.object(runtime,'command',return_value=SimpleNamespace(stdout='')).start()
        with self.assertRaises(runtime.CleanupUnconfirmed):
            runtime.run(allow=True,wheelhouse=self.root,evidence=self.root/'evidence')
        record=json.loads((self.root/'evidence/run-manifest.json').read_bytes())
        self.assertEqual(record['result'],'FAILED')
        self.assertFalse(record['cleanup_passed'])
        self.assertEqual(record['cleanup_status'],'CLEANUP_UNCONFIRMED')
        self.assertEqual(record['error_type'],'RuntimeError')
        self.assertEqual(record['unexpected_metadata']['custom_field'],'<redacted-disposable-secret>')
        self.assertGreater(record['secret_redactions'],0)
        self.assertEqual(captured['record'],record)
        self.assertIsNone(runtime._LIFECYCLE.get())
        self.assertEqual(runtime._TEST_SECRETS.get(),())

    def test_unknown_inventory_text_is_not_published(self):
        self.assertEqual(runtime._inventory_summary('UNTRUSTED_ENCODED_TEXT',[]),'UNAVAILABLE')

    def test_inspect_split_names_and_values_are_omitted(self):
        value = runtime.parse_disposable_inspect_metadata(json.dumps([{
            'Config':{'Env':['PART_ONE=secret-first','PART_TWO=secret-last',
                             'R7_PG_ADMIN_PASSWORD=secret']},
            'Labels':{'payload':'secret'}}]))
        self.assertEqual(value, {'Config':{'Env':['R7_PG_ADMIN_PASSWORD=<test-secret>']}})


# P1-J additions: explicit historical provenance and operational contracts.
import ast
from collections import Counter
from copy import deepcopy
import inspect
import runpy

RUNTIME_DIR = Path(__file__).resolve().parent
HISTORICAL = RUNTIME_DIR / 'fixtures/f04_p1f'
DIRECT_ASSERTION_NAMES = []


def _git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()


def _pinned_bytes(path, identity):
    data = path.read_bytes()
    assert _git_blob(data) == identity, 'historical/candidate source identity mismatch'
    return data


def _function(tree, name):
    return next(node for node in tree.body
                if isinstance(node, ast.FunctionDef) and node.name == name)


def _calls(tree, name):
    return Counter(ast.dump(node, include_attributes=False) for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == name)


def _source_function_context(path, names, extra=None):
    """Execute selected pure source-assertion functions; this is NOT pytest."""
    tree = ast.parse(path.read_text())
    selected = [node for node in tree.body
                if isinstance(node, ast.FunctionDef) and node.name in names]
    assert len(selected) == len(names)
    assert all(not node.decorator_list for node in selected)
    namespace = dict(__file__=str(path), Path=Path, ast=ast, hashlib=hashlib)
    if extra:
        namespace.update(extra)
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace


def _operational_stage_expected():
    source = _pinned_bytes(POSTGRES/'run_b5_4_1_reporting_stage_candidate.py',
                           '5a82cb0219948c0b895f92b603252a547957bed7')
    expected = ast.parse(source.decode('utf-8'))
    # Exactly enumerated source deltas, never a general AST normalization.
    assert isinstance(expected.body[0], ast.Expr)
    expected.body[0].value.value = (
        'Fixed B5-4-1 reporting stage; shared corrected runtime, minimized output.')
    global_imports = [node for node in expected.body if isinstance(node, ast.ImportFrom)
                      and node.module == 'run_postgres_security_patch_candidate']
    assert len(global_imports) == 1
    global_imports[0].module = 'run_postgres'
    global_imports[0].names.append(ast.alias(name='publish_stage_diagnostic'))
    function = _function(expected, 'reporting_stage')
    lifecycle_imports = [node for node in function.body if isinstance(node, ast.ImportFrom)
                         and node.module == 'run_postgres_security_patch_candidate']
    assert len(lifecycle_imports) == 1
    assert [node.name for node in lifecycle_imports[0].names] == ['_LIFECYCLE']
    lifecycle_imports[0].module = 'run_postgres'
    guards = [node for node in function.body if isinstance(node, ast.Try)]
    assert len(guards) == 1
    guard = guards[0]
    old_writes = ast.parse(
        "write_evidence(evidence_dir/'b5-4-1.stdout', result.stdout)\n"
        "write_evidence(evidence_dir/'b5-4-1.stderr', result.stderr)\n").body
    assert [ast.dump(n) for n in guard.body] == [ast.dump(n) for n in old_writes]
    guard.body = ast.parse(
        "publish_stage_diagnostic(evidence_dir, 'b5-4-1', result)").body
    for text in (
        "print(redact_test_secrets(result.stdout), flush=True)",
        "print(redact_test_secrets(result.stderr), flush=True)",
    ):
        target = ast.dump(ast.parse(text).body[0])
        matches = [i for i, node in enumerate(function.body) if ast.dump(node) == target]
        assert len(matches) == 1
        del function.body[matches[0]]
    # P1-K3: exactly the bounded-stdin transport deltas, after the P1-J deltas.
    fn = _function(expected, 'reporting_stage')
    where = next(i for i,a in enumerate(fn.args.kwonlyargs) if a.arg == 'envfile')
    fn.args.kwonlyargs.insert(where+1, ast.arg(arg='transport'))
    fn.args.kw_defaults.insert(where+1, None)
    isolation = next(n for n in fn.body if isinstance(n,ast.Assign)
        and any(isinstance(t,ast.Name) and t.id=='isolation' for t in n.targets))
    isolation.value.elts[:0] = ast.parse("['--log-driver=none','--ulimit','core=0:0']",mode='eval').body.elts
    args = next(n for n in fn.body if isinstance(n,ast.Assign)
        and any(isinstance(t,ast.Name) and t.id=='args' for t in n.targets))
    args.value.elts.insert(2,ast.Constant(value='-i'))
    index=next(i for i,n in enumerate(args.value.elts) if isinstance(n,ast.Constant) and n.value=='--env-file')
    assert ast.dump(args.value.elts[index+1])==ast.dump(ast.parse('str(envfile)',mode='eval').body)
    del args.value.elts[index:index+2]
    index=next(i for i,n in enumerate(args.value.elts) if isinstance(n,ast.Constant) and n.value=='--entrypoint')
    args.value.elts[index:]=ast.parse("['--entrypoint','python',client,'/code/tests/postgres/credential_test_client.py','b5-4-1']",mode='eval').body.elts
    result=next(n for n in fn.body if isinstance(n,ast.Assign)
        and any(isinstance(t,ast.Name) and t.id=='result' for t in n.targets))
    result.value.keywords.append(ast.keyword(arg='stdin',value=ast.parse("transport.client_frame('b5-4-1')",mode='eval').body))
    return expected


def _assert_operational_stage(actual):
    expected = _operational_stage_expected()
    assert ast.dump(actual, include_attributes=False) == ast.dump(expected, include_attributes=False)


class ProvenanceTransitionTests(unittest.TestCase):
    setUp = AdmissionTests.setUp

    def test_fixture_authenticity_and_tamper_denial(self):
        for name, identity in (
            ('run_postgres.py.txt','0863e81b733381a80b2f83560d8bbc231513ba41'),
            ('run_b5_4_1_postgres.py.txt','040d0d30bb719d646eb350b229ccd9a4c5f2bf79'),
        ):
            with self.subTest(name=name):
                data = _pinned_bytes(HISTORICAL/name, identity)
                changed = self.root/'changed.txt'
                changed.write_bytes(data + b'\n')
                with self.assertRaises(AssertionError):
                    _pinned_bytes(changed, identity)

    def test_existing_frozen_wrapper_assertions_direct(self):
        name = 'test_existing_operational_wrapper_is_still_frozen_source_and_not_candidate'
        path = RUNTIME_DIR/'test_r7_05b5_4_1_f04_r2_04_controller_binding.py'
        namespace = _source_function_context(path, {'_historical_wrapper_text',name})
        namespace[name]()
        DIRECT_ASSERTION_NAMES.append(name)

    def test_existing_candidate_reporting_parity_assertions_direct(self):
        name = 'test_real_reporting_stage_candidate_source_parity'
        path = RUNTIME_DIR/'test_r7_05b5_4_1_f04_r2_04_r4_actual_reporting_stage.py'
        candidate_stage = importlib.import_module('run_b5_4_1_reporting_stage_candidate')
        namespace = _source_function_context(path, {'_historical_wrapper_text',name},
            dict(PGDIR=POSTGRES, TESTS=reporting.TESTS))
        namespace[name]((None,None,None,candidate_stage,None,None))
        DIRECT_ASSERTION_NAMES.append(name)

    def test_existing_six_runner_parity_tests_direct(self):
        path = RUNTIME_DIR/'test_r7_05b5_4_1_f04_fork_ast_operational_parity.py'
        namespace = runpy.run_path(str(path))
        names = sorted(name for name in namespace if name.startswith('test_'))
        self.assertEqual(len(names),6)
        for name in names:
            with self.subTest(name=name):
                namespace[name]()
                DIRECT_ASSERTION_NAMES.append(name)

    def test_operational_reporting_module_has_only_exact_approved_deltas(self):
        _assert_operational_stage(ast.parse((POSTGRES/'run_b5_4_1_reporting_stage.py').read_text()))

    def test_operational_parity_rejects_extra_changes(self):
        original = ast.parse((POSTGRES/'run_b5_4_1_reporting_stage.py').read_text())
        for change in ('selector','raw_print','handler','ownership','import','extra_function'):
            with self.subTest(change=change):
                altered = deepcopy(original)
                function = _function(altered,'reporting_stage')
                if change == 'selector':
                    assignment = next(n for n in altered.body if isinstance(n,ast.Assign)
                        and any(isinstance(t,ast.Name) and t.id=='TESTS' for t in n.targets))
                    assignment.value.elts[0].value = 'tests/postgres/unapproved.py'
                elif change == 'raw_print':
                    function.body.append(ast.parse('print(result.stdout)').body[0])
                elif change == 'handler':
                    next(n for n in function.body if isinstance(n,ast.Try)).handlers[0].type.id='Exception'
                elif change == 'ownership':
                    call = next(n for n in ast.walk(function) if isinstance(n,ast.Call)
                        and isinstance(n.func,ast.Attribute) and n.func.attr=='append'
                        and isinstance(n.func.value,ast.Name) and n.func.value.id=='created')
                    call.args=[ast.Constant(value='foreign')]
                elif change == 'import':
                    next(n for n in altered.body if isinstance(n,ast.ImportFrom)
                        and n.module=='run_postgres').module='run_postgres_security_patch_candidate'
                else:
                    altered.body.append(ast.parse('def unexpected():\n    return None').body[0])
                with self.assertRaises(AssertionError):
                    _assert_operational_stage(altered)

    def test_unchanged_operational_helper_asts_remain_exact(self):
        historical = ast.parse(_pinned_bytes(HISTORICAL/'run_postgres.py.txt',
            '0863e81b733381a80b2f83560d8bbc231513ba41').decode())
        actual = ast.parse((POSTGRES/'run_postgres.py').read_text())
        for name in ('build_client','verified_clean_source'):
            with self.subTest(name=name):
                self.assertEqual(ast.dump(_function(historical,name)),
                                 ast.dump(_function(actual,name)))

    def test_operational_pins_selectors_and_scoped_deletion_calls(self):
        historical = ast.parse(_pinned_bytes(HISTORICAL/'run_postgres.py.txt',
            '0863e81b733381a80b2f83560d8bbc231513ba41').decode())
        candidate = ast.parse(_pinned_bytes(POSTGRES/'run_postgres_security_patch_candidate.py',
            '54fbe8292f7e8054ff682cadb97812683992cd1e').decode())
        actual = ast.parse((POSTGRES/'run_postgres.py').read_text())
        for name in ('BASE','POSTGRES','WHEEL','WHEEL_SHA256'):
            def value(tree):
                return next(ast.literal_eval(n.value) for n in tree.body
                    if isinstance(n,ast.Assign)
                    and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
            self.assertEqual(value(historical),value(actual))
        # P1-K3 exact credential command deltas; all other command ASTs equal.
        actual_calls=_calls(_function(actual,'run'),'command')
        old_calls=_calls(_function(candidate,'run'),'command')
        self.assertEqual(actual_calls-old_calls,Counter({"Call(func=Name(id='command', ctx=Load()), args=[Name(id='args', ctx=Load())], keywords=[keyword(arg='timeout', value=Constant(value=240)), keyword(arg='check', value=Constant(value=False)), keyword(arg='stdin', value=Call(func=Attribute(value=Name(id='transport', ctx=Load()), attr='client_frame', ctx=Load()), args=[Name(id='stage', ctx=Load())], keywords=[]))])": 1, "Call(func=Name(id='command', ctx=Load()), args=[List(elts=[Constant(value='docker'), Constant(value='stop'), Constant(value='--time=5'), Name(id='server', ctx=Load())], ctx=Load())], keywords=[keyword(arg='timeout', value=Constant(value=20))])": 2}))
        self.assertEqual(old_calls-actual_calls,Counter({"Call(func=Name(id='command', ctx=Load()), args=[List(elts=[Constant(value='docker'), Constant(value='exec'), Constant(value='-i'), Constant(value='-e'), BinOp(left=Constant(value='PGPASSWORD='), op=Add(), right=Subscript(value=Name(id='passwords', ctx=Load()), slice=Constant(value='admin'), ctx=Load())), Name(id='server', ctx=Load()), Constant(value='psql'), Constant(value='-h'), Constant(value='/var/run/postgresql'), Constant(value='-U'), Constant(value='r7_test_owner'), Constant(value='-d'), Name(id='database', ctx=Load()), Constant(value='-v'), Constant(value='ON_ERROR_STOP=1'), Constant(value='-v'), BinOp(left=Constant(value='test_database='), op=Add(), right=Name(id='database', ctx=Load())), Constant(value='-v'), BinOp(left=Constant(value='test_identity=r7_05b3_disposable:'), op=Add(), right=Call(func=Name(id='str', ctx=Load()), args=[Name(id='run_id', ctx=Load())], keywords=[])), Starred(value=Name(id='variables', ctx=Load()), ctx=Load())], ctx=Load())], keywords=[keyword(arg='stdin', value=Call(func=Attribute(value=BinOp(left=Name(id='ROOT', ctx=Load()), op=Div(), right=Constant(value='tests/postgres/bootstrap.sql')), attr='read_text', ctx=Load()), args=[], keywords=[]))])": 1, "Call(func=Name(id='command', ctx=Load()), args=[Name(id='args', ctx=Load())], keywords=[keyword(arg='timeout', value=Constant(value=240)), keyword(arg='check', value=Constant(value=False))])": 1, "Call(func=Name(id='command', ctx=Load()), args=[List(elts=[Constant(value='docker'), Constant(value='exec'), Constant(value='-e'), BinOp(left=Constant(value='PGPASSWORD='), op=Add(), right=Subscript(value=Name(id='passwords', ctx=Load()), slice=Constant(value='admin'), ctx=Load())), Name(id='server', ctx=Load()), Constant(value='psql'), Constant(value='-h'), Constant(value='/var/run/postgresql'), Constant(value='-U'), Constant(value='r7_test_owner'), Constant(value='-d'), Name(id='database', ctx=Load()), Constant(value='-At'), Constant(value='-c'), Constant(value='SELECT current_database(),current_user,version(),system_identifier FROM pg_control_system()')], ctx=Load())], keywords=[keyword(arg='check', value=Constant(value=False))])": 1, "Call(func=Name(id='command', ctx=Load()), args=[List(elts=[Constant(value='docker'), Constant(value='restart'), Constant(value='--time=5'), Name(id='server', ctx=Load())], ctx=Load())], keywords=[keyword(arg='timeout', value=Constant(value=20))])": 1}))
        self.assertEqual(_calls(_function(actual,'run'),'remove_owned'),
                         _calls(_function(historical,'run'),'remove_owned'))
        expected_call = ast.parse('remove_transient_credential_file(envfile)').body[0].value
        self.assertEqual(_calls(_function(actual,'run'),'remove_transient_credential_file'),
                         Counter({ast.dump(expected_call):2}))
        guards = [n for n in ast.walk(_function(actual,'run'))
            if isinstance(n,ast.If) and ast.dump(n.test)==ast.dump(
                ast.parse('not credential_cleanup_attempted',mode='eval').body)]
        self.assertEqual(len(guards),1)
        self.assertEqual(_calls(guards[0],'remove_transient_credential_file'),
                         Counter({ast.dump(expected_call):1}))

    def test_positive_operational_binding_and_no_candidate_imports(self):
        self.assertIs(wrapper.controller,controller)
        self.assertIs(controller.runtime,runtime)
        self.assertIs(reporting.command,runtime.command)
        self.assertIs(reporting.publish_stage_diagnostic,runtime.publish_stage_diagnostic)
        self.assertIs(reporting.publish_stage_diagnostic.__globals__['_LIFECYCLE'],runtime._LIFECYCLE)
        self.assertIs(reporting.publish_stage_diagnostic.__globals__['_TEST_SECRETS'],runtime._TEST_SECRETS)
        parameters=inspect.signature(controller.invoke_b5_4_1_and_admit).parameters
        self.assertEqual(set(parameters),{'allow','wheelhouse','evidence'})
        for module in (runtime,reporting,controller,wrapper):
            for node in ast.walk(ast.parse(Path(module.__file__).read_text())):
                if isinstance(node,ast.ImportFrom):
                    self.assertNotIn('_candidate',node.module or '')
                elif isinstance(node,ast.Import):
                    self.assertTrue(all('_candidate' not in alias.name for alias in node.names))


def _assert_no_marker(test, error, marker):
    queue=[error]
    seen=set()
    while queue:
        current=queue.pop()
        if id(current) in seen:
            continue
        seen.add(id(current))
        for name in ('args','doc','obj','object','filename','filename2','stdout','stderr','output'):
            test.assertNotIn(marker,repr(getattr(current,name,None)))
        test.assertNotIn(marker,repr(vars(current)))
        queue.extend(item for item in (current.__context__,current.__cause__) if item is not None)
    test.assertNotIn(marker,''.join(traceback.format_exception(error)))


class ChangedHelperSemanticTests(unittest.TestCase):
    setUp = AdmissionTests.setUp

    def test_inspect_image_valid_fixed_identity_and_platform(self):
        image={'Id':runtime.POSTGRES,'Os':'linux','Architecture':'amd64'}
        with patch.object(runtime,'command',return_value=SimpleNamespace(stdout=json.dumps([image]))) as command:
            self.assertEqual(runtime.inspect_image(runtime.POSTGRES),image)
        command.assert_called_once_with(['docker','image','inspect',runtime.POSTGRES])

    def test_inspect_image_rejects_shapes_identity_and_platform_without_disclosure(self):
        marker='PRIVATE_SCHEMA_MARKER'
        valid=dict(Id=runtime.POSTGRES,Os='linux',Architecture='amd64')
        shapes=[{},None,[],[valid,valid],[marker],[{}],
            [dict(valid,Id='sha256:'+'0'*64)],[dict(valid,Os=marker)],
            [dict(valid,Architecture=marker)],[dict(valid,Id={'payload':marker})]]
        for shape in shapes:
            with self.subTest(shape_type=type(shape).__name__), patch.object(runtime,'command',
                    return_value=SimpleNamespace(stdout=json.dumps(shape))):
                with self.assertRaises(ValueError) as caught:
                    runtime.inspect_image(runtime.POSTGRES)
                _assert_no_marker(self,caught.exception,marker)
        for raw in (marker,b'\xff'+marker.encode()):
            with self.subTest(raw_type=type(raw).__name__), patch.object(runtime,'command',
                    return_value=SimpleNamespace(stdout=raw)):
                with self.assertRaises(RuntimeError) as caught:
                    runtime.inspect_image(runtime.POSTGRES)
                _assert_no_marker(self,caught.exception,marker)

    def test_inspect_image_rejects_unsupported_identity_syntax(self):
        image=dict(Id='sha256:short',Os='linux',Architecture='amd64')
        with patch.object(runtime,'command',return_value=SimpleNamespace(stdout=json.dumps([image]))):
            with self.assertRaises(ValueError):
                runtime.inspect_image('sha256:short')

    def test_remove_owned_container_and_volume_delete_only_matching_label(self):
        run_id=uuid4()
        name='r7-05b3-'+run_id.hex+'-owned'
        for kind in ('container','volume'):
            metadata={'Config':{'Labels':{'r7_05b3_run':str(run_id)}}} if kind=='container' else {
                'Labels':{'r7_05b3_run':str(run_id)}}
            responses=[SimpleNamespace(returncode=0,stdout=json.dumps([metadata]),stderr=''),
                       SimpleNamespace(returncode=0,stdout='',stderr='')]
            with self.subTest(kind=kind),patch.object(runtime,'command',side_effect=responses) as command:
                self.assertIs(runtime.remove_owned(kind,name,run_id),True)
                expected=['docker','rm','-f',name] if kind=='container' else ['docker','volume','rm',name]
                self.assertEqual(command.call_args_list[0].args[0],['docker',kind,'inspect',name])
                self.assertEqual(command.call_args_list[1].args[0],expected)
                self.assertEqual(command.call_count,2)

    def test_remove_owned_foreign_missing_and_malformed_metadata_never_deletes(self):
        run_id=uuid4()
        name='r7-05b3-'+run_id.hex+'-owned'
        for kind in ('container','volume'):
            metadata=[]
            for labels in ({'r7_05b3_run':str(uuid4())},{},None,[], 'PRIVATE_SCHEMA_MARKER'):
                metadata.append([{'Config':{'Labels':labels}}] if kind=='container' else [{'Labels':labels}])
            metadata.extend(([],[{},{}],[None],{},[{'Config':None}], [{}]))
            for value in metadata:
                with self.subTest(kind=kind,shape=type(value).__name__),patch.object(runtime,'command',
                        return_value=SimpleNamespace(returncode=0,stdout=json.dumps(value),stderr='')) as command:
                    self.assertIs(runtime.remove_owned(kind,name,run_id),False)
                    self.assertEqual(command.call_count,1)
            with patch.object(runtime,'command',return_value=SimpleNamespace(
                    returncode=0,stdout='PRIVATE_SCHEMA_MARKER',stderr='')) as command:
                with self.assertRaises(RuntimeError) as caught:
                    runtime.remove_owned(kind,name,run_id)
                _assert_no_marker(self,caught.exception,'PRIVATE_SCHEMA_MARKER')
                self.assertEqual(command.call_count,1)

    def test_remove_owned_unknown_inventory_and_failed_deletion_fail_closed(self):
        run_id=uuid4()
        for kind in ('container','volume'):
            for stderr,expected in (('daemon unavailable',False),('no such '+kind,True)):
                with self.subTest(kind=kind,stderr=stderr),patch.object(runtime,'command',
                        return_value=SimpleNamespace(returncode=1,stdout='',stderr=stderr)) as command:
                    self.assertIs(runtime.remove_owned(kind,'owned',run_id),expected)
                    self.assertEqual(command.call_count,1)
            metadata={'Config':{'Labels':{'r7_05b3_run':str(run_id)}}} if kind=='container' else {
                'Labels':{'r7_05b3_run':str(run_id)}}
            with patch.object(runtime,'command',side_effect=[
                    SimpleNamespace(returncode=0,stdout=json.dumps([metadata]),stderr=''),
                    SimpleNamespace(returncode=1,stdout='',stderr='delete failed')]) as command:
                self.assertIs(runtime.remove_owned(kind,'owned',run_id),False)
                self.assertEqual(command.call_count,2)


class CredentialAttemptTests(unittest.TestCase):
    setUp = AdmissionTests.setUp
    fixture = RuntimeTests.fixture

    def test_single_attempt_target_across_normal_failure_reconciliation_and_interruptions(self):
        original_remove=runtime.remove_transient_credential_file
        cases=(
            ('normal',None,None),
            ('primary_failure',RuntimeError,RuntimeError),
            ('primary_keyboard',KeyboardInterrupt,KeyboardInterrupt),
            ('primary_systemexit',SystemExit,SystemExit),
            ('cleanup_unconfirmed',None,runtime.CleanupUnconfirmed),
            ('reconciliation_keyboard',None,KeyboardInterrupt),
            ('reconciliation_systemexit',None,SystemExit),
            ('inventory_keyboard',None,KeyboardInterrupt),
            ('unlink_failure',None,OSError),
            ('unlink_keyboard',None,KeyboardInterrupt),
            ('unlink_unexpected_return',None,runtime.CleanupUnconfirmed),
            ('deferred_sigterm',None,KeyboardInterrupt),
            ('post_unlink_keyboard',None,KeyboardInterrupt),
        )
        for name,primary,expected_error in cases:
            with self.subTest(path=name),tempfile.TemporaryDirectory() as directory,patch.object(
                    subprocess,'Popen',side_effect=AssertionError('process forbidden')):
                self.root=Path(directory)
                envfile=self.root/'evidence/test-client.env'
                calls=[]
                observed=self.fixture(fault=primary('safe primary') if primary else None,
                                      cleanup=name!='cleanup_unconfirmed')
                if name.startswith('reconciliation_'):
                    cls=KeyboardInterrupt if name.endswith('keyboard') else SystemExit
                    patch.object(runtime,'remove_owned',side_effect=cls('safe reconcile interruption')).start()
                if name=='inventory_keyboard':
                    fake_command=runtime.command
                    def command(args,**kwargs):
                        if args[:2]==['docker','ps']:
                            raise KeyboardInterrupt('safe inventory interruption')
                        return fake_command(args,**kwargs)
                    patch.object(runtime,'command',side_effect=command).start()
                def remove(path):
                    calls.append(path)
                    if name=='unlink_failure':
                        raise OSError('safe unlink failure')
                    if name=='unlink_keyboard':
                        raise KeyboardInterrupt('safe unlink interruption')
                    if name=='unlink_unexpected_return':
                        return object()
                    if name=='deferred_sigterm':
                        observed['restored'][0](signal.SIGTERM,None)
                    status=original_remove(path)
                    if name=='post_unlink_keyboard':
                        raise KeyboardInterrupt('safe post-unlink interruption')
                    return status
                patch.object(runtime,'remove_transient_credential_file',side_effect=remove).start()
                try:
                    if expected_error:
                        with self.assertRaises(expected_error):
                            controller.invoke_b5_4_1_and_admit(
                                allow=True,wheelhouse=self.root,evidence=self.root/'evidence')
                    else:
                        self.assertIsNotNone(controller.invoke_b5_4_1_and_admit(
                            allow=True,wheelhouse=self.root,evidence=self.root/'evidence'))
                    self.assertEqual(calls,[envfile])
                    self.assertIsNone(runtime._LIFECYCLE.get())
                    self.assertEqual(runtime._TEST_SECRETS.get(),())
                    self.assertEqual(observed['restored'][-1],signal.SIG_DFL)
                    if name in ('unlink_failure','unlink_keyboard','unlink_unexpected_return'):
                        self.assertFalse(envfile.exists())
                        self.assertEqual(observed['records'][0]['transport_retirement'],'RETIRED')
                        self.assertEqual(observed['records'][0]['credential_file_cleanup'],'UNCONFIRMED')
                    else:
                        self.assertFalse(envfile.exists())
                    if expected_error:
                        self.assertEqual(observed['records'][0]['result'],'FAILED')
                finally:
                    patch.stopall()

    def test_arbitrary_pre_call_interrupt_is_unconfirmed_not_a_claim_of_attempt(self):
        # P1-K3 removes the P1-J pre-call persistence counterexample.
        # Interruption still denies admission, but there is no file to survive.
        observed=self.fixture()
        envfile=self.root/'evidence/test-client.env'
        calls=[]
        actual=runtime.remove_transient_credential_file
        def remove(path):
            calls.append(path)
            return actual(path)
        patch.object(runtime,'remove_transient_credential_file',side_effect=remove).start()
        function=_function(ast.parse(Path(runtime.__file__).read_text()),'run')
        lines=[node.lineno for node in ast.walk(function) if isinstance(node,ast.Assign)
               and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name)
               and node.value.func.id=='remove_transient_credential_file']
        target=min(lines)
        previous=sys.gettrace()
        injected=[False]
        def trace(frame,event,arg):
            if frame.f_code is runtime.run.__code__ and event=='line' and frame.f_lineno==target:
                injected[0]=True
                raise KeyboardInterrupt('synthetic pre-call seam')
            return trace
        try:
            sys.settrace(trace)
            with self.assertRaises(KeyboardInterrupt):
                controller.invoke_b5_4_1_and_admit(
                    allow=True,wheelhouse=self.root,evidence=self.root/'evidence')
        finally:
            sys.settrace(previous)
        self.assertTrue(injected[0])
        self.assertEqual(calls,[])
        self.assertFalse(envfile.exists())
        self.assertEqual(observed['records'][0]['transport_retirement'],'RETIRED')
        record=observed['records'][0]
        self.assertEqual(record['result'],'FAILED')
        self.assertEqual(record['credential_file_cleanup'],'UNCONFIRMED')
        self.assertEqual(record['cleanup_status'],'CLEANUP_UNCONFIRMED')
        self.assertEqual(observed['restored'][-1],signal.SIG_DFL)
        self.assertIsNone(runtime._LIFECYCLE.get())
        self.assertEqual(runtime._TEST_SECRETS.get(),())



if __name__ == '__main__':
    unittest.main()
