# P1-K3 proposed narrow B5-4-1 transfer contract

PROPOSAL ONLY. No protected-source transfer or operational authorization.
F-04 OPEN / NO-GO. B5-4-2 BLOCKED. P1-J remains UNAUTHORIZED / UNTRANSFERRED.

## Identity and scope

Baseline source: 06c3c374232bb4fad6e549c322e3a1f6bdd0d195.
Inventory documentation: 4f84e168b495c6e77c53520cfeeb9c80a8c0010c.
The owner-review packet pins all 23 changed/new paths and resulting blobs.
Only the fixed B5-4-1 workflow may produce an in-process admission receipt.
Base CLI, B5-1, B5-2, native/B4b persistence and interruption recovery refuse
before operational imports/side effects. Old clones and external deployment
callers are not revoked by these guards and remain outside authorization.

## File-free credential transport

No operational credential envfile, passfile or disk fallback is created.
The legacy test-client.env pathname is checked for ABSENCE only; discovering
any file/symlink there fails closed without deleting or reading its contents.
The historical helper name remains solely to keep unchanged negative regression
fault injection meaningful. NOT_PRESENT alone is never credential retirement.

Server creation uses the unchanged pinned image ID, existing fixed isolation,
OpenStdin, no TTY, POSTGRES_PASSWORD_FILE=/dev/stdin, log-driver=none and core=0.
A dedicated managed docker start --attach --interactive process supplies the
finite ASCII password and explicit EOF; private daemon inspection requires
OpenStdin=true, StdinOnce=true and Tty=false before each activation; its lifetime spans the running server.
A successful write/EOF is not readiness: the existing private authenticated
query must succeed. Explicit stop/reap then fresh start/attach replaces blind
restart, preserving the same owned container, volumes and cluster identity.
Failed/partial/uncertain starts stay unresolved even if resources look absent.

psql is invoked by one fixed Bash stdin adapter, never PGPASSFILE=/dev/stdin.
It consumes exactly the bounded password line, exports PGPASSWORD only inside
the execution process and leaves remaining SQL on stdin. -X, -w and pager=off
prevent startup scripts/prompts/pagers from consuming or publishing input.
No password or SCRAM verifier appears in Docker configuration or argv.

Python clients accept only a four-digit ASCII length (1..2048), one strict JSON
frame and EOF. Duplicate keys, unknown fields/stages, invalid run/database,
truncation, extra bytes and malformed/non-distinct credentials reject. A ten
second alarm bounds stdin consumption. Fixed stage names select the original
five test-module selectors; callers cannot supply pytest modules/flags. The
adapter sets R7_PG_* only in its own process and clears owned references/env
on completion. It does not launch an arbitrary worker or use native stdin APIs.

Generated transport passwords are 50 printable ASCII bytes, with no NUL/CR/LF.
SCRAM-SHA-256 uses a fresh 16-byte random salt, 4096 iterations and 32-byte keys.
SASLprep uses Unicode 3.2 mapping/normalization/prohibition/bidi checks; unlike
PostgreSQL's raw fallback, unsupported input is rejected. Generated ASCII
credentials avoid Unicode-version ambiguity. Encodings and verifier fields are
strictly validated. Verifiers travel in bootstrap SQL stdin and join the secret
redaction set; plaintext role passwords are never psql -v arguments.
The original role restrictions/grants and private privilege tests are retained.

## Supervision and retirement

Before any owned Docker resource creation, a separate-session cleanup process
acknowledges a private nonsecret lease. It never receives passwords/verifiers
in stdin, argv or environment. Its resource plan derives solely from the run
UUID: five fixed container suffixes and the existing data/socket volumes.
Every delete requires the exact inspected name AND matching run ownership label.
Containers must reconcile before volumes; no prune or foreign deletion exists.
A lost/expired supervisor blocks new resource mutations and credential delivery,
but never blocks cleanup. Its ContextVar restores with the other runtime state.

The lease is mode 0600, created exclusively with no-follow semantics, and fsynced
with its directory. It holds only version, UUID, deadline and state. No password
is persisted there. Parent EOF (including runner-only SIGKILL), deadline or an
unknown/partial request causes cleanup with an UNCERTAIN lease retained. Empty
inventory cannot resolve a potentially late daemon mutation. Parent SETTLED is
sent only after local mutations/reaping/resource cleanup are confirmed; then an
independent reconciliation and durable CONFIRMED lease plus private ACK and zero
supervisor exit are required. Missing ACK, failure or uncertain teardown denies.

The parent always drops its session-owned credential references; RETIRED means
local delivery channels reaped and session references dropped, not secure memory
erasure. Admission additionally requires independent resource cleanup, two
successful activations and all three fixed client stages, so RETIRED alone does
not assert revocation of a still-running or uncertain PostgreSQL service.

If BOTH runner and supervisor die, or the WSL VM/host restarts, a separately
installed/reviewed external restarter must enumerate overdue private leases and
invoke the pinned supervisor's explicit --allow-owned-disposable-cleanup
--recover interface after Docker is reachable. It retries owned cleanup but
never upgrades uncertainty into admission. That service is NOT installed by
this patch. Its startup/retry/alerting/host-reboot behavior requires separately
authorized host integration. No Python process can handle SIGKILL, guarantee
survival of the entire host, or prove an uncertain daemon request cannot finish.

## Canonical runtime and immutable admission

run_postgres owns commands, ContextVars, evidence, resource ledger, transport,
supervisor binding and signal restoration. A low-level run() return is not an
admission token. The fixed synchronous controller captures the same UUID,
retained record, exact CredentialSession object and evidence directory. It
requires normal completion, retired session with no owned passwords, two
activations, exact stage sequence, supervisor confirmation, cleanup success,
restored handler, no legacy file and zero observed secret redactions.

Version 2.0 terminal schema explicitly includes STDIN_PIPE_V1, RETIRED,
CONFIRMED and server_activations=2. Old credential-file PASS records are rejected.
The controller reconstructs canonical immutable UTF-8 bytes from the finalized
in-memory record, compares SHA-256 AND bytes with a bounded single no-follow
regular-file read, then returns a frozen in-process receipt. Consumers use those
bytes and never reopen the manifest. Wrong run/path/session, missing/duplicate
callback, mutation, exceptions and ambiguous publication deny even if PASS bytes
survive. Archives/imports/restart admission remain unconditional default-deny.
Receipts are not signed bearer attestations. Hostile ancestors, malicious Python
introspection and crash-durable manifest acceptance are outside this boundary.

## Bounded diagnostics and trust

Raw worker stdout/stderr, metadata, SQL, credentials, verifiers and exception
objects are nonpublishable. Six fixed stage files contain only OUTPUT_WITHHELD.
Observing an exact generated secret/verifier still increments rejection state.
Split/encoded output is withheld rather than reconstructed. Readiness strings
remain private. Inspection uses the existing intentionally lossy Config.Env
allowlist; omitted fields do not attest networking/mounts/privilege settings.
The admission schema rejects unknown keys/nested metadata and unowned inventory.
Cleanup leases and build metadata are private operational artifacts, not new
admission receipts. Only fixed trusted runtime code constructs public fields.

Trusted boundary: approved Linux/WSL host, Docker daemon, pinned image/source,
client dependency closure and fixed test producers. Process environments,
traceback frame locals, live buffers, same-UID/root inspection, swap/pagefiles,
VM snapshots and crash dumps remain sensitive. Dropping Python references is
not secure erasure. Host/VM swap/core/telemetry policy must be verified before
live testing; absence of persistent plaintext is NOT inferred from mocks or a
post-run directory scan. Container log persistence is disabled and application
logging restricted, but real daemon/VM behavior remains a proof obligation.

## Tests, provenance and authorization

Byte-authenticated historical fixtures retain protected source blobs
0863e81b733381a80b2f83560d8bbc231513ba41 and
040d0d30bb719d646eb350b229ccd9a4c5f2bf79. All original 46 provenance/parity test
functions/assertion expressions remain, with the already disclosed P1-J source
fixture transitions. Candidate code and OFFLINE_REVIEW_ONLY stops are unchanged.
The original cleanup_lifecycle regression source is unchanged and still imports
actual run_postgres. Its unexpected_manifest_secret case remains mandatory.

Live reporting parity permits only the enumerated P1-J diagnostic deltas plus
the explicit transport argument, -i, log/core restrictions, removal of env-file
and fixed adapter invocation. Command parity enumerates every added/removed AST
call expression. Unchanged build/source helpers stay exactly equal; ownership
removal expressions stay unchanged. The legacy helper is now absence-only.
The P1-J *proposal's* rejected file-survival expectations are explicitly replaced
by absence PLUS retirement/denial assertions, not skipped or silently rebaselined.
New tests cover framing, verifier boundaries, failed authentication, EOF model,
interruption classes, restart, supervision, stale evidence and disclosure.

Separately authorize exact resulting blobs before any protected-source change.
Require full offline suites and original RED on Python 3.11/3.12, then separately
authorize disposable integration and approved supply-chain/host prerequisites.
Do not infer absence of persistent plaintext or production readiness from mocks.
No source application, rebaseline acceptance, merge, deployment, gate closure or
B5-4-2 advancement is authorized by this document or a passing test.
