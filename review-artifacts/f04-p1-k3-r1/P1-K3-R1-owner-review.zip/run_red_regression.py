"""Non-authoritative P1-K3 offline executor. No dependency installation."""
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import unittest

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT/'proposed/sales-forecast-platform')
def forbidden(*args,**kwargs):
    raise AssertionError('P1-K3 harness: external process/network/signal forbidden')
# Direct deny assignments survive test-local patch.stopall() calls.
for name in ('Popen','run','call','check_call','check_output'):
    setattr(subprocess,name,forbidden)
for name in ('system','popen','kill','killpg','posix_spawn','posix_spawnp',
             'spawnl','spawnle','spawnlp','spawnlpe','spawnv','spawnve','spawnvp','spawnvpe'):
    if hasattr(os,name):setattr(os,name,forbidden)
socket.create_connection=forbidden
for name in ('connect','connect_ex','bind','listen'):
    setattr(socket.socket,name,forbidden)
# Audit guard survives mocks being reset and denies every actual child process.
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.kill','os.killpg',
                 'socket.connect','socket.bind'):
        raise AssertionError('P1-K3 audit guard: real external operation forbidden')
sys.addaudithook(audit)
# No real credentials are generated: all production entropy calls resolve to
# public deterministic synthetic values throughout this offline harness.
import secrets
counter=[0]
def synthetic_hex(size):
    counter[0]+=1
    return format(counter[0], '0'+str(size*2)+'x')
secrets.token_hex=synthetic_hex
secrets.token_bytes=lambda size: bytes(range(size))
suite=unittest.TestSuite()
loader=unittest.TestLoader()
sys.path.insert(0,'tests/runtime')
import importlib.util, importlib, hashlib
sys.path.insert(0,str(ROOT/'proposed/sales-forecast-platform/tests/postgres'))
original_path=ROOT.parent/'F04-P1-K3-NON-AUTHORITATIVE-06c3c374/proposed/sales-forecast-platform/tests/postgres/credential_cleanup_supervisor.py'
original_data=original_path.read_bytes()
expected=__import__('json').loads((ROOT.parent/'F04-P1-K3-NON-AUTHORITATIVE-06c3c374/manifest.json').read_text())
original_row=next(x for x in expected['files'] if x['path'].endswith('/credential_cleanup_supervisor.py'))
assert hashlib.sha256(original_data).hexdigest()==original_row['sha256']
spec=importlib.util.spec_from_file_location('authenticated_k3_supervisor',original_path)
original_module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(original_module)
tests=importlib.import_module('test_r7_05b5_4_1_f04_credential_supervision')
tests.supervisor=original_module
suite.addTests(loader.loadTestsFromName('test_r7_05b5_4_1_f04_credential_supervision.LeaseUpdateRecoveryTests.test_legacy_fixed_stage_cannot_poison_recovery'))
log=io.StringIO()
result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
(ROOT/'red-results.txt').write_text(log.getvalue())
module=sys.modules.get('test_r7_05b5_4_1_f04_operational_admission')
names=list(getattr(module,'DIRECT_ASSERTION_NAMES',()))
summary=dict(python=sys.version.split()[0],tests_run=result.testsRun,
    failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
    successful=result.wasSuccessful(),
    direct_existing_assertion_functions=names,
    direct_execution_is_not_pytest=True,
    original_pytest_regression='NOT EXECUTED: pytest unavailable; unchanged source retained',
    python_311='NOT EXECUTED: interpreter unavailable',
    execution='stdlib unittest; fake commands; process/network/real signals denied',
    known_pre_call_seam='No production credential file is created; historical API checks prohibited-path absence only.')
(ROOT/'red-results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(log.getvalue())
raise SystemExit(0 if result.wasSuccessful() else 1)

