| Path | K3 Git blob | R1 Git blob |
|---|---|---|
| sales-forecast-platform/tests/postgres/credential_cleanup_supervisor.py | 5bc7c67a0be8d7a189da80eecb7db16d8efe5f99 | e4c579838226bed554f268fb0072043c72851e17 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_credential_supervision.py | 32bfb277ac1b51c706f1c1a073f873fa4c8fb455 | 6de654bf68955f6ccdd6a018d50e74e22a2cc362 |
