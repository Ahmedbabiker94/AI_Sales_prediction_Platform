"""Non-authoritative P1-K3 offline executor. No dependency installation."""
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import unittest

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT/'proposed/sales-forecast-platform')
def forbidden(*args,**kwargs):
    raise AssertionError('P1-K3 harness: external process/network/signal forbidden')
# Direct deny assignments survive test-local patch.stopall() calls.
for name in ('Popen','run','call','check_call','check_output'):
    setattr(subprocess,name,forbidden)
for name in ('system','popen','kill','killpg','posix_spawn','posix_spawnp',
             'spawnl','spawnle','spawnlp','spawnlpe','spawnv','spawnve','spawnvp','spawnvpe'):
    if hasattr(os,name):setattr(os,name,forbidden)
socket.create_connection=forbidden
for name in ('connect','connect_ex','bind','listen'):
    setattr(socket.socket,name,forbidden)
# Audit guard survives mocks being reset and denies every actual child process.
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.kill','os.killpg',
                 'socket.connect','socket.bind'):
        raise AssertionError('P1-K3 audit guard: real external operation forbidden')
sys.addaudithook(audit)
# No real credentials are generated: all production entropy calls resolve to
# public deterministic synthetic values throughout this offline harness.
import secrets
counter=[0]
def synthetic_hex(size):
    counter[0]+=1
    return format(counter[0], '0'+str(size*2)+'x')
secrets.token_hex=synthetic_hex
secrets.token_bytes=lambda size: bytes(range(size))
suite=unittest.TestSuite()
loader=unittest.TestLoader()
for pattern in (
    'test_r7_05b5_4_1_f04_operational_admission.py',
    'test_r7_05b5_4_1_f04_excluded_entrypoints.py',
    'test_r7_05b5_4_1_f04_credential_transport.py',
    'test_r7_05b5_4_1_f04_credential_supervision.py',
):
    suite.addTests(loader.discover('tests/runtime',pattern=pattern))
log=io.StringIO()
result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
(ROOT/'mock-results.txt').write_text(log.getvalue())
module=sys.modules.get('test_r7_05b5_4_1_f04_operational_admission')
names=list(getattr(module,'DIRECT_ASSERTION_NAMES',()))
summary=dict(python=sys.version.split()[0],tests_run=result.testsRun,
    failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
    successful=result.wasSuccessful(),
    direct_existing_assertion_functions=names,
    direct_execution_is_not_pytest=True,
    original_pytest_regression='NOT EXECUTED: pytest unavailable; unchanged source retained',
    python_311='NOT EXECUTED: interpreter unavailable',
    execution='stdlib unittest; fake commands; process/network/real signals denied',
    known_pre_call_seam='No production credential file is created; historical API checks prohibited-path absence only.')
(ROOT/'mock-results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(log.getvalue())
raise SystemExit(0 if result.wasSuccessful() else 1)

