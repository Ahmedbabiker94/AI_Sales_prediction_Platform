# Exact P1-K3 staging-pattern review

Scope: all 42 members of authenticated ZIP SHA-256
ca7178dc029ed8f905e036fd1b8581e38650e5349cf450b4a165dd478c445f51,
including the 23 proposed files, historical source witnesses and review scripts.
Source-pattern evidence is in staging-pattern-scan.json. No other source was edited.

| Site in original archive | Result |
|---|---|
| credential_cleanup_supervisor.py:37-45, _save update branch | CONFIRMED defect: fixed .cleanup-lease-update + exclusive create reserves the same slot after interruption. Corrected only here. |
| credential_cleanup_supervisor.py initial lease creation | Canonical O_EXCL creation is intentional. No resource creation is permitted before a successful private lease handshake. A missing/corrupt canonical lease is not repaired by trusting a leftover temporary file. Preserved. |
| run_postgres.py:110-149, publish_terminal_manifest | Uses unique .run-manifest-<nonce>.tmp names and hard-link publication. No fixed temporary update slot. Its fixed run-manifest.json target intentionally refuses overwrite; stale/ambiguous PASS does not grant admission. Collision or publication failure remains fail-closed. Preserved. |
| run_postgres.py:104-111, write_evidence | Fixed final diagnostic file names are one-shot O_EXCL outputs, not reusable recovery staging slots. Partial output invalidates evidence; replacing existing evidence is deliberately unsupported. Preserved. |
| Historical frozen runner .txt fixture | Parse-only provenance witness; fixed evidence outputs are preserved byte-for-byte. Not an operational recovery implementation. |
| Review generators/test scripts | Write review artifacts directly; no fixed O_EXCL temporary-update/replace protocol. They are not operational admission or recovery authority. Preserved. |

No second instance of the same fixed-staging recovery defect was found in the
exact proposal. This is a bounded pattern assessment, not a new general security
signoff. The unchanged random manifest publisher has no explicit collision retry;
an improbable collision rejects publication rather than reserving a permanent
recovery slot. No reason to change that admission-sensitive code was established.
