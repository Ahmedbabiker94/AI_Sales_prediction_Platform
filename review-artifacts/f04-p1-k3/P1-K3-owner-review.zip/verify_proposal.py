"""Assemble/check one non-authoritative proposal, never apply it."""
import ast
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'F04-P1-J-NON-AUTHORITATIVE-06c3c374'
BASE=ROOT/'baseline';PROPOSED=ROOT/'proposed'
PG='sales-forecast-platform/tests/postgres/'
RT='sales-forecast-platform/tests/runtime/'
pins=json.loads((ROOT/'baseline-pins.json').read_text())['blobs']
assert hashlib.sha256((PRIOR/'proposal.patch').read_bytes()).hexdigest()=='3b0c50189afb34e2f2dfeb1145665ff2889edeaf6d776d8240a67762e823127e'
rows=json.loads((PRIOR/'allowlist.json').read_text())
extra=[PG+'bootstrap.sql',PG+'credential_transport.py',PG+'credential_test_client.py',
       PG+'credential_cleanup_supervisor.py',RT+'test_r7_05b5_4_1_f04_credential_transport.py',
       RT+'test_r7_05b5_4_1_f04_credential_supervision.py']
for path in extra:
 rows.append(dict(path=path,old_blob=pins.get(path),mode='100644'))
rows.sort(key=lambda r:r['path'])
assert len(rows)==23 and len({r['path'] for r in rows})==23

def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def files(root):return {str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*')
    if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
before=files(BASE);after=files(PROPOSED)
changed={p for p in set(before)|set(after) if before.get(p)!=after.get(p)}
assert changed=={r['path'] for r in rows},changed.symmetric_difference({r['path'] for r in rows})
manifest=[];patch=[]
for row in rows:
 path=row['path'];old=before.get(path,b'');new=after[path]
 assert row['old_blob']==pins.get(path),path
 if row['old_blob']:assert blob(old)==row['old_blob'],path
 else:assert path not in before,path
 if path.endswith('.py'):ast.parse(new.decode(),filename=path)
 manifest.append(dict(row,new_blob=blob(new),sha256=hashlib.sha256(new).hexdigest(),old_size=len(old),new_size=len(new)))
 patch.append('diff --git a/'+path+' b/'+path+'\n')
 if not row['old_blob']:patch.append('new file mode 100644\n')
 patch.append('index '+(row['old_blob'] or '0'*40)+'..'+blob(new)+' 100644\n')
 patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),
     fromfile='a/'+path if row['old_blob'] else '/dev/null',tofile='b/'+path,n=3))
patch_data=''.join(patch).encode();digest=hashlib.sha256(patch_data).hexdigest()
(ROOT/'proposal.patch').write_bytes(patch_data)
(ROOT/'allowlist.json').write_text(json.dumps(rows,indent=2)+'\n')
payload=dict(authority='NON-AUTHORITATIVE P1-K3; NO PROTECTED TRANSFER OR OPERATIONAL AUTHORIZATION',
 baseline_commit='06c3c374232bb4fad6e549c322e3a1f6bdd0d195',
 inventory_commit='4f84e168b495c6e77c53520cfeeb9c80a8c0010c',
 prior_untransferred_proposal_sha256='3b0c50189afb34e2f2dfeb1145665ff2889edeaf6d776d8240a67762e823127e',
 patch_sha256=digest,files=manifest)
(ROOT/'manifest.json').write_text(json.dumps(payload,indent=2)+'\n')
# Frozen fixtures, candidate code, original RED and original assertions remain.
for name,identity in (('run_postgres.py.txt','0863e81b733381a80b2f83560d8bbc231513ba41'),
                      ('run_b5_4_1_postgres.py.txt','040d0d30bb719d646eb350b229ccd9a4c5f2bf79')):
 assert blob(after[RT+'fixtures/f04_p1f/'+name])==identity
red=RT+'test_r7_05b5_4_1_f04_cleanup_lifecycle.py'
assert after[red]==before[red] and blob(after[red])=='e0685f1c6cb4d932c33bc746ae4d14288c134620'
for path in set(after)-changed:
 assert after[path]==before[path]
 if path in pins:assert blob(after[path])==pins[path],path
original_functions=0
for name in ('test_r7_05b5_4_1_f04_r2_04_controller_binding.py',
             'test_r7_05b5_4_1_f04_r2_04_r4_actual_reporting_stage.py',
             'test_r7_05b5_4_1_f04_fork_ast_operational_parity.py'):
 old=ast.parse(before[RT+name]);new=ast.parse(after[RT+name])
 newf={n.name:n for n in new.body if isinstance(n,ast.FunctionDef)}
 for fn in old.body:
  if not isinstance(fn,ast.FunctionDef) or not fn.name.startswith('test_'):continue
  original_functions+=1
  newfn=newf[fn.name]
  assert [ast.dump(n) for n in fn.decorator_list]==[ast.dump(n) for n in newfn.decorator_list]
  asserts=lambda n:Counter(ast.dump(x) for x in ast.walk(n) if isinstance(x,ast.Assert))
  assert asserts(fn)<=asserts(newfn),fn.name
  if fn.name not in ('test_existing_operational_wrapper_is_still_frozen_source_and_not_candidate',
                     'test_real_reporting_stage_candidate_source_parity'):
   assert ast.dump(fn)==ast.dump(newfn),fn.name
assert original_functions==46
# Preserve all 49 P1-J proposal methods, explicitly enumerate their source deltas.
prior_test_changes=[];prior_methods=0
for name in ('test_r7_05b5_4_1_f04_operational_admission.py','test_r7_05b5_4_1_f04_excluded_entrypoints.py'):
 old=ast.parse((PRIOR/'proposed'/RT/name).read_text());new=ast.parse(after[RT+name])
 newclasses={n.name:n for n in new.body if isinstance(n,ast.ClassDef)}
 for cls in old.body:
  if not isinstance(cls,ast.ClassDef):continue
  newmethods={n.name:n for n in newclasses[cls.name].body if isinstance(n,ast.FunctionDef)}
  for method in cls.body:
   if not isinstance(method,ast.FunctionDef) or not method.name.startswith('test_'):continue
   prior_methods+=1
   assert method.name in newmethods
   if ast.dump(method)!=ast.dump(newmethods[method.name]):prior_test_changes.append(cls.name+'.'+method.name)
assert prior_methods==49
# The fixed source identities, wheel pin and unchanged helper bodies.
old=ast.parse(before[PG+'run_postgres.py']);new=ast.parse(after[PG+'run_postgres.py'])
def constant(tree,name):return next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)
    and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
for name in ('BASE','POSTGRES','WHEEL','WHEEL_SHA256'):assert constant(old,name)==constant(new,name)
def function(tree,name):return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
for name in ('build_client','verified_clean_source'):assert ast.dump(function(old,name))==ast.dump(function(new,name))
# Bootstrap equality after exactly the credential security substitutions.
expected=before[PG+'bootstrap.sql'].decode()
for role in ('migrator','writer','reader'):expected=expected.replace(":'"+role+"_password'", ":'"+role+"_verifier'")
expected=expected.replace('CREATE ROLE r7_forecast_migrator',
    '-- Verifiers are validated and substituted in memory; never psql argv variables.\nCREATE ROLE r7_forecast_migrator')
assert after[PG+'bootstrap.sql'].decode()==expected
wf='.github/workflows/r7-b5-4-1-f04-candidate-offline.yml'
entries=lambda b:set(re.findall(r'tests/runtime/test_[A-Za-z0-9_]+\.py',b.decode()))
assert entries(before[wf])<=entries(after[wf])
assert len(entries(after[wf]))==39
results=json.loads((ROOT/'mock-results.json').read_text())
assert results['successful'] and results['failures']==results['errors']==results['skipped']==0
witness=json.loads((ROOT/'authoritative-before.json').read_text())
assert all(Path(path).exists() and hashlib.sha256(Path(path).read_bytes()).hexdigest()==value
           for path,value in witness.items()),'authoritative checkout content drift'
report=dict(status='PROPOSAL VERIFIED; NO TRANSFER AUTHORIZATION',changed_paths=23,
 existing_paths=sum(bool(r['old_blob']) for r in rows),new_paths=sum(not r['old_blob'] for r in rows),
 patch_sha256=digest,baseline_preimages_verified=True,actual_changes_equal_allowlist=True,
 original_RED_source_unchanged=True,original_provenance_functions_retained=original_functions,
 original_provenance_assertions_retained=True,prior_proposal_methods_retained=prior_methods,
 prior_proposal_methods_changed=prior_test_changes,workflow_modules=len(entries(after[wf])),
 image_and_wheel_pins_unchanged=True,unchanged_helpers=['build_client','verified_clean_source'],
 bootstrap_only_approved_credential_deltas=True,authoritative_snapshot_files_unchanged=len(witness),
 prior_J_patch_unchanged=True,python_312=results,python_311='UNEXECUTED: interpreter absent',
 pytest='UNEXECUTED: package absent; no installation authorized',
 original_RED_pytest='UNEXECUTED; source unchanged; equivalent actual-path unittest PASS',
 live_signals_Docker_PostgreSQL='UNEXECUTED / NOT AUTHORIZED')
(ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
(ROOT/'file-identities.md').write_text('| Path | Baseline Git blob | Proposed Git blob |\n|---|---|---|\n'+
 '\n'.join(f"| {r['path']} | {r['old_blob'] or 'NEW'} | {r['new_blob']} |" for r in manifest)+'\n')
print(json.dumps(dict(patch_sha256=digest,paths=23,original_functions=46,methods=results['tests_run'],
 original_RED='PRESERVED / pytest UNEXECUTED',changed_prior_methods=prior_test_changes),indent=2))
