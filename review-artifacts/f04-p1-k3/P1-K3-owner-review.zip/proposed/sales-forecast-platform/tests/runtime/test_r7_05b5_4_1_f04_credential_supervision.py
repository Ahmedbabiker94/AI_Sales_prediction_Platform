"""Nonsecret synthetic supervisor and lifecycle tests; no real OS signals."""
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from uuid import UUID

PG=Path(__file__).resolve().parents[1]/'postgres'
sys.path.insert(0,str(PG))
import credential_cleanup_supervisor as supervisor
import credential_transport as transport
import test_r7_05b5_4_1_f04_operational_admission as legacy

RUN=UUID('12345678-1234-1234-1234-123456789abc')


class SupervisorTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.path=self.root/supervisor.LEASE_NAME
        self.record=dict(version=1,run_id=str(RUN),deadline=int(time.time())+10,state='ARMED')

    def test_lease_has_only_nonsecret_fixed_identity_and_deadline(self):
        supervisor._save(self.path,self.record,initial=True)
        self.assertEqual(supervisor._load(self.path),self.record)
        self.assertEqual(self.path.stat().st_mode&0o777,0o600)
        self.assertEqual(set(json.loads(self.path.read_bytes())),{'version','run_id','deadline','state'})

    def test_symlink_overwrite_bad_shape_and_extra_metadata_denied(self):
        target=self.root/'foreign'
        target.write_text('foreign')
        self.path.symlink_to(target)
        with self.assertRaises(ValueError):supervisor._save(self.path,self.record,initial=True)
        with self.assertRaises(ValueError):supervisor._load(self.path)
        self.assertEqual(target.read_text(),'foreign')
        self.path.unlink()
        supervisor._save(self.path,dict(self.record,password='PUBLIC_BAD_FIELD'),initial=True)
        with self.assertRaises(ValueError):supervisor._load(self.path)

    def command_fixture(self, *, labels=None, wrong_name=False, failed=False, inventory=False):
        calls=[]
        def command(args):
            calls.append(args)
            if len(args)>1 and args[1]=='inspect':
                kind,_,name=args
                item=dict(Name=('foreign' if wrong_name else name))
                ownership={'r7_05b3_run':str(RUN)} if labels is None else labels
                if kind=='container':item['Config']={'Labels':ownership}
                else:item['Labels']=ownership
                return SimpleNamespace(returncode=0,stdout=json.dumps([item]).encode(),stderr=b'')
            if args[:1]==['ps'] or args[:2]==['volume','ls']:
                return SimpleNamespace(returncode=0,stdout=b'unknown' if inventory else b'',stderr=b'')
            return SimpleNamespace(returncode=1 if failed else 0,stdout=b'',stderr=b'')
        return calls,command

    def test_all_exact_names_and_labels_required_before_deletion(self):
        for kwargs in ({'labels':{'r7_05b3_run':'foreign'}},{'labels':{}},{'wrong_name':True}):
            calls,command=self.command_fixture(**kwargs)
            self.assertFalse(supervisor.reconcile(str(RUN),command))
            self.assertFalse(any(args[0]=='rm' or args[:2]==['volume','rm'] for args in calls))

    def test_fixed_owned_plan_deletes_containers_before_volumes(self):
        calls,command=self.command_fixture()
        self.assertTrue(supervisor.reconcile(str(RUN),command))
        removed=[args for args in calls if args[0]=='rm' or args[:2]==['volume','rm']]
        containers,volumes=supervisor.resource_plan(str(RUN))
        self.assertEqual([args[-1] for args in removed],containers+volumes)
        self.assertTrue(all('prune' not in args for args in calls))

    def test_failed_deletion_unknown_inventory_and_daemon_unavailable_deny(self):
        for kwargs in ({'failed':True},{'inventory':True}):
            _,command=self.command_fixture(**kwargs)
            self.assertFalse(supervisor.reconcile(str(RUN),command))
        def fail(args):raise OSError('synthetic daemon unavailable')
        self.assertFalse(supervisor.reconcile(str(RUN),fail))

    def test_malformed_inspect_is_not_an_ownership_proof(self):
        for value in (b'PUBLIC_BAD_JSON',b'[]',b'null',b'[{}]',b'[{"Config":null}]'):
            with self.subTest(value=value):
                def command(args):return SimpleNamespace(returncode=0,stdout=value,stderr=b'')
                self.assertFalse(supervisor.reconcile(str(RUN),command))

    def run_protocol(self,request,clean=True):
        supervisor._save(self.path,self.record,initial=True)
        read_end,write_end=os.pipe()
        out_read,out_write=os.pipe()
        try:
            os.write(write_end,request)
            os.close(write_end)
            with patch.object(supervisor,'reconcile',return_value=clean) as reconcile:
                result=supervisor.supervise(self.path,input_fd=read_end,output_fd=out_write)
            os.close(out_write)
            output=os.read(out_read,100)
            return result,output,supervisor._load(self.path),reconcile.call_count
        finally:
            for fd in (read_end,out_read):os.close(fd)

    def test_parent_sigkill_model_eof_reconciles_but_cannot_attest(self):
        result,output,record,calls=self.run_protocol(b'')
        self.assertEqual(result,72)
        self.assertEqual(output,b'ARMED\n')
        self.assertEqual(record['state'],'UNCERTAIN')
        self.assertEqual(calls,1)

    def test_success_requires_settled_message_and_independent_cleanup(self):
        result,output,record,calls=self.run_protocol(b'SETTLED\n')
        self.assertEqual(result,0)
        self.assertEqual(output,b'ARMED\nCONFIRMED\n')
        self.assertEqual(record['state'],'CONFIRMED')

    def test_failed_teardown_never_acknowledges_confirmation(self):
        result,output,record,calls=self.run_protocol(b'SETTLED\n',clean=False)
        self.assertEqual(result,72)
        self.assertEqual(output,b'ARMED\n')
        self.assertEqual(record['state'],'UNCERTAIN')

    def test_unknown_message_and_deadline_do_not_confirm(self):
        result,output,record,calls=self.run_protocol(b'COMPLETE\n')
        self.assertEqual(result,72)
        self.assertNotIn(b'CONFIRMED',output)
        self.assertEqual(record['state'],'UNCERTAIN')

    def test_restart_recovery_never_becomes_an_archive_receipt(self):
        self.record['deadline']=int(time.time())-1
        self.record['state']='UNCERTAIN'
        supervisor._save(self.path,self.record,initial=True)
        with patch.object(supervisor,'reconcile',return_value=True) as cleanup:
            self.assertEqual(supervisor.main(['--allow-owned-disposable-cleanup','--recover',str(self.path)]),72)
        self.assertEqual(cleanup.call_count,1)
        self.assertEqual(supervisor._load(self.path)['state'],'UNCERTAIN')
        self.assertNotEqual(supervisor.main(['--recover',str(self.path)]),0)

    def test_supervisor_crash_lost_ack_or_bad_return_types_deny(self):
        item=supervisor.CleanupSupervisor(RUN,self.root)
        self.assertEqual(item.finish(False),'UNCONFIRMED')
        for bad in (True,1,None,[],object()):
            process=SimpleNamespace(stdin=io.BytesIO(),wait=lambda **kw:0)
            item.process=process
            with patch.object(item,'_read',return_value=bad),patch.object(supervisor,'_load',return_value={'state':'CONFIRMED'}):
                # Only a literal boolean from the private fixed reader is valid.
                result=item.finish(True)
            if bad is not True:self.assertEqual(result,'UNCONFIRMED')

    def test_supervisor_process_has_own_session_and_no_secret_protocol(self):
        item=supervisor.CleanupSupervisor(RUN,self.root)
        process=SimpleNamespace(stdin=io.BytesIO(),poll=lambda:None)
        with patch.object(supervisor.subprocess,'Popen',return_value=process) as popen,\
             patch.object(item,'_read',return_value=True):
            item.start()
        args,kwargs=popen.call_args
        self.assertTrue(kwargs['start_new_session'])
        self.assertTrue(kwargs['close_fds'])
        self.assertEqual(args[0][-2:],["--supervise",str(self.path)])
        self.assertNotIn('password',repr(args)+repr(kwargs))

    def test_dead_or_expired_supervisor_blocks_new_work(self):
        item=supervisor.CleanupSupervisor(RUN,self.root)
        supervisor._save(self.path,self.record,initial=True)
        item.deadline=self.record['deadline']
        item.process=SimpleNamespace(poll=lambda:None)
        item.check_live()
        item.process=SimpleNamespace(poll=lambda:137)
        with self.assertRaises(transport.TransportFailure):item.check_live()
        item.process=SimpleNamespace(poll=lambda:None)
        item.deadline=int(time.time())-1
        with self.assertRaises(transport.TransportFailure):item.check_live()

    def test_cross_run_lease_cannot_confirm_or_keep_supervision_live(self):
        item=supervisor.CleanupSupervisor(RUN,self.root)
        item.deadline=self.record['deadline']
        process=SimpleNamespace(stdin=io.BytesIO(),poll=lambda:None,wait=lambda **kw:0)
        item.process=process
        foreign=dict(self.record,run_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa')
        with patch.object(supervisor,'_load',return_value=foreign):
            with self.assertRaises(transport.TransportFailure):item.check_live()
        with patch.object(item,'_read',return_value=True),\
             patch.object(supervisor,'_load',return_value=dict(foreign,state='CONFIRMED')):
            self.assertEqual(item.finish(True),'UNCONFIRMED')

    def test_supervision_check_preserves_interrupt_class_without_raw_error(self):
        item=supervisor.CleanupSupervisor(RUN,self.root)
        for cls in (KeyboardInterrupt,SystemExit):
            with patch.object(supervisor,'_load',side_effect=cls('PUBLIC_UNSAFE_LEASE_INTERRUPT')):
                with self.assertRaises(cls) as caught:item.check_live()
            self.assertIsNone(caught.exception.__context__)
            self.assertNotIn('PUBLIC_UNSAFE_LEASE_INTERRUPT',repr(caught.exception.args))

    def test_lost_supervision_blocks_creates_but_never_blocks_cleanup(self):
        runtime=legacy.runtime
        record={'run_hex':RUN.hex,'creation_attempts':[]}
        name='r7-05b3-'+RUN.hex+'-server'
        def fail():raise transport.TransportFailure('supervisor lost')
        owner=runtime._LIFECYCLE.set(record)
        supervision=runtime._SUPERVISOR.set(SimpleNamespace(check_live=fail))
        try:
            with self.assertRaises(transport.TransportFailure):
                runtime.command(['docker','create','--name',name])
            process=SimpleNamespace(communicate=lambda **kw:('',''),returncode=0)
            with patch.object(runtime.subprocess,'Popen',return_value=process):
                self.assertEqual(runtime.command(['docker','rm','-f',name]).returncode,0)
        finally:
            runtime._SUPERVISOR.reset(supervision)
            runtime._LIFECYCLE.reset(owner)


class RetirementAdmissionTests(unittest.TestCase):
    setUp=legacy.AdmissionTests.setUp
    fixture=legacy.RuntimeTests.fixture

    def invoke(self):
        return legacy.controller.invoke_b5_4_1_and_admit(
            allow=True,wheelhouse=self.root,evidence=self.root/'evidence')

    def test_hostile_cleanup_status_does_not_execute_equality(self):
        class Hostile:
            def __eq__(self,other):raise AssertionError('foreign equality executed')
        class ForeignString(str):
            def __eq__(self,other):raise AssertionError('foreign equality executed')
        for bad in (True,1,None,[],Hostile(),ForeignString('RETIRED')):
            self.assertEqual(legacy.runtime._fixed_status(bad,'RETIRED'),'UNCONFIRMED')
        self.assertEqual(legacy.runtime._fixed_status('RETIRED','RETIRED'),'RETIRED')

    def test_missing_supervisor_confirmation_denies_even_with_removed_resources(self):
        self.fixture()
        class Unconfirmed:
            confirmed=False
            def __init__(self,*a):pass
            def start(self):pass
            def check_live(self):pass
            def finish(self,settled):return 'UNCONFIRMED'
            def abandon(self):pass
        with patch.object(legacy.runtime,'CleanupSupervisor',Unconfirmed):
            with self.assertRaises(legacy.runtime.CleanupUnconfirmed):self.invoke()
        record=json.loads((self.root/'evidence/run-manifest.json').read_bytes())
        self.assertEqual(record['result'],'FAILED')
        self.assertEqual(record['supervisor_cleanup'],'UNCONFIRMED')
        self.assertEqual(record['transport_retirement'],'RETIRED')
        self.assertFalse((self.root/'evidence/test-client.env').exists())

    def test_missing_retirement_or_wrong_activation_count_denies_receipt(self):
        for key,bad in (('transport_retirement','UNCONFIRMED'),('supervisor_cleanup','UNCONFIRMED'),
                        ('server_activations',1),('server_activations',True),('credential_file_cleanup','REMOVED')):
            with tempfile.TemporaryDirectory() as directory:
                self.root=Path(directory)
                helper=legacy.AdmissionTests()
                helper.root=self.root
                fake=helper.synthetic(mutation=lambda data,record:(record.update({key:bad}) or legacy.canonical(record)))
                with patch.object(legacy.runtime,'run',side_effect=fake),patch.object(legacy.controller,'reporting_stage'):
                    self.assertIsNone(self.invoke())

    def test_failed_bootstrap_authentication_reconciles_and_denies(self):
        observed=self.fixture()
        original=legacy.runtime.command
        def command(args,**kwargs):
            if args[:3]==['docker','exec','-i'] and 'SELECT current_database()' not in str(args):
                return SimpleNamespace(returncode=2,stdout='',stderr='PUBLIC_FAILED_AUTH')
            return original(args,**kwargs)
        with patch.object(legacy.runtime,'command',side_effect=command):
            with self.assertRaises(RuntimeError):self.invoke()
        record=json.loads((self.root/'evidence/run-manifest.json').read_bytes())
        self.assertEqual(record['result'],'FAILED')
        self.assertEqual(record['transport_retirement'],'RETIRED')
        self.assertTrue(observed['removals'])
        self.assertNotIn('PUBLIC_FAILED_AUTH',json.dumps(record))

    def test_truncated_delivery_or_sigterm_class_interrupt_cannot_admit(self):
        for cls in (transport.TransportFailure,KeyboardInterrupt,SystemExit):
            with tempfile.TemporaryDirectory() as directory:
                self.root=Path(directory)
                observed=self.fixture()
                def activate(session,server,**kwargs):
                    session._failed=True
                    session._lifecycle['creation_attempts'].append(
                        dict(kind='container',name=server,state='DAEMON_UNRESOLVED'))
                    raise cls('synthetic interrupted delivery')
                with patch.object(transport.CredentialSession,'activate',activate):
                    with self.assertRaises(BaseException):self.invoke()
                record=json.loads((self.root/'evidence/run-manifest.json').read_bytes())
                self.assertEqual(record['result'],'FAILED')
                self.assertEqual(record['transport_retirement'],'UNCONFIRMED')
                self.assertEqual(record['cleanup_status'],'CLEANUP_UNCONFIRMED')
                self.assertFalse((self.root/'evidence/test-client.env').exists())
                self.assertIsNone(legacy.runtime._LIFECYCLE.get())
                self.assertIsNone(legacy.runtime._SUPERVISOR.get())
                self.assertEqual(legacy.runtime._TEST_SECRETS.get(),())
                patch.stopall()

    def test_restart_uses_fresh_delivery_and_receipt_is_immutable(self):
        observed=self.fixture()
        receipt=self.invoke()
        self.assertIsNotNone(receipt)
        record=json.loads(receipt.manifest_bytes)
        self.assertEqual(record['server_activations'],2)
        self.assertEqual(record['supervisor_cleanup'],'CONFIRMED')
        self.assertEqual(record['transport_retirement'],'RETIRED')
        commands=observed['commands']
        self.assertFalse(any(args[:2]==['docker','restart'] for args in commands))
        self.assertTrue(any(args[:2]==['docker','create'] and '-i' in args for args in commands))
        self.assertFalse(any('--env-file' in args for args in commands))
        before=receipt.manifest_bytes
        (self.root/'evidence/run-manifest.json').write_text('stale replacement')
        self.assertEqual(receipt.manifest_bytes,before)


if __name__=='__main__':
    unittest.main()
