| Path | Baseline Git blob | Proposed Git blob |
|---|---|---|
| .github/workflows/r7-b5-4-1-f04-candidate-offline.yml | daa477ceba84bd7a6a85dcb4d40fa33fa0452aea | bb4610d98f0a1a50b5cb9db5c67b13129f3743df |
| sales-forecast-platform/docs/r7_05b5_4_1_f04_narrow_transfer_contract.md | NEW | bc8bb0eaa2137799d8d256453ffca9a526a0fb47 |
| sales-forecast-platform/tests/persistence/run_authorized_persistence.py | 817873f82131439d34e5fce2cef7a05e5720d50a | 6c5cd02694e8c222666e545df26a46d8b53a98b8 |
| sales-forecast-platform/tests/persistence/test_interruption_recovery.py | 63f53811b246487fd6729719f0388d911d18fda0 | 433407db79805b4e3b52616ccc5eb54db712d8e2 |
| sales-forecast-platform/tests/postgres/bootstrap.sql | 9bb7a51b14e6cd4dedf20ebf550c4b3085d69de1 | 683e55c522b008212db594998f92f48cb3907f8f |
| sales-forecast-platform/tests/postgres/credential_cleanup_supervisor.py | NEW | 5bc7c67a0be8d7a189da80eecb7db16d8efe5f99 |
| sales-forecast-platform/tests/postgres/credential_test_client.py | NEW | 730dd3b596f4648648c37a58002656ef7cb25f92 |
| sales-forecast-platform/tests/postgres/credential_transport.py | NEW | 77d126fae4b628cdfbcd3e54fd86568ff9235c78 |
| sales-forecast-platform/tests/postgres/run_b5_4_1_postgres.py | 040d0d30bb719d646eb350b229ccd9a4c5f2bf79 | 6b08cf07f80946437fccba8265a5517540d93543 |
| sales-forecast-platform/tests/postgres/run_b5_4_1_reporting_stage.py | NEW | 1ace4cfa82c23f86120ea8e742016b49e93b1c20 |
| sales-forecast-platform/tests/postgres/run_forecast_read.py | 0aaa57aa3a952a72461fd95cba69cd78e53085c7 | d981d144145ee9b90604f261cf85ad2ebb935996 |
| sales-forecast-platform/tests/postgres/run_manifest_admission_controller.py | NEW | f70d80895bd079adbf7d816a2b981f6b5d7cd509 |
| sales-forecast-platform/tests/postgres/run_postgres.py | 0863e81b733381a80b2f83560d8bbc231513ba41 | db63d15f4586112eccb0e379bf5d03f652339746 |
| sales-forecast-platform/tests/postgres/run_stored_accuracy.py | d7606d0631c8c18bd49f3112262a6e2652c3d76b | 6537ffde46f6e4097ecb1f9cf2ecdd975dc916c0 |
| sales-forecast-platform/tests/runtime/fixtures/f04_p1f/run_b5_4_1_postgres.py.txt | NEW | 040d0d30bb719d646eb350b229ccd9a4c5f2bf79 |
| sales-forecast-platform/tests/runtime/fixtures/f04_p1f/run_postgres.py.txt | NEW | 0863e81b733381a80b2f83560d8bbc231513ba41 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_credential_supervision.py | NEW | 32bfb277ac1b51c706f1c1a073f873fa4c8fb455 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_credential_transport.py | NEW | ba3a8c3215462209d35eeea50b9332b08a742d8f |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_excluded_entrypoints.py | NEW | 2816ed2a2b79128367dbde79a139ad9026ade594 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_fork_ast_operational_parity.py | 94587c80c873f7f4891eb20c357af9116fbbac4e | 636e70112d4dc3b7b34b248e583e8e8d8e8231b2 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_operational_admission.py | NEW | bea4ce4ab1a306e0c0b516f9f99006e572906f02 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_r2_04_controller_binding.py | 92a75489619e75db0cf6f3167c6288220f86cbbb | d6a97a45812af10983edde00b7aca3316e588984 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_r2_04_r4_actual_reporting_stage.py | a0a41ec4c0a30b0807fc423e384d99f8c8cd8140 | ac868877bd2d2a388b29fb80e9c406702ea1e413 |
