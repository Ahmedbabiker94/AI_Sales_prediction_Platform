# F-04 P1-K3 — Exact credential transport proposal

**NON-AUTHORITATIVE OWNER-REVIEW PACKET. Prepared 2026-11-21.**
**F-04 OPEN / NO-GO. B5-4-2 BLOCKED. P1-J UNAUTHORIZED / UNTRANSFERRED.**

## 1. Exact identity and disposition

Proposal preparation is complete for owner review. This packet is NOT source
transfer authorization, production approval or independent human signoff.

- Source baseline: `06c3c374232bb4fad6e549c322e3a1f6bdd0d195`.
- Inventory/documentation baseline: `4f84e168b495c6e77c53520cfeeb9c80a8c0010c`.
- Combined P1-K3 patch SHA-256: **d0c57e33d1bd774b26070eaae3278e05335efb993ce8051d86c8c52a032846f7**.
- Exact manifest SHA-256: **84f1c22b0d610303b34c31c8f52fd018ede2420cb783754933cc8125c5b3de43**.
- P1-J patch remains byte-unchanged at
  `3b0c50189afb34e2f2dfeb1145665ff2889edeaf6d776d8240a67762e823127e`.

P1-K3 was constructed from pinned baseline bytes and the reviewed, untransferred
P1-J proposal content. Neither patch was applied to an authoritative checkout,
index or operational branch. No commits, pushes, merge, installs, deployment,
Docker/PostgreSQL commands, real process signals or live credentials occurred.
Synthetic test entropy was globally replaced with public deterministic values;
crypto tests use public fixed vectors only. UUID/tempfile names are nonsecret.

Artifacts:
- [Complete exact unified diff](proposal.patch)
- [Full per-file Git blob/SHA-256/size/mode manifest](manifest.json)
- [Exact allowlist](allowlist.json)
- [Static verification](verification.json)
- [Offline result JSON](mock-results.json) / [full final log](mock-results.txt)
- [Initial failure log](mock-results-initial.txt)
- [Every unexecuted check and source-level test catalog](unexecuted-tests.md)
- [Machine-readable test catalog](test-catalog.json)
- [Proposed security contract](proposed/sales-forecast-platform/docs/r7_05b5_4_1_f04_narrow_transfer_contract.md)
- [Implementation line map](source-references.md)
- [Reproduction and per-file verification plan](REPRODUCE.md)

## 2. Complete allowlist and resulting identities

Exactly **23 paths: 11 modified existing paths, 12 new paths**. P1-J's 17-path
allowlist expands only by bootstrap.sql, three credential/supervisor modules and
two focused test modules. No Dockerfile, dependency lock, image pin, native
worker protocol or deployment/service configuration is changed. This is the
necessary credential-security delta; an external restarter deployment would
require a separately scoped owner decision and is NOT included.

| Path | Baseline Git blob | Proposed Git blob |
|---|---|---|
| .github/workflows/r7-b5-4-1-f04-candidate-offline.yml | daa477ceba84bd7a6a85dcb4d40fa33fa0452aea | bb4610d98f0a1a50b5cb9db5c67b13129f3743df |
| sales-forecast-platform/docs/r7_05b5_4_1_f04_narrow_transfer_contract.md | NEW | bc8bb0eaa2137799d8d256453ffca9a526a0fb47 |
| sales-forecast-platform/tests/persistence/run_authorized_persistence.py | 817873f82131439d34e5fce2cef7a05e5720d50a | 6c5cd02694e8c222666e545df26a46d8b53a98b8 |
| sales-forecast-platform/tests/persistence/test_interruption_recovery.py | 63f53811b246487fd6729719f0388d911d18fda0 | 433407db79805b4e3b52616ccc5eb54db712d8e2 |
| sales-forecast-platform/tests/postgres/bootstrap.sql | 9bb7a51b14e6cd4dedf20ebf550c4b3085d69de1 | 683e55c522b008212db594998f92f48cb3907f8f |
| sales-forecast-platform/tests/postgres/credential_cleanup_supervisor.py | NEW | 5bc7c67a0be8d7a189da80eecb7db16d8efe5f99 |
| sales-forecast-platform/tests/postgres/credential_test_client.py | NEW | 730dd3b596f4648648c37a58002656ef7cb25f92 |
| sales-forecast-platform/tests/postgres/credential_transport.py | NEW | 77d126fae4b628cdfbcd3e54fd86568ff9235c78 |
| sales-forecast-platform/tests/postgres/run_b5_4_1_postgres.py | 040d0d30bb719d646eb350b229ccd9a4c5f2bf79 | 6b08cf07f80946437fccba8265a5517540d93543 |
| sales-forecast-platform/tests/postgres/run_b5_4_1_reporting_stage.py | NEW | 1ace4cfa82c23f86120ea8e742016b49e93b1c20 |
| sales-forecast-platform/tests/postgres/run_forecast_read.py | 0aaa57aa3a952a72461fd95cba69cd78e53085c7 | d981d144145ee9b90604f261cf85ad2ebb935996 |
| sales-forecast-platform/tests/postgres/run_manifest_admission_controller.py | NEW | f70d80895bd079adbf7d816a2b981f6b5d7cd509 |
| sales-forecast-platform/tests/postgres/run_postgres.py | 0863e81b733381a80b2f83560d8bbc231513ba41 | db63d15f4586112eccb0e379bf5d03f652339746 |
| sales-forecast-platform/tests/postgres/run_stored_accuracy.py | d7606d0631c8c18bd49f3112262a6e2652c3d76b | 6537ffde46f6e4097ecb1f9cf2ecdd975dc916c0 |
| sales-forecast-platform/tests/runtime/fixtures/f04_p1f/run_b5_4_1_postgres.py.txt | NEW | 040d0d30bb719d646eb350b229ccd9a4c5f2bf79 |
| sales-forecast-platform/tests/runtime/fixtures/f04_p1f/run_postgres.py.txt | NEW | 0863e81b733381a80b2f83560d8bbc231513ba41 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_credential_supervision.py | NEW | 32bfb277ac1b51c706f1c1a073f873fa4c8fb455 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_credential_transport.py | NEW | ba3a8c3215462209d35eeea50b9332b08a742d8f |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_excluded_entrypoints.py | NEW | 2816ed2a2b79128367dbde79a139ad9026ade594 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_fork_ast_operational_parity.py | 94587c80c873f7f4891eb20c357af9116fbbac4e | 636e70112d4dc3b7b34b248e583e8e8d8e8231b2 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_operational_admission.py | NEW | bea4ce4ab1a306e0c0b516f9f99006e572906f02 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_r2_04_controller_binding.py | 92a75489619e75db0cf6f3167c6288220f86cbbb | d6a97a45812af10983edde00b7aca3316e588984 |
| sales-forecast-platform/tests/runtime/test_r7_05b5_4_1_f04_r2_04_r4_actual_reporting_stage.py | a0a41ec4c0a30b0807fc423e384d99f8c8cd8140 | ac868877bd2d2a388b29fb80e9c406702ea1e413 |


The manifest includes SHA-256, old/new sizes and modes for every row. Existing
preimages are byte-verified against pinned Git blob identities. Historical fixture
blobs equal the original protected runner/wrapper. Both image IDs, driver wheel
identity/hash, original role grants and five fixed PostgreSQL selectors remain.

## 3. Implementation and bounded compatibility

**Server:** docker create -i with the unchanged server image, no TTY, fixed
isolation and POSTGRES_PASSWORD_FILE=/dev/stdin. A separate managed start/attach
process receives only a finite ASCII password on stdin and explicit EOF.
Private daemon inspection requires literal OpenStdin=true, StdinOnce=true and
Tty=false before EVERY activation. The CLI source supporting create -i was
rechecked at reference commit a7dcaa6fdb6ed04aacbfdc76357fdae01605609e:
opts.go lines 355-356 and 724-726 set AttachStdin/StdinOnce. The installed host CLI
and daemon behavior remain live verification obligations. Engine 29.7.2 commit
6a43e3d5afddf4111da0f864bbc7cae5d7e95001 supplies the previously reviewed EOF/reset
behavior; attachment completion is never used as readiness.

Explicit stop/reap/fresh start replaces blind restart, retaining the same owned
container and volumes. Private authenticated readiness and cluster comparison
remain. An interrupted/uncertain mutation never becomes settled solely because
inventory is empty. Daemon log persistence is disabled for credential-bearing
containers, core limits are zero, final server logging collector is disabled,
and no password is configured in Docker environment or command arguments.

**psql:** a fixed bounded Bash adapter reads one 50-byte password and its newline,
sets PGPASSWORD only inside the exec process, then execs psql -X -w with pager off
and remaining SQL stdin untouched. No passfile, hidden fallback or arbitrary
worker selection exists. Real Bash read behavior and initdb/bootstrap error-log
confidentiality must be verified in the exact image. Partial input may initialize
an unintended password; successful write/EOF is insufficient. Expected-password
authentication must succeed or the run rejects and tears down.

**Python clients:** four-digit ASCII size, <=2048-byte strict JSON, exact reads
and EOF, duplicate-key/type/shape/identity/stage/credential rejection and a ten
second input alarm. Only the original fixed stage selectors are available.
The existing conftest remains unchanged (blob
34dbd300c461ccedfd330c03861ae5456f0c374d); it requires all four role passwords,
including admin for private privilege/migration validation. The adapter sets
R7_PG_* only in its own process, clears ambient PG connection settings and
clears owned password references/environment after pytest. It is Linux/WSL-only,
not a Windows-native or native/B4b stdin protocol.

**SCRAM:** generated passwords remain fixed-format nonempty printable ASCII.
SASLprep explicitly uses Unicode 3.2 mapping/NFKC/prohibition/bidi validation;
unsupported values reject rather than use PostgreSQL's raw fallback. Verifiers
require SHA-256, 4096 iterations, a fresh 16-byte cryptographic salt, 32-byte keys,
canonical Base64 and exact shape. SQL receives validated verifier literals in
stdin, not plaintext -v arguments. Verifiers join the redaction set as sensitive
material. The packaged source review supports this design; no PostgreSQL binary
was executed to prove authentication or normalization interoperability here.

**Supervisor:** a separate-session process has a private nonsecret lease and EOF
pipe, fixed UUID-derived five-container/two-volume plan, exact name+ownership
checks, container-before-volume cleanup and no prune. It receives no PG secrets
in its protocol, arguments or environment. New work/credential delivery checks
liveness, deadline and SAME-run lease identity; cleanup remains available after
supervision is lost. EOF/deadline/unknown request retains UNCERTAIN even after an
empty observation. Normal success needs parent SETTLED, independent cleanup,
durable same-run CONFIRMED lease, exact ACK and zero supervisor exit. Typed
literal status validation rejects custom comparison objects.

**External dependency:** runner-only SIGKILL is modeled by EOF; actual survival
of the supervisor is not tested. Both-process death/VM reboot requires a
separately installed, pinned restarter that enumerates private overdue leases,
waits for Docker, retries ownership-scoped cleanup and alerts on uncertainty.
Its installation, startup ordering, service manager, cadence and supervision
must be approved and verified BEFORE live testing. This patch installs no
systemd unit, Windows task or service. No in-process solution handles host death
or proves that an unresolved daemon request cannot complete later. Recovery
never creates a receipt or silently upgrades an uncertain lease.

## 4. Security invariant and evidence matrix

| Invariant | Proposed mechanism / offline evidence | Remaining live obligation |
|---|---|---|
| No persistent plaintext credential file | No operational creator/envfile/passfile; absence-only lstat guard; source tests and interrupted pre-call regression | Trace actual writes throughout host/VM/container lifecycle, not post-run scans alone |
| No password/verifier argv or Docker configuration | Fixed scripts, pipe input, no env-file/-e secret; captured argv tests | Inspect real container/exec metadata, CLI/process argv and daemon storage |
| Bounded, noninteractive consumption | Strict frames/EOF/alarm; every truncation and malformed boundary rejected; psql -X/-w | Actual Bash/libpq/Engine stream behavior and stalls |
| SCRAM and existing PG functionality | Strict format/length/iteration/normalization tests; bootstrap parity preserves grants | Catalog verifier and correct/incorrect password authentication; original fixed PG tests |
| Same runtime/invocation admission | Same UUID, record, evidence path and exact session; normal return; immutable bytes+digest | Full offline suite and separately authorized real lifecycle |
| Credential retirement | Session-owned references dropped; attachments reaped; two activations and all stages; independent teardown confirmation | Real local reaping, resource absence and pending daemon operations; no memory-erasure claim |
| Cleanup uncertainty dominates | Unresolved attempt/retirement/supervisor/handler/status faults deny; primary/publisher regressions retained | Late daemon appearance and failure combinations with actual Engine |
| Runner interruption / SIGKILL | KI/SystemExit fault injection and real nonsecret-pipe EOF model; restored ContextVars/handler | Actual SIGINT/SIGTERM/SIGKILL at each seam; both-process death/reboot/service retry |
| Ownership/isolation | Existing removal expressions/pins/selectors; stronger supervisor name+label checks | Inspect actual mounts/network/caps/users/limits and foreign resource survival |
| Confidential bounded diagnostics | Fixed OUTPUT_WITHHELD; existing lossy inspect projection; secret/verifier redaction and schema denial | Actual logs, error paths, telemetry and producer behavior |
| Stale/ambiguous PASS never sufficient | Missing/duplicate callback, tampering, cross-run/session/lease, publisher faults, immutable receipt, archive denial tests | Full required suite; no durable archive authority is introduced |
| Excluded routes | First-action guards for B5-1/B5-2/persistence/recovery and base CLI; exclusion tests retained | External/deployment/old-clone inventory and execution policy remain owner holds |

RETIRED denotes local transport retirement, not secure erasure or independent
revocation. Admission ALSO requires no unresolved mutations and confirmed owned
cluster/client teardown. Failed revocation/teardown is UNCONFIRMED/NO ADMISSION;
private leases remain for cleanup supervision. Same-UID/root/daemon inspection,
traceback locals and process/VM memory remain within the declared trusted-host
boundary. Python reference clearing is not a memory secrecy proof.

## 5. Test contract, RED regression and results

| Environment/check | Result |
|---|---|
| Python 3.12.14 stdlib unittest | **95 passed; 0 failures, 0 errors, 0 skips** |
| Historical pure assertions | Eight functions called directly and passed; not pytest execution |
| Python 3.11 | UNEXECUTED: interpreter unavailable; none installed |
| Full pytest / original unchanged RED node | UNEXECUTED: pytest unavailable; none installed |
| Proposed Python AST/syntax, identities, changed-path set | PASS |
| Exact patch applicability | git apply --check PASS in isolated pinned baseline; no patch applied |
| Real Docker/PG/processes/signals/host persistence | UNEXECUTED / NOT AUTHORIZED |

All 49 P1-J proposal methods remain enabled. Four have explicit reviewed contract
deltas: unchanged-helper parity now excludes the intentionally changed
absence-only helper; command parity enumerates exact added/removed AST calls;
and the two credential-attempt methods replace rejected file-survival assertions
with ABSENCE PLUS retirement and continued fail-closed checks. The original 46
baseline provenance/parity test functions/decorators/assertion expressions remain
preserved through P1-J's authenticated historical-fixture transitions. No skip,
xfail, test deletion or generic AST normalization was introduced. All 39 workflow
module entries remain enabled (35 original + two P1-J + two P1-K3).

Initial validation found four failures of obsolete P1-J file-survival assertions
(one pre-call seam and three subcases). The initial log is retained. The source
also needed explicit failed bookkeeping when interrupted before the absence
check. Both were corrected within the proposal; final results above are clean.
An applicability invocation initially used the artifact root rather than the
baseline directory and reported missing preimages; the corrected baseline check
passed. That invocation did not apply/change any source.

The original RED source is unchanged at blob
e0685f1c6cb4d932c33bc746ae4d14288c134620:
`test_run_finalization_fails_closed_on_negative_scenarios[unexpected_manifest_secret]`.
It still imports actual run_postgres. Frozen source reset secret context before
serialization/counting, allowing an unexpected secret with zero observed hits.
The proposal serializes/redacts using an explicit active secret/verifier tuple,
classifies rejection, replaces the SAME retained record with finalized redacted
state, then publishes. Its equivalent actual-path unittest passes. This is NOT
a claim that the original pytest node is green, or that its authoritative source
has changed. That original node and all mandatory suites must pass unchanged.

[The unexecuted catalog](unexecuted-tests.md) lists 250 source-level entries,
not collected parameterized IDs. Original metadata for 35 modules is inherited
from the pinned P1-J catalog; 31 modules are not materialized here and were not
independently re-read. Full-suite compatibility and further assertion conflicts
therefore remain UNVERIFIED. Any newly required test/source delta needs separate
review; it is not permission to weaken an existing acceptance test.

## 6. Publication and trust policy

Untrusted output is never evidence merely because it has no exact secret match.
Raw worker output, SQL, inspect fields, exceptions and potentially split/encoded
credentials remain nonpublishable. Six stage files carry only fixed markers;
readiness is privately validated, inventory is ownership-bounded and admitted
JSON uses a strict version-2 schema. Lease/build files are private nonsecret
operational artifacts, not admission receipts. Only trusted fixed host code
constructs fields; producers cannot merge arbitrary dictionaries into records.

Docker logging is disabled for credential-bearing containers, but host/VM/core/
swap/pagefile/hibernation/telemetry behavior is unverified. Container memory-swap
limits are not proof about WSL or Windows backing storage. Before live testing,
require an approved host policy preventing plaintext persistence at every relevant
layer, plus instrumentation. A malicious host or privileged memory observer
cannot be excluded by anonymous pipes. This is NOT a general production secret
manager, and source/mocks/post-run scans cannot establish production safety.

## 7. Explicit prerequisites and live proof obligations

Before protected transfer may be considered:
1. Separate owner review/authorization of this EXACT patch, manifest, all 23
   paths, new protocol/schema, deliberate diagnostics loss, status semantics,
   external restarter dependency and trust boundary; independent human review
   wherever the project requires it. AI review is not that approval.
2. Run full required offline suites with already approved dependencies on both
   Python 3.11 and 3.12 against these exact proposed bytes, including unchanged
   RED, historical parity and applicable launcher/collection regressions. No
   skip/xfail or unreviewed follow-up edits; disclose every failure/conflict.
3. Confirm all protected source preimages and full baseline tree on the intended
   branch. Stop on drift. Retain source gates and excluded-entrypoint holds.

Before ANY real integration (separate permission, never implicit in transfer):
- Approve Linux/WSL host health, fixed local Docker socket and intended Engine
  29.7.2/Desktop host, client/API behavior, exact pinned images (no pin change or
  implicit pull), wheel/dependency closure and applicable supply-chain checks.
- Approve/deploy/verify the independent restarter and nonsecret lease location,
  reboot ordering, deadlines, retries, alerts and uncertain-daemon disposition.
  This deployment scope is excluded from the 23 paths and needs a new decision.
- Verify host, WSL and Docker VM swap/pagefile/core/hibernation/snapshot/telemetry
  controls consistent with the owner's no-persistent-plaintext requirement.
  Refuse live execution if that deployment model cannot meet the requirement.
- Instrument filesystem and process activity DURING startup, bootstrap, clients,
  restart, failure and termination. Include host temp/workspace, WSL, Docker
  data-root, volumes, container layers, logs and dumps. Detect transformations
  and error paths; a clean post-run scan is insufficient. Approve any tracing
  tooling separately; none was installed here.
- Inspect actual container/exec configuration and process argv. Distinguish
  expected transient process-local environment from daemon-stored metadata.
- Exercise fresh init and repeated activation, exact EOF/partial writes,
  malformed frames, blocked reads, wrong passwords, all role privileges, cluster
  identity preservation and the unchanged fixed selectors.
- Exercise actual SIGINT/SIGTERM/SIGKILL in each delivery/creation/auth/output/
  reconciliation/publication seam, CLI vs daemon ambiguity, daemon outage/late
  appearance, supervisor failure, both-process termination and host recovery.
- Prove owned cleanup and foreign resource preservation. Missing confirmation,
  failed retirement/teardown/restoration, stale PASS or ambiguous publication
  must yield no receipt. Recovery/archive import must remain default-deny.

No operational readiness, protected rebaseline acceptance, F-04 closure or
B5-4-2 advancement is established by satisfying only source/offline conditions.

## 8. Exact bounded authorization request — DRAFT ONLY

The following requests a LATER owner decision; no authorization is granted:

> Authorize source application and mock/offline validation ONLY of P1-K3 patch
> SHA-256 d0c57e33d1bd774b26070eaae3278e05335efb993ce8051d86c8c52a032846f7, manifest SHA-256 84f1c22b0d610303b34c31c8f52fd018ede2420cb783754933cc8125c5b3de43, against baseline
> 06c3c374232bb4fad6e549c322e3a1f6bdd0d195. The complete permitted paths and
> resulting Git blobs are exactly the 23 rows in Section 2 / manifest.json.
> Frozen runner preimage is 0863e81b733381a80b2f83560d8bbc231513ba41; wrapper
> preimage is 040d0d30bb719d646eb350b229ccd9a4c5f2bf79. Permit only this exact
> narrow admission/credential transport/supervision/security-test/documentation
> delta. P1-J is not authorized or separately applied. Preserve image/wheel
> pins, original RED and historical assertions, ownership/isolation and all
> exclusions; do not skip/xfail/weaken tests. Stop on source drift, any failed
> mandatory check or any additional required file/delta and return for review.
> Before approval record the prerequisite reviews and unresolved verification
> gaps in Section 7. No Docker/PostgreSQL, operational launchers, real credential
> generation, dependency acquisition, service installation, commit/push/merge,
> deployment, gate closure or B5-4-2 advancement is included. Any real integration
> or restarter deployment requires separately scoped explicit authorization.
> This is owner authorization only if separately granted; AI preparation does
> not constitute independent human security signoff.

## 9. Rollback and stop procedure

No transfer occurred, so rollback now is unnecessary. If later authorized source
application must be reversed: stop/quarantine all operational entrypoints first;
verify each affected path still matches its proposed blob; restore ONLY the 11
existing files from listed preimages and remove ONLY the 12 matching new files.
Stop on drift and preserve unrelated work/evidence. Never blanket reset/prune.
The old baseline restores known credential-file/redaction defects and stays
NO-GO: rollback must not enable its CLI or imply residual-risk acceptance.

If separately authorized live testing has begun, resource retirement is a
separate prerequisite: preserve nonsecret leases and cleanup supervision until
owned resources reconcile; retain UNCONFIRMED and alert if daemon operations are
uncertain. Do not remove foreign resources, erase evidence, or treat source
rollback as credential revocation. Escalate unresolved teardown to the owner.

Stop here for owner review. F-04 OPEN / NO-GO. B5-4-2 BLOCKED.
