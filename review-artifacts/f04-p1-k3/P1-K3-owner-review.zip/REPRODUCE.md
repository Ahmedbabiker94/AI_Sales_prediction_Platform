# Verification plan (not execution authorization)

The ZIP is a review bundle: exact patch, 23 proposed files, identities and logs.
It is not a complete repository checkout. run_mock_proposal.py needs a full
materialized proposed baseline tree; verify_proposal.py additionally uses this
session's retained baseline, P1-J and authoritative snapshot. Those scripts record
local checks and are not advertised as standalone ZIP-only CI tools.

For each file, manifest.json specifies the exact preimage Git blob, resulting
Git blob, SHA-256, size and mode. Git blob identity is SHA-1 of
`b'blob '+str(len(data)).encode('ascii')+b'\0'+data`; SHA-256 is over raw file
bytes. Verify both, including historical fixtures, before execution/reliance.

Future owner-approved offline verification:

1. Authenticate the patch SHA-256 against PACKET.md and the delivered chat hash.
   Verify manifest SHA-256, all 23 proposed raw byte identities, and no unexpected
   file paths or symlink escapes. Review the entire diff and status contract.
2. Materialize a FULL clean pinned baseline commit
   06c3c374232bb4fad6e549c322e3a1f6bdd0d195 in another clearly marked isolated
   directory; do not touch protected/operational branches. Verify each existing
   preimage blob and the expected absence of the 12 new paths. Run only
   `git apply --check /path/to/proposal.patch` there. This does not apply it.
3. If separately permitted for isolated mock verification, reconstruct the
   proposed tree from that baseline and exactly the 23 authenticated proposed
   files. Do not separately apply P1-J. Verify the complete diff equals the
   allowlist and all resulting identities, not merely a selected-file scan.
4. With already approved Python 3.11/3.12 and dependencies (no installation
   authorized by this packet), run this packet's guarded unittest harness against
   the full proposed tree. It denies real child processes/network/signals at an
   audit boundary even when mocks reset, and uses only deterministic public test
   entropy. Preserve fresh logs separately from the delivered evidence.
5. Run ALL 39 exact tests/runtime modules listed by the proposed offline workflow
   under both Python versions with plugin autoload disabled and process/network/
   real-signal denial. Use an approved real pytest installation, no replacement
   framework. Include the ORIGINAL unchanged unexpected_manifest_secret node,
   every historical regression, fixture/provenance/parity, exclusion, admission,
   confidentiality and transport/supervisor test. Record actual collected IDs,
   parametrized counts, Python/dependency versions and exact source bytes.
6. Investigate every error/failure. Additional source/test contract transitions
   require review and authorization; do not skip/xfail or normalize away drift.
7. Real Docker/PostgreSQL, actual signal supervision, source-to-binary rebuilds,
   host/VM tracing and deployment/service changes remain separately authorized
   proof obligations in PACKET.md. No offline command grants those permissions.

The initial four P1-J file-survival assertion failures are retained explicitly in
mock-results-initial.txt. Final method counts are not pytest/CI claims. The
original pytest RED and full required matrix remain unexecuted here.
